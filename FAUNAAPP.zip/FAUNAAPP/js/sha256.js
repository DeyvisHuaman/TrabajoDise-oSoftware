/* SHA-256 (implementación pura en JS, sin dependencias externas).
   Se utiliza para el resguardo de contraseñas: nunca se almacena texto plano. */
(function (global) {
  'use strict';
  var K = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  ];
  function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }

  function bytes(input) {
    if (input instanceof Uint8Array) return input;
    return new TextEncoder().encode(String(input));
  }

  function sha256Bytes(raw) {
    var data = bytes(raw);
    var l = data.length;
    var total = Math.ceil((l + 9) / 64) * 64;
    var msg = new Uint8Array(total);
    msg.set(data);
    msg[l] = 0x80;
    var view = new DataView(msg.buffer);
    var bitsHi = Math.floor((l * 8) / 4294967296);
    var bitsLo = (l * 8) >>> 0;
    view.setUint32(total - 8, bitsHi);
    view.setUint32(total - 4, bitsLo);

    var H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    var w = new Int32Array(64);
    for (var i = 0; i < total; i += 64) {
      for (var t = 0; t < 16; t++) w[t] = view.getInt32(i + t * 4);
      for (t = 16; t < 64; t++) {
        var s0 = rotr(w[t - 15], 7) ^ rotr(w[t - 15], 18) ^ (w[t - 15] >>> 3);
        var s1 = rotr(w[t - 2], 17) ^ rotr(w[t - 2], 19) ^ (w[t - 2] >>> 10);
        w[t] = (w[t - 16] + s0 + w[t - 7] + s1) | 0;
      }
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (t = 0; t < 64; t++) {
        var S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        var ch = (e & f) ^ (~e & g);
        var t1 = (h + S1 + ch + K[t] + w[t]) | 0;
        var S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        var maj = (a & b) ^ (a & c) ^ (b & c);
        var t2 = (S0 + maj) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
      H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    var out = '';
    for (var k = 0; k < 8; k++) out += ('00000000' + (H[k] >>> 0).toString(16)).slice(-8);
    return out;
  }

  function randomSalt(len) {
    len = len || 16;
    var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var out = '';
    var buf = new Uint8Array(len);
    if (global.crypto && global.crypto.getRandomValues) global.crypto.getRandomValues(buf);
    else for (var i = 0; i < len; i++) buf[i] = Math.floor(Math.random() * 256);
    for (var j = 0; j < len; j++) out += chars[buf[j] % chars.length];
    return out;
  }

  /* Derivación iterada tipo PBKDF2 simplificado. El formato almacenado es
     iter$salt$digest — nunca la contraseña. */
  var ITERATIONS = 6000;
  function derive(password, salt, iterations) {
    var value = sha256Bytes(salt + '::' + password + '::sifas');
    for (var i = 0; i < iterations; i++) {
      value = sha256Bytes(value + salt + i);
    }
    return value;
  }
  function hashPassword(password, salt, iterations) {
    salt = salt || randomSalt(16);
    iterations = iterations || ITERATIONS;
    return 'sha256i$' + iterations + '$' + salt + '$' + derive(password, salt, iterations);
  }
  function verifyPassword(password, stored) {
    if (!stored || typeof stored !== 'string') return false;
    var parts = stored.split('$');
    if (parts.length !== 4) return false;
    var iterations = parseInt(parts[1], 10);
    if (!iterations || iterations < 1) return false;
    var candidate = derive(password, parts[2], iterations);
    var expected = parts[3];
    if (candidate.length !== expected.length) return false;
    var diff = 0;
    for (var i = 0; i < candidate.length; i++) diff |= candidate.charCodeAt(i) ^ expected.charCodeAt(i);
    return diff === 0;
  }

  global.SIFAS = global.SIFAS || {};
  global.SIFAS.Hash = {
    sha256: function (text) { return sha256Bytes(text); },
    hashPassword: hashPassword,
    verifyPassword: verifyPassword,
    randomSalt: randomSalt,
    iterations: ITERATIONS
  };
})(typeof window !== 'undefined' ? window : this);

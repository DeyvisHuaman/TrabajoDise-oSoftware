/* Panel, gestión de rescates, triaje, pre-acta digital y edición. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util, D = S.Domain, Store = S.Store, UI = S.UI, Auth = S.Auth, Charts = S.Charts, MapView = S.Map;
  var Views = S.Views = S.Views || {};

  function user() { return Auth.current(); }
  function hasGeo(obj) {
    var loc = obj && obj.location;
    return !!(loc && loc.lat !== null && loc.lat !== undefined && loc.lng !== null && loc.lng !== undefined &&
      isFinite(loc.lat) && isFinite(loc.lng));
  }
  function linkBtn(href, icon, label, cls) {
    return '<a class="btn ' + (cls || 'btn-secondary') + '" href="' + href + '">' + U.icon(icon) + label + '</a>';
  }
  function scoreRing(priority, size) {
    var p = D.normalizePriority(priority);
    var pct = Math.round((U.num(priority && priority.score) / 8) * 100);
    var s = size || 76;
    return '<div class="triage-score-ring" style="--p:' + pct + ';--tc:' + p.color + ';width:' + s + 'px;height:' + s + 'px;flex:0 0 ' + s + 'px">' +
      '<div style="text-align:center"><div class="tsr-num" style="font-size:' + Math.round(s * 0.28) + 'px">' + U.num(priority && priority.score) + '</div>' +
      '<div class="tsr-max">de 8</div></div></div>';
  }
  function criteriaRows(priority) {
    if (!priority || !priority.criteria) return '';
    return D.CRITERIA.map(function (c) {
      var pts = U.num(priority.criteria[c.key]);
      var opt = c.options[pts] || c.options[0];
      return '<div class="crit-row"><span>' + U.esc(c.label) + '</span>' +
        '<span style="display:flex;align-items:center;gap:.5rem"><span class="hint">' + U.esc(opt.label) + '</span>' +
        '<span class="pts p' + pts + '">' + pts + '</span></span></div>';
    }).join('');
  }

  /* ==================================================================
     PANEL DE CONTROL (adaptado por rol)
     ================================================================== */
  function dashboard() {
    var u = user();
    var stats = Store.stats();
    var all = Store.interventions();
    var inCare = all.filter(D.isInCare);
    var html = '';

    function headerBlock(title, sub) {
      return '<div class="page-head"><div class="ph-text"><h1>' + U.esc(title) + '</h1><div class="sub">' + sub + '</div></div>' +
        '<div class="ph-actions">' + (Store.can(u.role, 'rescates.create') ? linkBtn('#/app/rescates/nuevo', 'plus', 'Nuevo rescate', 'btn-primary') : '') +
        (Store.can(u.role, 'reports.view') ? linkBtn('#/app/reportes', 'chart', 'Reportes') : '') + '</div></div>';
    }

    if (u.role === 'logistics') {
      html += headerBlock('Panel de logística', 'Control de alimentos, medicamentos y herramientas de contención · ' + U.fmtDateLong(U.nowISO()));
      html += logisticsDashboard();
      return { html: html, mount: bindDashboard };
    }
    if (u.role === 'vet') {
      html += headerBlock('Panel clínico', 'Cola de atención por prioridad de triaje · ' + U.fmtDateLong(U.nowISO()));
      html += vetDashboard();
      return { html: html, mount: bindDashboard };
    }
    if (u.role === 'field') {
      html += headerBlock('Panel de campo', 'Registro y seguimiento de intervenciones · ' + U.fmtDateLong(U.nowISO()));
      html += fieldDashboard();
      return { html: html, mount: bindDashboard };
    }

    /* Administrador */
    html += headerBlock('Panel de control', 'Indicadores consolidados de la ATFFS Sierra Central · actualizado ' + U.fmtTime(U.nowISO()));
    html += '<div class="grid grid-4 section">' +
      statCard('paw', 'Rescates registrados', stats.total, 'Total histórico de intervenciones', '') +
      statCard('heart', 'En rehabilitación', stats.inCare, 'Animales en cuarentena o atención', 'tone-amber') +
      statCard('leaf', 'Liberaciones', stats.released, 'Con decisión técnica de liberación', 'tone-blue') +
      statCard('alert', 'Prioridad I activos', stats.critical, 'Requieren atención inmediata', 'tone-red') +
      '</div>';

    html += '<div class="grid grid-4 section">' +
      miniStat('Denuncias nuevas', stats.newDenuncias, 'Total ' + stats.denuncias + ' reportes ciudadanos', 'badge-blue') +
      miniStat('Alertas de inventario', stats.inventoryAlerts, 'Stock mínimo o vencimiento', 'badge-amber') +
      miniStat('Custodia permanente', stats.custody, 'Derivados a centros autorizados', 'badge-purple') +
      miniStat('Especies atendidas', stats.speciesInCare, 'Especies distintas en rehabilitación', 'badge-green') +
      '</div>';

    var monthly = lastMonthsSeries(all, 6);
    var bySpecies = countBy(all, function (i) { return i.speciesName; }).slice(0, 6);
    var byZone = countBy(all, function (i) { return (i.location && i.location.zone) || 'Sin zona'; }).slice(0, 6);
    var byPriority = ['I', 'II', 'III'].map(function (lvl) {
      return { label: 'Prioridad ' + lvl, value: all.filter(function (i) { return i.priority.level === lvl; }).length, color: D.PRIORITY[lvl].color };
    });

    html += '<div class="split section">' +
      '<div class="card"><div class="card-head"><h3>' + U.icon('activity') + ' Evolución de intervenciones</h3><div class="ch-actions"><span class="hint">Últimos 6 meses</span></div></div>' +
      '<div class="card-body">' + Charts.line([{ points: monthly, color: '#1b7a56', label: 'Intervenciones registradas por mes' }], { height: 200 }) + '</div></div>' +
      '<div class="card"><div class="card-head"><h3>Distribución por triaje</h3></div><div class="card-body">' +
      Charts.donut(byPriority, { centerLabel: 'intervenciones', size: 140 }) + '</div></div>' +
      '</div>';

    html += '<div class="split-even section">' +
      '<div class="card"><div class="card-head"><h3>Especies con más ingresos</h3><span class="hint" style="margin-left:auto">Top 6</span></div><div class="card-body">' +
      Charts.barList(bySpecies, { color: '#2a9169' }) + '</div></div>' +
      '<div class="card"><div class="card-head"><h3>Zonas con mayor concentración</h3><span class="hint" style="margin-left:auto">Según GPS</span></div><div class="card-body">' +
      Charts.barList(byZone, { color: '#b7791f' }) + '</div></div>' +
      '</div>';

    var mapMarkers = all.filter(hasGeo).map(function (i) {
      return {
        id: i.id, lat: i.location.lat, lng: i.location.lng, color: D.normalizePriority(i.priority).color,
        title: i.code, subtitle: i.speciesName + ' · ' + U.fmtDate(i.occurredAt)
      };
    });
    html += '<div class="card section"><div class="card-head"><h3>' + U.icon('map') + ' Mapa de intervenciones</h3>' +
      '<div class="ch-actions">' + linkBtn('#/app/mapa', 'external', 'Ver mapa completo') + '</div></div>' +
      '<div class="card-body"><div id="dash-map"></div></div></div>';

    html += '<div class="split section">' +
      '<div class="card"><div class="card-head"><h3>Últimas intervenciones</h3><div class="ch-actions">' + linkBtn('#/app/rescates', 'arrowRight', 'Ver todas') + '</div></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Código</th><th>Especie</th><th>Triaje</th><th>Estado</th><th>Fecha</th></tr></thead><tbody>' +
      U.sortBy(all, function (i) { return new Date(i.createdAt); }, true).slice(0, 6).map(function (i) {
        return '<tr class="is-click" data-go="#/app/rescates/' + i.id + '"><td class="t-code">' + U.esc(i.code) + '</td>' +
          '<td><div class="t-main">' + U.esc(i.speciesName) + '</div><div class="t-sub">' + U.esc((i.location && i.location.zone) || 'Sin zona') + '</div></td>' +
          '<td>' + UI.priorityBadge(i.priority.level) + '</td><td>' + UI.statusBadge(i.status) + '</td>' +
          '<td class="t-nowrap t-sub">' + U.fmtDate(i.occurredAt) + '</td></tr>';
      }).join('') + '</tbody></table></div></div>' +
      '<div class="card"><div class="card-head"><h3>Actividad reciente</h3></div><div class="card-body" style="padding-top:.4rem">' +
      auditList(Store.get().audit.slice(0, 7)) + '</div></div>' +
      '</div>';

    return {
      html: html,
      mount: function (root) {
        bindDashboard(root);
        var holder = root.querySelector('#dash-map');
        if (holder) MapView.create(holder, {
          markers: mapMarkers, legend: true, showZones: true,
          onSelect: function (id) { location.hash = '#/app/rescates/' + id; }
        });
      }
    };
  }

  function statCard(icon, label, value, foot, tone) {
    return '<article class="stat ' + (tone || '') + '"><div class="st-top"><span class="st-icon">' + U.icon(icon) + '</span><span class="st-label">' + label + '</span></div>' +
      '<div class="st-value">' + value + '</div><div class="st-foot">' + foot + '</div></article>';
  }
  function miniStat(label, value, foot, tone) {
    return '<div class="card card-pad" style="display:flex;align-items:center;gap:.8rem"><div style="flex:1"><div class="hint" style="font-weight:700">' + U.esc(label) + '</div>' +
      '<div style="font-size:1.4rem;font-weight:800;letter-spacing:-.02em">' + value + '</div>' +
      '<div class="hint" style="font-size:.68rem">' + U.esc(foot) + '</div></div>' + UI.badge(String(value), tone) + '</div>';
  }
  function countBy(list, keyFn) {
    var map = {};
    list.forEach(function (i) { var k = keyFn(i) || 'Sin dato'; map[k] = (map[k] || 0) + 1; });
    return Object.keys(map).map(function (k) { return { label: k, value: map[k] }; })
      .sort(function (a, b) { return b.value - a.value; });
  }
  function lastMonthsSeries(list, months) {
    var out = [];
    var now = new Date();
    for (var i = months - 1; i >= 0; i--) {
      var d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      var next = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
      var count = list.filter(function (it) {
        var t = new Date(it.occurredAt || it.createdAt);
        return t >= d && t < next;
      }).length;
      out.push({ ts: d.toISOString(), value: count, label: U.fmtMonth(d) });
    }
    return out;
  }
  function auditList(logs) {
    if (!logs.length) return '<p class="hint">Sin actividad registrada.</p>';
    return '<div class="timeline">' + logs.map(function (l) {
      return '<div class="tl-item"><div class="tl-head"><span class="tl-title">' + U.esc(l.action) + '</span><span class="tl-time">' + U.timeAgo(l.ts) + '</span></div>' +
        '<div class="tl-body">' + U.esc(l.userName) + ' · <span class="text-muted">' + U.esc(l.detail) + '</span></div></div>';
    }).join('') + '</div>';
  }

  function vetDashboard() {
    var all = Store.interventions();
    var inCare = all.filter(D.isInCare);
    var queue = U.sortBy(inCare, function (i) { return (i.priority.order || 3) * 10000000000000 + new Date(i.occurredAt).getTime(); });
    var noControl = inCare.filter(function (i) {
      var sum = Store.clinicalSummary(i.id);
      return !sum.lastControl || (Date.now() - new Date(sum.lastControl.ts).getTime()) > 3 * 86400000;
    });
    var notified = Store.notificationsFor('vet').filter(function (n) { return !n.read; });
    var h = '<div class="grid grid-4 section">' +
      statCard('alert', 'Prioridad I en atención', stats(all).critical, 'Atención inmediata (RD011)', 'tone-red') +
      statCard('heart', 'Animales en cuarentena', inCare.length, 'Con historia clínica activa', 'tone-amber') +
      statCard('activity', 'Controles pendientes', noControl.length, 'Sin control en más de 3 días', 'tone-blue') +
      statCard('checkCircle', 'Altas médicas', all.filter(function (i) { return i.discharge; }).length, 'Habilitados para evaluación de liberación', '') +
      '</div>';
    if (notified.length) {
      h += '<div class="alert-banner ab-red">' + U.icon('alert') + '<div><strong>' + notified.length + ' alerta(s) de atención inmediata.</strong> ' +
        'Existen animales clasificados con Prioridad I que requieren evaluación veterinaria.</div></div>';
    }
    h += '<div class="card section"><div class="card-head"><h3>Cola de atención clínica</h3><span class="hint" style="margin-left:auto">Ordenada por prioridad de triaje y fecha de ingreso</span></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Prioridad</th><th>Código / especie</th><th>Ingreso</th><th>Último control</th><th>Estado</th><th></th></tr></thead><tbody>' +
      (queue.length ? queue.map(function (i) {
        var sum = Store.clinicalSummary(i.id);
        return '<tr><td>' + UI.priorityBadge(i.priority.level) + '</td>' +
          '<td><div class="t-main">' + U.esc(i.speciesName) + '</div><div class="t-code">' + U.esc(i.code) + '</div></td>' +
          '<td class="t-sub t-nowrap">' + U.fmtDate(i.occurredAt) + '</td>' +
          '<td class="t-sub t-nowrap">' + (sum.lastControl ? U.fmtDate(sum.lastControl.ts) : '<span class="text-red">Sin control</span>') + '</td>' +
          '<td>' + UI.statusBadge(i.status) + '</td>' +
          '<td class="t-right"><a class="btn btn-sm btn-soft" href="#/app/clinica/' + i.id + '">Atender ' + U.icon('arrowRight') + '</a></td></tr>';
      }).join('') : '<tr><td colspan="6">' + UI.empty('checkCircle', 'Sin animales pendientes', 'No hay animales en rehabilitación en este momento.') + '</td></tr>') +
      '</tbody></table></div></div>';
    h += '<div class="split"><div class="card"><div class="card-head"><h3>Últimos registros clínicos</h3></div><div class="card-body" style="padding-top:.5rem">' +
      (Store.get().clinicalRecords.slice(-6).reverse().map(function (r) {
        var intv = Store.intervention(r.interventionId);
        return '<div class="list-item"><div class="li-icon">' + U.icon(D.RECORD_TYPES[r.type].icon) + '</div>' +
          '<div class="li-main"><div class="li-title">' + U.esc(intv ? intv.speciesName : 'Animal') + ' · ' + U.esc(D.RECORD_TYPES[r.type].label) + '</div>' +
          '<div class="li-sub">' + U.esc(r.vetName) + ' · ' + U.esc(r.diagnosis || r.observations || r.diet || '') + '</div></div>' +
          '<div class="li-right">' + U.timeAgo(r.ts) + '</div></div>';
      }).join('') || '<p class="hint">Sin registros.</p>') + '</div></div>' +
      '<div class="card"><div class="card-head"><h3>Notificaciones</h3></div><div class="card-body" style="padding-top:.5rem">' +
      notificationsList('vet') + '</div></div></div>';
    return h;
  }
  function stats(all) {
    var st = Store.stats(); return st;
  }
  function notificationsList(role) {
    var list = Store.notificationsFor(role).slice(0, 6);
    if (!list.length) return '<p class="hint">Sin notificaciones pendientes.</p>';
    return list.map(function (n) {
      return '<a class="list-item" href="' + U.attr(n.link || '#') + '" style="text-decoration:none;color:inherit">' +
        '<div class="li-icon">' + U.icon(n.type === 'inventory' ? 'box' : n.type === 'denuncia' ? 'alert' : 'activity') + '</div>' +
        '<div class="li-main"><div class="li-title">' + U.esc(n.title) + '</div><div class="li-sub">' + U.esc(n.message) + '</div></div>' +
        '<div class="li-right">' + U.timeAgo(n.ts) + '</div></a>';
    }).join('');
  }
  function fieldDashboard() {
    var u = user();
    var mine = Store.interventions().filter(function (i) { return i.agentId === u.id; });
    var today = U.dayKey(U.nowISO());
    var todayCount = mine.filter(function (i) { return U.dayKey(i.createdAt) === today; }).length;
    var critical = mine.filter(function (i) { return D.isInCare(i) && i.priority.level === 'I'; });
    var pending = mine.filter(function (i) { return Store.clinicalSummary(i.id).count === 0; });
    var h = '<div class="grid grid-4 section">' +
      statCard('paw', 'Mis rescates', mine.length, 'Intervenciones registradas', '') +
      statCard('calendar', 'Registrados hoy', todayCount, U.fmtDateLong(U.nowISO()), 'tone-blue') +
      statCard('alert', 'Prioridad I activos', critical.length, 'Atención veterinaria inmediata', 'tone-red') +
      statCard('file', 'Pendientes de historia clínica', pending.length, 'Sin evaluación veterinaria', 'tone-amber') +
      '</div>' +
      '<div class="alert-banner ab-green">' + U.icon('camera') + '<div><strong>Registro en campo.</strong> Puedes crear una ficha desde tu celular en pocos pasos: la ubicación GPS y las fotografías quedan asociadas automáticamente a la intervención.</div></div>' +
      '<div class="split">' +
      '<div class="card"><div class="card-head"><h3>Mis intervenciones recientes</h3><div class="ch-actions">' + linkBtn('#/app/rescates', 'list', 'Ver todas') + '</div></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Código</th><th>Especie</th><th>Triaje</th><th>Estado</th><th>Fecha</th></tr></thead><tbody>' +
      (mine.length ? U.sortBy(mine, function (i) { return new Date(i.createdAt); }, true).slice(0, 7).map(function (i) {
        return '<tr class="is-click" data-go="#/app/rescates/' + i.id + '"><td class="t-code">' + U.esc(i.code) + '</td>' +
          '<td><div class="t-main">' + U.esc(i.speciesName) + '</div><div class="t-sub">' + U.esc((i.location && i.location.zone) || 'Sin ubicación') + '</div></td>' +
          '<td>' + UI.priorityBadge(i.priority.level) + '</td><td>' + UI.statusBadge(i.status) + '</td><td class="t-sub t-nowrap">' + U.fmtDate(i.occurredAt) + '</td></tr>';
      }).join('') : '<tr><td colspan="5">' + UI.empty('paw', 'Aún no registras rescates', 'Cuando registres una intervención aparecerá en esta lista.', '<a class="btn btn-primary" href="#/app/rescates/nuevo">Registrar ahora</a>') + '</td></tr>') +
      '</tbody></table></div></div>' +
      '<div style="display:flex;flex-direction:column;gap:1rem">' +
      '<div class="card card-pad" style="background:linear-gradient(150deg,#0f4a35,#0b3d2c);color:#fff">' +
      '<h3 style="color:#fff;font-size:1rem">' + U.icon('plus') + ' Registrar un rescate</h3>' +
      '<p style="font-size:.78rem;color:#b9d8c9;margin:.4rem 0 .9rem">Ficha digital, GPS, fotografías, triaje y pre-acta en un solo flujo.</p>' +
      '<a class="btn btn-primary btn-block" href="#/app/rescates/nuevo" style="background:#7fd1a8;color:#062117">Comenzar registro</a></div>' +
      '<div class="card"><div class="card-head"><h3>Alertas de prioridad</h3></div><div class="card-body" style="padding-top:.4rem">' +
      (critical.length ? critical.map(function (i) {
        return '<a class="list-item" href="#/app/rescates/' + i.id + '" style="text-decoration:none;color:inherit"><div class="li-icon" style="background:var(--red-100);color:var(--red-700)">' + U.icon('alert') + '</div>' +
          '<div class="li-main"><div class="li-title">' + U.esc(i.speciesName) + '</div><div class="li-sub">' + U.esc(i.code) + ' · Prioridad I</div></div></a>';
      }).join('') : '<p class="hint">Sin alertas de prioridad I activas.</p>') + '</div></div>' +
      '</div></div>';
    return h;
  }
  function logisticsDashboard() {
    var items = Store.items().filter(function (i) { return i.active; });
    var alerts = D.inventoryAlerts(Store.items());
    var today = U.dayKey(U.nowISO());
    var movementsToday = Store.movements().filter(function (m) { return U.dayKey(m.ts) === today; });
    var h = '<div class="grid grid-4 section">' +
      statCard('box', 'Insumos activos', items.length, 'Alimentos, medicamentos y herramientas', '') +
      statCard('alert', 'Stock mínimo', alerts.filter(function (a) { return a.type === 'stock'; }).length, 'Insumos por debajo del mínimo', 'tone-red') +
      statCard('clock', 'Por vencer / vencidos', alerts.filter(function (a) { return a.type === 'por_vencer' || a.type === 'vencido'; }).length, 'Vencimiento en los próximos 30 días', 'tone-amber') +
      statCard('activity', 'Movimientos hoy', movementsToday.length, 'Entradas y salidas registradas', 'tone-blue') +
      '</div>' +
      '<div class="card section"><div class="card-head"><h3>' + U.icon('alert') + ' Alertas automáticas</h3><div class="ch-actions">' + linkBtn('#/app/inventario', 'external', 'Ir al inventario') + '</div></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Alerta</th><th>Producto</th><th>Motivo</th><th>Stock</th><th></th></tr></thead><tbody>' +
      (alerts.length ? alerts.map(function (a) {
        return '<tr><td>' + UI.badge(a.title, a.severity === 1 ? 'red' : 'amber') + '</td>' +
          '<td><div class="t-main">' + U.esc(a.item.name) + '</div><div class="t-sub">' + U.esc(a.item.code) + '</div></td>' +
          '<td class="t-sub">' + U.esc(a.reason) + '</td>' +
          '<td class="t-nowrap"><strong>' + a.item.stock + '</strong> ' + U.esc(a.item.unit) + '</td>' +
          '<td class="t-right"><button class="btn btn-sm btn-soft" data-move="' + U.attr(a.item.id) + '">Registrar movimiento</button></td></tr>';
      }).join('') : '<tr><td colspan="5"><div class="table-empty">' + U.icon('checkCircle') + 'Sin alertas: el inventario se encuentra en niveles adecuados.</div></td></tr>') +
      '</tbody></table></div></div>' +
      '<div class="split"><div class="card"><div class="card-head"><h3>Inventario resumido</h3></div><div class="card-body" style="padding-top:.4rem">' +
      items.slice(0, 8).map(function (it) {
        var low = U.num(it.stock) <= U.num(it.minStock);
        var st = D.expiryStatus(it.expiresAt);
        return '<div class="list-item"><div class="li-icon">' + U.icon((D.INVENTORY_CATEGORIES.filter(function (c) { return c.key === it.category; })[0] || {}).icon || 'box') + '</div>' +
          '<div class="li-main"><div class="li-title">' + U.esc(it.name) + '</div><div class="li-sub">' + U.esc(it.code) + ' · ' + (it.expiresAt ? st.label : 'Sin vencimiento') + '</div></div>' +
          '<div class="li-right"><strong style="color:' + (low ? 'var(--red-700)' : 'var(--ink)') + '">' + it.stock + '</strong> ' + U.esc(it.unit) + '</div></div>';
      }).join('') + '</div></div>' +
      '<div class="card"><div class="card-head"><h3>Últimos movimientos</h3></div><div class="card-body" style="padding-top:.4rem">' +
      Store.movements().slice(0, 7).map(function (m) {
        return '<div class="list-item"><div class="li-icon" style="background:' + (m.type === 'entrada' ? '#e3f4ea' : '#fdf3d9') + ';color:' + (m.type === 'entrada' ? '#146c46' : '#8a5a0b') + '">' + U.icon(m.type === 'entrada' ? 'download' : 'send') + '</div>' +
          '<div class="li-main"><div class="li-title">' + U.esc(m.itemName) + '</div><div class="li-sub">' + U.esc(m.userName) + ' · ' + U.esc(m.reason) + '</div></div>' +
          '<div class="li-right">' + (m.type === 'entrada' ? '+' : '−') + m.qty + ' · ' + U.timeAgo(m.ts) + '</div></div>';
      }).join('') + '</div></div></div>';
    return h;
  }

  function bindDashboard(root) {
    U.on(root, '[data-go]', 'click', function () { location.hash = this.getAttribute('data-go'); });
    U.on(root, '[data-move]', 'click', function () {
      if (S.Views.inventory) S.Views.inventory.openMoveModal(this.getAttribute('data-move'), 'entrada', function () { S.App.refresh(); });
    });
  }

  /* ==================================================================
     LISTADO DE RESCATES
     ================================================================== */
  function rescates() {
    var canCreate = Store.can(user().role, 'rescates.create');
    var html = '<div class="page-head"><div class="ph-text"><h1>Rescates y decomisos</h1>' +
      '<div class="sub">Registro único de intervenciones de fauna silvestre · código ATFFS-HYO</div></div>' +
      '<div class="ph-actions">' + (canCreate ? linkBtn('#/app/rescates/nuevo', 'plus', 'Nuevo rescate', 'btn-primary') : '') + '</div></div>' +
      '<div class="card"><div class="card-body">' +
      '<div class="toolbar">' +
      '<div class="search-box">' + U.icon('search') + '<input class="input" id="flt-q" type="search" placeholder="Buscar por código, especie o agente…" aria-label="Buscar"></div>' +
      '<select class="select" id="flt-pri" aria-label="Filtrar prioridad"><option value="">Toda prioridad</option><option value="I">Prioridad I</option><option value="II">Prioridad II</option><option value="III">Prioridad III</option></select>' +
      '<select class="select" id="flt-status" aria-label="Filtrar estado"><option value="">Todo estado</option>' + Object.keys(D.STATUS).map(function (k) { return '<option value="' + k + '">' + D.STATUS[k].label + '</option>'; }).join('') + '</select>' +
      '<span class="spacer"></span><span class="result-count" id="flt-count"></span>' +
      '</div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Código</th><th>Especie / intervención</th><th>Ubicación</th><th>Triaje</th><th>Estado</th><th>Agente</th><th>Fecha</th><th></th></tr></thead><tbody id="flt-body"></tbody></table></div>' +
      '</div></div>';
    return {
      html: html,
      mount: function (root) {
        var all = U.sortBy(Store.interventions(), function (i) { return new Date(i.occurredAt); }, true);
        var body = root.querySelector('#flt-body');
        var q = root.querySelector('#flt-q'), pri = root.querySelector('#flt-pri'), st = root.querySelector('#flt-status'), count = root.querySelector('#flt-count');
        function draw() {
          var query = U.normalize(q.value);
          var list = all.filter(function (i) {
            var text = U.normalize(i.code + ' ' + i.speciesName + ' ' + i.agentName + ' ' + ((i.location && i.location.zone) || '') + ' ' + i.description);
            return (!query || text.indexOf(query) >= 0) && (!pri.value || i.priority.level === pri.value) && (!st.value || i.status === st.value);
          });
          count.textContent = list.length + ' de ' + all.length + ' intervenciones';
          body.innerHTML = list.length ? list.map(function (i) {
            return '<tr class="is-click" data-go="#/app/rescates/' + i.id + '">' +
              '<td class="t-code">' + U.esc(i.code) + '</td>' +
              '<td><div class="t-main">' + U.esc(i.speciesName) + '</div><div class="t-sub">' + U.esc(U.titleCase(i.type)) + ' · ' + U.esc(i.preliminaryId) + '</div></td>' +
              '<td><div class="t-sub">' + U.icon('pin') + ' ' + U.esc((i.location && i.location.zone) || 'Sin GPS') + '</div>' +
              '<div class="t-sub" style="font-size:.66rem">' + U.esc((i.location && i.location.reference) || '') + '</div></td>' +
              '<td>' + UI.priorityBadge(i.priority.level) + '</td>' +
              '<td>' + UI.statusBadge(i.status) + '</td>' +
              '<td class="t-sub">' + U.esc(i.agentName) + '</td>' +
              '<td class="t-sub t-nowrap">' + U.fmtDate(i.occurredAt) + '<br>' + U.fmtTime(i.occurredAt) + '</td>' +
              '<td class="t-right">' + U.icon('chevronRight') + '</td></tr>';
          }).join('') : '<tr><td colspan="8"><div class="table-empty">' + U.icon('search') + 'No se encontraron intervenciones con los filtros seleccionados.</div></td></tr>';
        }
        q.addEventListener('input', U.debounce(draw, 180));
        pri.addEventListener('change', draw); st.addEventListener('change', draw);
        U.on(root, '[data-go]', 'click', function () { location.hash = this.getAttribute('data-go'); });
        draw();
      }
    };
  }

  /* ==================================================================
     NUEVO RESCATE (asistente)
     ================================================================== */
  function nuevo() {
    var speciesAll = Store.species();
    var conditions = D.CONDITIONS;
    var steps = ['Datos del animal', 'Ubicación', 'Evidencias', 'Triaje', 'Pre-acta'];
    var html = '<div class="page-head"><div class="ph-text"><h1>Registrar nuevo rescate</h1>' +
      '<div class="sub">Ficha digital de intervención · el código único y la pre-acta se generan al guardar</div></div>' +
      '<div class="ph-actions">' + linkBtn('#/app/rescates', 'arrowLeft', 'Volver') + '</div></div>' +
      '<form id="wiz-form" novalidate>' +
      '<div class="stepper" id="wiz-steps">' + steps.map(function (s, i) {
        return '<button class="step" type="button" data-step-btn="' + i + '"><span class="s-num">' + (i + 1) + '</span>' + s + '</button>' +
          (i < steps.length - 1 ? '<span class="step-sep"></span>' : '');
      }).join('') + '</div>' +
      '<div class="split"><div>' +

      '<section data-panel="0" class="card card-pad">' +
      '<div class="fs-title" style="font-size:.8rem;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:var(--green-800);margin-bottom:.8rem">' + U.icon('paw') + ' Identificación preliminar y condiciones del hallazgo</div>' +
      '<div class="form-grid">' +
      '<div class="field span-2"><label for="f-species">Especie o identificación preliminar <span class="req">*</span></label>' +
      '<input class="input" id="f-species" name="speciesName" list="wiz-species" placeholder="Escriba el nombre común de la especie…" autocomplete="off" required>' +
      '<datalist id="wiz-species">' + speciesAll.map(function (s) { return '<option value="' + U.attr(s.common) + '">' + U.attr(s.sci) + '</option>'; }).join('') + '</datalist>' +
      '<div class="err" data-err="species">Indique la especie o una identificación preliminar del animal.</div>' +
      '<span class="hint" id="f-species-hint">Si no logras identificarla, escribe «No identificada» y describe el animal.</span></div>' +
      '<div class="field"><label for="f-type">Tipo de intervención</label><select class="select" id="f-type" name="type">' +
      D.INTERVENTION_TYPES.map(function (t) { return '<option value="' + t.key + '">' + t.label + '</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label for="f-when">Fecha y hora de la intervención</label><input class="input" id="f-when" name="occurredAt" type="datetime-local" value="' + U.attr(U.toLocalInput()) + '"></div>' +
      '<div class="field"><label for="f-prelim">Identificación preliminar</label><input class="input" id="f-prelim" name="preliminaryId" maxlength="120" placeholder="Ej. Juvenil, macho, aprox. 1 año"></div>' +
      '<div class="field"><label for="f-ref">Referencia del lugar</label><input class="input" id="f-ref" name="reference" maxlength="140" placeholder="Ej. Mercado Modelo de Huancayo"></div>' +
      '<div class="field span-2"><label for="f-desc">Descripción de la intervención <span class="req">*</span></label>' +
      '<textarea class="textarea" id="f-desc" name="description" maxlength="1200" placeholder="Describe cómo fue hallado el animal, las circunstancias del decomiso y cualquier detalle relevante…" required></textarea>' +
      '<div class="err" data-err="description">Describa la intervención con al menos 10 caracteres.</div></div>' +
      '<div class="field span-2"><label>Condiciones en las que fue encontrado</label>' +
      '<div class="check-grid">' + conditions.map(function (c) {
        return '<label class="check"><input type="checkbox" name="conditions" value="' + U.attr(c) + '">' + U.esc(c) + '</label>';
      }).join('') + '</div></div>' +
      '</div></section>' +

      '<section data-panel="1" class="card card-pad is-hidden">' +
      '<div class="fs-title" style="font-size:.8rem;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:var(--green-800);margin-bottom:.8rem">' + U.icon('pin') + ' Ubicación GPS del rescate</div>' +
      '<p class="fs-sub" style="font-size:.75rem;color:var(--muted);margin:-.3rem 0 .8rem">El sistema obtiene las coordenadas del dispositivo. Si no es posible, informa al usuario y permite continuar con el procedimiento establecido.</p>' +
      '<div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:.8rem">' +
      '<button class="btn btn-primary" type="button" id="wiz-gps">' + U.icon('pin') + 'Capturar ubicación GPS</button>' +
      '<button class="btn btn-ghost" type="button" id="wiz-clear-loc">' + U.icon('x') + 'Limpiar</button>' +
      '<span class="hint" id="wiz-gps-status" style="align-self:center">Aún no se ha capturado la ubicación.</span></div>' +
      '<div id="wiz-map" style="margin-bottom:.9rem"></div>' +
      '<div class="form-grid">' +
      '<div class="field"><label for="f-lat">Latitud</label><input class="input" id="f-lat" name="lat" readonly placeholder="—"></div>' +
      '<div class="field"><label for="f-lng">Longitud</label><input class="input" id="f-lng" name="lng" readonly placeholder="—"></div>' +
      '</div>' +
      '<div class="alert-banner ab-amber" style="margin-top:.9rem;margin-bottom:0">' + U.icon('info') +
      '<span><strong>Sin GPS:</strong> si el dispositivo no permite obtener la ubicación, puedes continuar el registro y consignar la referencia del lugar.</span></div>' +
      '</section>' +

      '<section data-panel="2" class="card card-pad is-hidden">' +
      '<div class="fs-title" style="font-size:.8rem;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:var(--green-800);margin-bottom:.8rem">' + U.icon('camera') + ' Evidencias fotográficas</div>' +
      '<p class="fs-sub" style="font-size:.75rem;color:var(--muted);margin:-.3rem 0 .8rem">Adjunta fotografías del animal y del lugar. Cada evidencia conserva la fecha y hora de registro.</p>' +
      '<div class="uploader"><div class="up-icon">' + U.icon('camera') + '</div><p>Toma una fotografía o adjunta archivos existentes</p>' +
      '<div class="up-actions"><label class="btn btn-secondary btn-sm" style="margin:0">' + U.icon('camera') + 'Tomar foto<input type="file" id="wiz-camera" accept="image/*" capture="environment" multiple hidden></label>' +
      '<label class="btn btn-secondary btn-sm" style="margin:0">' + U.icon('image') + 'Adjuntar<input type="file" id="wiz-files" accept="image/*" multiple hidden></label></div>' +
      '<div class="hint">Hasta 8 imágenes · compresión automática en el dispositivo.</div></div>' +
      '<div class="photo-grid" id="wiz-photos" style="margin-top:.8rem"></div>' +
      '</section>' +

      '<section data-panel="3" class="card card-pad is-hidden">' +
      '<div class="fs-title" style="font-size:.8rem;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:var(--green-800);margin-bottom:.8rem">' + U.icon('activity') + ' Triaje inicial — cuatro criterios clínicos</div>' +
      '<p class="fs-sub" style="font-size:.75rem;color:var(--muted);margin:-.3rem 0 .8rem">Califica cada criterio de 0 a 2. La prioridad se asigna automáticamente según la regla RD011.</p>' +
      D.CRITERIA.map(function (c) {
        return '<div style="margin-bottom:1rem"><div class="lbl" style="margin-bottom:.35rem">' + U.icon(c.icon) + ' ' + U.esc(c.label) + '</div>' +
          '<div class="radio-cards">' + c.options.map(function (o) {
            return '<label class="radio-card"><input type="radio" name="crit_' + c.key + '" value="' + o.score + '">' +
              '<span style="flex:1"><span class="rc-title">' + U.esc(o.label) + '</span><span class="rc-desc">' + U.esc(o.desc) + '</span></span>' +
              '<span class="pts p' + o.score + '">' + o.score + ' pt' + (o.score === 1 ? '' : 's') + '</span></label>';
          }).join('') + '</div></div>';
      }).join('') +
      '<div class="err" data-err="criteria">Califique los cuatro criterios para calcular la prioridad.</div>' +
      '</section>' +

      '<section data-panel="4" class="is-hidden">' +
      '<div class="card card-pad"><div class="fs-title" style="font-size:.8rem;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:var(--green-800);margin-bottom:.8rem">' + U.icon('checkCircle') + ' Revisión y generación de pre-acta</div>' +
      '<div id="wiz-review"></div></div></section>' +

      '<div class="form-actions" style="margin-top:1rem">' +
      '<button class="btn btn-secondary" type="button" id="wiz-prev">' + U.icon('arrowLeft') + 'Anterior</button>' +
      '<button class="btn btn-primary" type="button" id="wiz-next">Continuar' + U.icon('arrowRight') + '</button>' +
      '<button class="btn btn-primary is-hidden" type="submit" id="wiz-save">' + U.icon('save') + 'Guardar y generar pre-acta</button>' +
      '</div>' +
      '</div>' +
      '<aside><div class="triage-box" id="triage-box"></div>' +
      '<div class="card card-pad mt-2"><div class="note">' + U.icon('info') +
      '<span><strong>Regla de prioridad RD011.</strong> Prioridad I si el total es 5–8 o si «signos vitales» obtiene 2 puntos. Prioridad II si el total es 2–4. Prioridad III si el total es 0–1.</span></div></div>' +
      '<div class="card card-pad mt-2"><div class="note">' + U.icon('database') +
      '<span>El código único de intervención y la pre-acta digital se generan automáticamente al guardar. La información queda asociada a tu usuario.</span></div></div>' +
      '</aside></div></form>';

    return {
      html: html,
      mount: function (root) {
        var state = { step: 0, photos: [], location: null, source: 'sin_gps', speciesId: null };
        var form = root.querySelector('#wiz-form');
        var panels = U.$$('[data-panel]', root);
        var stepBtns = U.$$('[data-step-btn]', root);
        var btnPrev = root.querySelector('#wiz-prev');
        var btnNext = root.querySelector('#wiz-next');
        var btnSave = root.querySelector('#wiz-save');
        var triageBox = root.querySelector('#triage-box');
        var speciesInput = root.querySelector('#f-species');
        var latInput = root.querySelector('#f-lat'), lngInput = root.querySelector('#f-lng');
        var gpsStatus = root.querySelector('#wiz-gps-status');

        var map = MapView.create(root.querySelector('#wiz-map'), {
          markers: [], pick: true, showZones: true, legend: false, zoom: true,
          onPick: function (ll) {
            setLocation(ll, 'map');
            gpsStatus.textContent = 'Ubicación fijada manualmente en el mapa.';
          }
        });

        function setLocation(ll, source) {
          state.location = ll; state.source = source;
          latInput.value = ll ? ll.lat : '';
          lngInput.value = ll ? ll.lng : '';
          map.update({ pickMarker: ll });
        }
        root.querySelector('#wiz-gps').addEventListener('click', function () {
          if (!navigator.geolocation) { gpsStatus.textContent = 'GPS no disponible. Marca el punto en el mapa.'; UI.toast('Este navegador no permite obtener la ubicación.', 'warn'); return; }
          gpsStatus.textContent = 'Obteniendo ubicación GPS…';
          navigator.geolocation.getCurrentPosition(function (pos) {
            var ll = { lat: +pos.coords.latitude.toFixed(5), lng: +pos.coords.longitude.toFixed(5) };
            setLocation(ll, 'gps');
            gpsStatus.textContent = 'GPS capturado · precisión ±' + Math.round(pos.coords.accuracy) + ' m.';
            UI.toast('Ubicación GPS asociada a la intervención.', 'success');
          }, function () {
            gpsStatus.textContent = 'No se pudo obtener el GPS. Puedes fijar el punto en el mapa.';
            UI.toast('No fue posible obtener la ubicación GPS. El sistema permite continuar y fijar el punto manualmente.', 'warn');
          }, { enableHighAccuracy: true, timeout: 9000, maximumAge: 0 });
        });
        root.querySelector('#wiz-clear-loc').addEventListener('click', function () {
          setLocation(null, 'sin_gps'); gpsStatus.textContent = 'Ubicación eliminada.';
        });

        speciesInput.addEventListener('input', function () {
          var found = Store.species().filter(function (s) { return U.normalize(s.common) === U.normalize(this.value); }.bind(this))[0];
          state.speciesId = found ? found.id : null;
          var hint = root.querySelector('#f-species-hint');
          if (found) hint.innerHTML = '<em>' + U.esc(found.sci) + '</em> · ' + U.esc(D.PROTECTION[found.prot].label) + '.';
          else hint.textContent = 'Si no logras identificarla, escribe «No identificada» y describe el animal.';
        });

        function addPhotos(files) {
          var remaining = 8 - state.photos.length;
          if (remaining <= 0) { UI.toast('Se alcanzó el límite de 8 evidencias.', 'warn'); return; }
          UI.readPhotos(Array.prototype.slice.call(files).slice(0, remaining)).then(function (ps) {
            state.photos = state.photos.concat(ps);
            drawPhotos();
          }).catch(function (e) { UI.toast(e.message, 'error'); });
        }
        function drawPhotos() {
          root.querySelector('#wiz-photos').innerHTML = state.photos.map(function (p, i) {
            return '<div class="photo-thumb" style="cursor:default"><img src="' + U.attr(p.dataUrl) + '" alt="Evidencia">' +
              '<button type="button" class="btn btn-sm" data-del-photo="' + i + '" style="position:absolute;top:3px;right:3px;padding:2px 6px;background:rgba(6,33,23,.75);color:#fff;border:0" aria-label="Eliminar">×</button>' +
              '<span class="pt-time">' + U.fmtDateTime(p.ts) + '</span></div>';
          }).join('');
        }
        root.querySelector('#wiz-camera').addEventListener('change', function () { addPhotos(this.files); this.value = ''; });
        root.querySelector('#wiz-files').addEventListener('change', function () { addPhotos(this.files); this.value = ''; });
        U.on(root, '[data-del-photo]', 'click', function () { state.photos.splice(Number(this.getAttribute('data-del-photo')), 1); drawPhotos(); });

        function readCriteria() {
          var c = {};
          D.CRITERIA.forEach(function (cr) {
            var el = form.querySelector('input[name="crit_' + cr.key + '"]:checked');
            c[cr.key] = el ? Number(el.value) : null;
          });
          return c;
        }
        function updateTriage() {
          var c = readCriteria();
          var selected = D.CRITERIA.filter(function (cr) { return c[cr.key] !== null && c[cr.key] !== undefined; }).length;
          if (selected < 4) {
            triageBox.innerHTML = '<div class="hint" style="text-transform:uppercase;letter-spacing:.08em;font-weight:800;font-size:.66rem">Resultado del triaje</div>' +
              '<div style="font-size:1.1rem;font-weight:800;margin:.4rem 0">' + selected + ' de 4 criterios</div>' +
              '<p class="hint">Completa la evaluación para calcular automáticamente la prioridad de atención.</p>' +
              '<div class="triage-scale">' + D.CRITERIA.map(function (cr) {
                return '<div class="ts-row"><span style="width:78px">' + U.esc(cr.short) + '</span><span class="ts-bar"><i style="width:' + ((c[cr.key] || 0) / 2 * 100) + '%;background:' + ((c[cr.key] || 0) === 2 ? '#c0392b' : (c[cr.key] === 1 ? '#d99a18' : '#2a9169')) + '"></i></span>' +
                  '<span style="width:12px;text-align:right">' + (c[cr.key] === null || c[cr.key] === undefined ? '—' : c[cr.key]) + '</span></div>';
              }).join('') + '</div>';
            return;
          }
          var t = D.triage(c);
          triageBox.innerHTML = '<div class="hint" style="text-transform:uppercase;letter-spacing:.08em;font-weight:800;font-size:.66rem">Resultado del triaje</div>' +
            '<div class="tb-score" style="margin-top:.6rem">' + scoreRing(t) +
            '<div><div class="triage-level" style="color:' + t.color + '">' + t.name + '</div>' +
            '<div class="triage-reason">' + U.esc(t.reason) + '</div></div></div>' +
            '<div class="triage-scale" style="margin-top:.9rem">' + D.CRITERIA.map(function (cr) {
              var pts = c[cr.key];
              return '<div class="ts-row"><span style="width:78px">' + U.esc(cr.short) + '</span><span class="ts-bar"><i style="width:' + (pts / 2 * 100) + '%;background:' + (pts === 2 ? '#c0392b' : pts === 1 ? '#d99a18' : '#2a9169') + '"></i></span>' +
                '<span style="width:12px;text-align:right">' + pts + '</span></div>';
            }).join('') + '</div>' +
            (t.alert ? '<div class="alert-banner ab-red" style="margin:.8rem 0 0;font-size:.72rem">' + U.icon('alert') + '<span>Se generará una <strong>alerta de atención inmediata</strong> al Médico Veterinario.</span></div>' : '');
        }
        form.addEventListener('change', function (ev) {
          if (ev.target.name && ev.target.name.indexOf('crit_') === 0) updateTriage();
        });

        function go(step) {
          state.step = U.clamp(step, 0, 4);
          panels.forEach(function (p, i) { p.classList.toggle('is-hidden', i !== state.step); });
          stepBtns.forEach(function (b, i) {
            b.classList.toggle('active', i === state.step);
            b.classList.toggle('done', i < state.step);
          });
          btnPrev.classList.toggle('is-hidden', state.step === 0);
          btnNext.classList.toggle('is-hidden', state.step === 4);
          btnSave.classList.toggle('is-hidden', state.step !== 4);
          if (state.step === 4) drawReview();
          if (state.step === 3) updateTriage();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        function showErr(key, show) {
          var el = root.querySelector('[data-err="' + key + '"]');
          if (el) el.classList.toggle('show', !!show);
        }
        function validateStep(step) {
          var ok = true;
          if (step === 0) {
            var sp = speciesInput.value.trim();
            var desc = root.querySelector('#f-desc').value.trim();
            showErr('species', !sp); speciesInput.classList.toggle('is-invalid', !sp); if (!sp) ok = false;
            showErr('description', desc.length < 10); root.querySelector('#f-desc').classList.toggle('is-invalid', desc.length < 10); if (desc.length < 10) ok = false;
          }
          if (step === 3) {
            var c = readCriteria();
            var all = D.CRITERIA.every(function (cr) { return c[cr.key] !== null && c[cr.key] !== undefined; });
            showErr('criteria', !all); if (!all) ok = false;
          }
          return ok;
        }
        function drawReview() {
          var c = readCriteria();
          var t = D.triage(c);
          var spName = speciesInput.value.trim() || 'No identificada';
          var type = root.querySelector('#f-type').value;
          var conditions = U.$$('input[name="conditions"]:checked', form).map(function (x) { return x.value; });
          var loc = state.location;
          root.querySelector('#wiz-review').innerHTML =
            '<div class="grid grid-2" style="gap:1rem">' +
            '<div><div class="meta-item"><div class="mi-label">Especie</div><div class="mi-value">' + U.esc(spName) + (state.speciesId ? ' <span class="hint">(catálogo)</span>' : '') + '</div></div>' +
            '<div class="meta-item"><div class="mi-label">Tipo de intervención</div><div class="mi-value">' + U.esc((D.INTERVENTION_TYPES.filter(function (x) { return x.key === type; })[0] || {}).label) + '</div></div>' +
            '<div class="meta-item"><div class="mi-label">Fecha y hora</div><div class="mi-value">' + U.fmtDateTime(root.querySelector('#f-when').value ? new Date(root.querySelector('#f-when').value).toISOString() : U.nowISO()) + '</div></div>' +
            '<div class="meta-item"><div class="mi-label">Identificación preliminar</div><div class="mi-value">' + U.esc(root.querySelector('#f-prelim').value || 'No determinada') + '</div></div>' +
            '<div class="meta-item"><div class="mi-label">Ubicación</div><div class="mi-value">' + (loc ? (loc.lat + ', ' + loc.lng) + ' <span class="hint">(' + (state.source === 'gps' ? 'GPS' : 'mapa') + ')</span>' : '<span class="text-amber">Sin coordenadas — se registrará con referencia</span>') + '</div></div>' +
            '<div class="meta-item"><div class="mi-label">Evidencias</div><div class="mi-value">' + state.photos.length + ' fotografía(s)</div></div></div>' +
            '<div><div class="lbl" style="margin-bottom:.35rem">Condiciones registradas</div><div class="pill-row">' + (conditions.length ? conditions.map(function (x) { return '<span class="chip">' + U.esc(x) + '</span>'; }).join('') : '<span class="hint">Sin condiciones marcadas.</span>') + '</div>' +
            '<div class="divider"></div><div class="triage-box" style="position:static">' +
            '<div style="display:flex;gap:.8rem;align-items:center">' + scoreRing(t, 66) + '<div><div class="triage-level" style="color:' + t.color + '">' + t.name + '</div><div class="triage-reason">' + U.esc(t.reason) + '</div></div></div></div></div></div>' +
            '<div class="alert-banner ab-blue" style="margin:1rem 0 0">' + U.icon('file') + '<span>Al guardar se generará un <strong>código único</strong> de intervención y la <strong>pre-acta digital</strong> con todos los datos, evidencias y el resultado del triaje.</span></div>';
        }

        btnNext.addEventListener('click', function () { if (validateStep(state.step)) go(state.step + 1); else UI.toast('Complete los campos obligatorios del paso actual.', 'error'); });
        btnPrev.addEventListener('click', function () { go(state.step - 1); });
        U.on(root, '[data-step-btn]', 'click', function () {
          var target = Number(this.getAttribute('data-step-btn'));
          if (target <= state.step) go(target);
          else { for (var s = 0; s < target; s++) { if (!validateStep(s)) { go(s); UI.toast('Complete los campos obligatorios antes de avanzar.', 'error'); return; } } go(target); }
        });

        form.addEventListener('submit', function (ev) {
          ev.preventDefault();
          if (!validateStep(0) || !validateStep(3)) { UI.toast('Revise los datos del animal y el triaje antes de guardar.', 'error'); return; }
          var c = readCriteria();
          var conditions = U.$$('input[name="conditions"]:checked', form).map(function (x) { return x.value; });
          var payload = {
            speciesId: state.speciesId,
            speciesName: speciesInput.value.trim(),
            preliminaryId: root.querySelector('#f-prelim').value.trim() || 'No determinada',
            type: root.querySelector('#f-type').value,
            occurredAt: root.querySelector('#f-when').value ? new Date(root.querySelector('#f-when').value).toISOString() : U.nowISO(),
            description: root.querySelector('#f-desc').value.trim(),
            conditions: conditions,
            criteria: c,
            photos: state.photos,
            location: state.location ? {
              lat: state.location.lat, lng: state.location.lng,
              accuracy: state.source === 'gps' ? 10 : null, source: state.source,
              reference: root.querySelector('#f-ref').value.trim() || 'Referencia no especificada',
              zone: (D.nearestZone(state.location.lat, state.location.lng) || {}).zone ? D.nearestZone(state.location.lat, state.location.lng).zone.name : ''
            } : {
              lat: null, lng: null, accuracy: null, source: 'sin_gps',
              reference: root.querySelector('#f-ref').value.trim() || 'Sin referencia', zone: ''
            }
          };
          function save() {
            try {
              var intv = Store.createIntervention(payload, user());
              UI.toast('Intervención ' + intv.code + ' registrada. Pre-acta generada.', 'success');
              location.hash = '#/app/rescates/' + intv.id + '/preacta';
            } catch (err) {
              UI.toast(err.message, 'error');
            }
          }
          if (!state.location) {
            UI.confirm({
              title: 'Registro sin coordenadas GPS',
              message: 'No se obtuvo la ubicación GPS de la intervención. Según el procedimiento, puedes continuar utilizando la referencia del lugar. ¿Deseas guardar de todos modos?',
              confirmLabel: 'Guardar sin GPS'
            }).then(function (ok) { if (ok) save(); });
          } else save();
        });

        go(0);
        updateTriage();
      }
    };
  }

  /* ==================================================================
     DETALLE DE LA INTERVENCIÓN
     ================================================================== */
  function detalle(params) {
    var intv = Store.intervention(params.id);
    if (!intv) return { html: notFound('La intervención solicitada no existe en el sistema.'), mount: function () {} };
    var u = user();
    var canEdit = Store.can(u.role, 'rescates.edit');
    var canClinical = Store.can(u.role, 'clinical.view');
    var canDecide = Store.can(u.role, 'decisions.register');
    var sum = Store.clinicalSummary(intv.id);
    var decision = Store.decisionFor(intv.id);
    var markers = [];
    if (hasGeo(intv)) {
      markers.push({ id: intv.id, lat: intv.location.lat, lng: intv.location.lng, color: D.normalizePriority(intv.priority).color, title: intv.code, subtitle: intv.speciesName });
    }
    var h = '<div class="page-head"><div class="ph-text"><a href="#/app/rescates" class="btn btn-ghost btn-sm" style="margin-bottom:.4rem">' + U.icon('arrowLeft') + 'Volver a rescates</a>' +
      '<h1>' + U.esc(intv.speciesName) + '</h1>' +
      '<div class="dh-sub"><span class="code-pill">' + U.esc(intv.code) + '</span>' + UI.statusBadge(intv.status) + UI.priorityBadge(intv.priority.level) +
      '<span class="hint">' + U.icon('calendar') + ' ' + U.fmtDateTime(intv.occurredAt) + '</span></div></div>' +
      '<div class="ph-actions">' +
      '<a class="btn btn-primary" href="#/app/rescates/' + intv.id + '/preacta">' + U.icon('file') + 'Pre-acta digital</a>' +
      (canEdit ? '<a class="btn btn-secondary" href="#/app/rescates/' + intv.id + '/editar">' + U.icon('edit') + 'Editar datos</a>' : '') +
      (canClinical ? '<a class="btn btn-secondary" href="#/app/clinica/' + intv.id + '">' + U.icon('stethoscope') + 'Historia clínica</a>' : '') +
      '</div></div>';

    h += '<div class="split"><div>' +
      '<div class="card section"><div class="card-head"><h3>Datos de la intervención</h3></div><div class="card-body">' +
      '<div class="meta-grid">' +
      UI.infoRow('Tipo', U.esc((D.INTERVENTION_TYPES.filter(function (x) { return x.key === intv.type; })[0] || {}).label || intv.type)) +
      UI.infoRow('Fecha de registro', U.fmtDateTime(intv.createdAt)) +
      UI.infoRow('Agente responsable', U.esc(intv.agentName)) +
      UI.infoRow('Identificación preliminar', U.esc(intv.preliminaryId)) +
      UI.infoRow('Nombre científico', '<em>' + U.esc(intv.scientificName || '—') + '</em>') +
      UI.infoRow('Zona', U.esc((intv.location && intv.location.zone) || 'Sin zona')) +
      '</div><div class="divider"></div>' +
      '<div class="fs-75"><strong>Descripción</strong><p style="margin:.35rem 0 0;color:var(--ink-soft)">' + U.esc(intv.description) + '</p></div>' +
      '<div class="divider"></div><div class="fs-75"><strong>Condiciones del hallazgo</strong><div class="pill-row" style="margin-top:.4rem">' +
      (intv.conditions.length ? intv.conditions.map(function (c) { return '<span class="chip">' + U.esc(c) + '</span>'; }).join('') : '<span class="hint">No se registraron condiciones.</span>') + '</div></div>' +
      '</div></div>' +

      '<div class="card section"><div class="card-head"><h3>' + U.icon('activity') + ' Evaluación de triaje</h3><div class="ch-actions">' + UI.badge('RD011', 'outline') + '</div></div><div class="card-body">' +
      '<div style="display:flex;gap:1rem;align-items:center;flex-wrap:wrap">' + scoreRing(intv.priority) +
      '<div style="flex:1;min-width:180px"><div class="triage-level" style="color:' + D.normalizePriority(intv.priority).color + '">' + U.esc(intv.priority.name || D.normalizePriority(intv.priority).name) + '</div>' +
      '<div class="triage-reason">' + U.esc(intv.priority.reason || '') + '</div>' +
      '<div class="hint" style="margin-top:.3rem">Evaluado el ' + U.fmtDateTime(intv.priority.evaluatedAt || intv.createdAt) + '</div></div></div>' +
      '<div class="divider"></div>' + criteriaRows(intv.priority) +
      (intv.priority.level === 'I' ? '<div class="alert-banner ab-red" style="margin:.9rem 0 0">' + U.icon('alert') + '<span>Prioridad I: se generó una alerta de atención inmediata al Médico Veterinario. El orden de atención clínica está determinado por esta clasificación.</span></div>' : '') +
      '</div></div>' +

      '<div class="card section"><div class="card-head"><h3>' + U.icon('pin') + ' Ubicación georreferenciada</h3></div><div class="card-body">' +
      (hasGeo(intv) ?
        '<div id="detail-map"></div><div class="meta-grid" style="margin-top:.8rem">' + UI.infoRow('Latitud', intv.location.lat) + UI.infoRow('Longitud', intv.location.lng) +
        UI.infoRow('Precisión', intv.location.accuracy ? '±' + intv.location.accuracy + ' m' : '—') + UI.infoRow('Fuente', intv.location.source === 'gps' ? 'GPS del dispositivo' : intv.location.source === 'map' ? 'Selección en mapa' : 'No disponible') +
        '</div><p class="hint" style="margin:.5rem 0 0">' + U.icon('pin') + ' ' + U.esc(intv.location.reference || 'Sin referencia') + '</p>' :
        '<div class="alert-banner ab-amber" style="margin:0">' + U.icon('alert') + '<span><strong>Sin coordenadas GPS.</strong> El registro se conserva con la referencia: ' + U.esc((intv.location && intv.location.reference) || 'no especificada') + '.</span></div>') +
      '</div></div>' +

      '<div class="card section"><div class="card-head"><h3>' + U.icon('camera') + ' Evidencias fotográficas</h3><span class="hint" style="margin-left:auto">' + intv.photos.length + ' archivo(s)</span></div><div class="card-body">' +
      UI.photoGrid(intv.photos) + '</div></div>' +

      '<div class="card section"><div class="card-head"><h3>' + U.icon('clock') + ' Historial y trazabilidad</h3><div class="ch-actions">' + UI.badge('RNF006', 'outline') + '</div></div><div class="card-body">' +
      '<div class="timeline">' + intv.history.slice().reverse().map(function (ev) {
        return '<div class="tl-item ' + (ev.action.indexOf('Decisión') >= 0 ? 'tl-red' : ev.action.indexOf('actualiz') >= 0 ? 'tl-gray' : '') + '">' +
          '<div class="tl-head"><span class="tl-title">' + U.esc(ev.action) + '</span><span class="tl-time">' + U.fmtDateTime(ev.ts) + '</span></div>' +
          '<div class="tl-body">' + U.esc(ev.detail || '') + '</div><div class="tl-changes">' + U.esc(ev.userName) + '</div></div>';
      }).join('') + '</div></div></div>' +
      '</div>' +

      '<aside style="display:flex;flex-direction:column;gap:1rem">' +
      '<div class="card"><div class="card-head"><h3>' + U.icon('stethoscope') + ' Estado clínico</h3></div><div class="card-body">' +
      '<div class="kpi-row" style="grid-template-columns:1fr 1fr">' +
      '<div class="kpi-mini"><div class="km-val">' + sum.count + '</div><div class="km-lbl">Registros clínicos</div></div>' +
      '<div class="kpi-mini"><div class="km-val">' + (sum.hasDischarge ? 'Sí' : 'No') + '</div><div class="km-lbl">Alta médica</div></div></div>' +
      (sum.lastControl ? '<p class="hint" style="margin:.7rem 0 0"><strong>Último control:</strong> ' + U.fmtDateTime(sum.lastControl.ts) + ' · ' + U.esc(sum.lastControl.vetName) + '</p>' : '<p class="hint" style="margin:.7rem 0 0">Aún no se registran controles clínicos.</p>') +
      '<div class="divider"></div>' +
      (canClinical ? '<a class="btn btn-soft btn-block" href="#/app/clinica/' + intv.id + '">' + U.icon('stethoscope') + 'Abrir historia clínica</a>' : '<p class="hint" style="margin:0">La información clínica solo está disponible para los perfiles autorizados.</p>') +
      '</div></div>' +

      '<div class="card"><div class="card-head"><h3>' + U.icon('scale') + ' Decisión técnica</h3></div><div class="card-body">' +
      (decision ? decisionSummary(decision) :
        (canDecide ? '<p class="hint" style="margin-bottom:.7rem">Evalúa la aptitud del animal para liberación, custodia permanente o eutanasia. La liberación requiere alta médica y comportamiento apto.</p>' +
          '<button class="btn btn-primary btn-block" data-open-decision="' + intv.id + '">' + U.icon('scale') + 'Registrar decisión</button>' :
          '<p class="hint" style="margin:0">El destino final del animal será registrado por el Médico Veterinario responsable.</p>')) +
      '</div></div>' +

      '<div class="card"><div class="card-head"><h3>' + U.icon('file') + ' Documento digital</h3></div><div class="card-body">' +
      '<p class="hint" style="margin:0 0 .6rem">Pre-acta generada el ' + U.fmtDateTime(intv.preacta && intv.preacta.generatedAt || intv.createdAt) + '. Conserva los datos, evidencias y la identificación del agente responsable.</p>' +
      '<a class="btn btn-secondary btn-block" href="#/app/rescates/' + intv.id + '/preacta">' + U.icon('print') + 'Ver e imprimir pre-acta</a></div></div>' +
      '</aside></div>';

    return {
      html: h,
      mount: function (root) {
        Store.log({ id: u.id, name: u.name, role: u.role }, 'Consulta de intervención', 'intervencion', intv.id, 'Acceso a la ficha ' + intv.code + '.', true);
        if (markers.length) {
          var holder = root.querySelector('#detail-map');
          if (holder) MapView.create(holder, { markers: markers, showZones: false, legend: false, zoom: true, selectedId: intv.id });
        }
        U.on(root, '[data-photo]', 'click', function () { UI.lightbox(this.getAttribute('data-photo'), this.getAttribute('data-caption')); });
        U.on(root, '[data-open-decision]', 'click', function () {
          if (S.Views.clinical.openDecisionModal) S.Views.clinical.openDecisionModal(this.getAttribute('data-open-decision'), function () { S.App.refresh(); });
        });
      }
    };
  }

  function decisionSummary(dec) {
    var labels = { liberacion: 'Liberación', custodia: 'Custodia permanente', eutanasia: 'Eutanasia' };
    var tone = { liberacion: 'green', custodia: 'purple', eutanasia: 'gray' };
    return '<div class="pill-row">' + UI.badge(labels[dec.type], tone[dec.type]) + '</div>' +
      '<p class="hint" style="margin:.6rem 0 .3rem"><strong>' + U.fmtDateTime(dec.ts) + '</strong> · ' + U.esc(dec.vetName) + '</p>' +
      '<p style="font-size:.78rem;color:var(--ink-soft);margin:.2rem 0">' + U.esc(dec.justification) + '</p>' +
      (dec.destination ? '<p class="hint">Destino: ' + U.esc(dec.destination) + '</p>' : '') +
      (dec.releasePlace ? '<p class="hint">Lugar de liberación: ' + U.esc(dec.releasePlace) + '</p>' : '') +
      (dec.monitoring && dec.monitoring.length ? '<div class="divider"></div><div class="hint"><strong>' + dec.monitoring.length + ' monitoreo(s) post-liberación</strong></div>' : '');
  }

  /* ==================================================================
     EDICIÓN CON HISTORIAL (PG-17)
     ================================================================== */
  function editar(params) {
    var intv = Store.intervention(params.id);
    if (!intv) return { html: notFound('La intervención no existe.'), mount: function () {} };
    var h = '<div class="page-head"><div class="ph-text"><a href="#/app/rescates/' + intv.id + '" class="btn btn-ghost btn-sm" style="margin-bottom:.4rem">' + U.icon('arrowLeft') + 'Volver a la ficha</a>' +
      '<h1>Editar datos del animal</h1><div class="sub">' + U.esc(intv.code) + ' · las modificaciones quedan registradas en el historial</div></div></div>' +
      '<div class="card card-pad" style="max-width:820px"><form id="edit-form">' +
      '<div class="form-grid">' +
      '<div class="field span-2"><label for="e-species">Especie</label><input class="input" id="e-species" name="speciesName" list="edit-species" value="' + U.attr(intv.speciesName) + '">' +
      '<datalist id="edit-species">' + Store.species().map(function (s) { return '<option value="' + U.attr(s.common) + '"></option>'; }).join('') + '</datalist></div>' +
      '<div class="field"><label for="e-prelim">Identificación preliminar</label><input class="input" id="e-prelim" name="preliminaryId" value="' + U.attr(intv.preliminaryId) + '"></div>' +
      '<div class="field"><label for="e-when">Fecha y hora</label><input class="input" id="e-when" name="occurredAt" type="datetime-local" value="' + U.attr(U.toLocalInput(intv.occurredAt)) + '"></div>' +
      '<div class="field span-2"><label for="e-desc">Descripción</label><textarea class="textarea" id="e-desc" name="description">' + U.esc(intv.description) + '</textarea></div>' +
      '<div class="field span-2"><label for="e-ref">Referencia de ubicación</label><input class="input" id="e-ref" name="reference" value="' + U.attr((intv.location && intv.location.reference) || '') + '"></div>' +
      '<div class="field span-2"><label>Condiciones</label><div class="check-grid">' + D.CONDITIONS.map(function (c) {
        return '<label class="check"><input type="checkbox" name="conditions" value="' + U.attr(c) + '"' + (intv.conditions.indexOf(c) >= 0 ? ' checked' : '') + '>' + U.esc(c) + '</label>';
      }).join('') + '</div></div>' +
      '<div class="field span-2"><label for="e-note">Motivo de la modificación</label><input class="input" id="e-note" maxlength="160" placeholder="Ej. Se corrige la identificación preliminar tras evaluación"></div>' +
      '</div>' +
      '<div class="form-actions"><a class="btn btn-secondary" href="#/app/rescates/' + intv.id + '">Cancelar</a>' +
      '<button class="btn btn-primary" type="submit">' + U.icon('save') + 'Guardar cambios</button></div>' +
      '</form></div>';
    return {
      html: h,
      mount: function (root) {
        root.querySelector('#edit-form').addEventListener('submit', function (ev) {
          ev.preventDefault();
          var name = root.querySelector('#e-species').value.trim();
          var found = Store.species().filter(function (s) { return U.normalize(s.common) === U.normalize(name); })[0];
          var ref = root.querySelector('#e-ref').value.trim();
          try {
            Store.updateIntervention(intv.id, {
              speciesId: found ? found.id : null,
              speciesName: name,
              scientificName: found ? found.sci : intv.scientificName,
              preliminaryId: root.querySelector('#e-prelim').value.trim(),
              description: root.querySelector('#e-desc').value.trim(),
              occurredAt: new Date(root.querySelector('#e-when').value).toISOString(),
              conditions: U.$$('input[name="conditions"]:checked', root).map(function (x) { return x.value; }),
              location: Object.assign({}, intv.location, { reference: ref })
            }, user(), root.querySelector('#e-note').value.trim());
            UI.toast('Datos actualizados. La versión anterior quedó registrada en el historial.', 'success');
            location.hash = '#/app/rescates/' + intv.id;
          } catch (err) { UI.toast(err.message, 'error'); }
        });
      }
    };
  }

  /* ==================================================================
     PRE-ACTA DIGITAL (RF005)
     ================================================================== */
  function preacta(params) {
    var intv = Store.intervention(params.id);
    if (!intv) return { html: notFound('La intervención no existe.'), mount: function () {} };
    var pri = D.normalizePriority(intv.priority);
    var h = '<div class="page-head no-print"><div class="ph-text"><a href="#/app/rescates/' + intv.id + '" class="btn btn-ghost btn-sm" style="margin-bottom:.4rem">' + U.icon('arrowLeft') + 'Volver a la ficha</a>' +
      '<h1>Pre-acta digital de intervención</h1><div class="sub">Documento generado automáticamente · ' + U.esc(intv.code) + '</div></div>' +
      '<div class="ph-actions"><button class="btn btn-primary" id="pa-print">' + U.icon('print') + 'Imprimir / Guardar PDF</button>' +
      '<button class="btn btn-secondary" id="pa-download">' + U.icon('download') + 'Descargar documento</button></div></div>' +
      '<div class="preacta" id="preacta-doc">' +
      '<div class="pa-head"><div><div class="pa-org">Servicio Nacional Forestal y de Fauna Silvestre · SERFOR</div>' +
      '<div class="pa-org" style="font-weight:600;letter-spacing:.04em">Administración Técnica Forestal y de Fauna Silvestre — Sierra Central · Sede Huancayo</div>' +
      '<h2>PRE-ACTA DIGITAL DE INTERVENCIÓN DE FAUNA SILVESTRE</h2>' +
      '<div style="font-size:.7rem;color:#5f7068">Documento generado por el Sistema de Información y Trazabilidad de Fauna Silvestre (SIFAS)</div></div>' +
      '<div class="pa-code">CÓDIGO ÚNICO<strong>' + U.esc(intv.code) + '</strong>Generado: ' + U.fmtDateTime(intv.preacta && intv.preacta.generatedAt || intv.createdAt) + '<br>Versión ' + (intv.preacta && intv.preacta.version || 1) + '</div></div>' +

      '<h3>I. Datos de la intervención</h3><dl>' +
      '<dt>Tipo de intervención</dt><dd>' + U.esc((D.INTERVENTION_TYPES.filter(function (x) { return x.key === intv.type; })[0] || {}).label || intv.type) + '</dd>' +
      '<dt>Fecha y hora</dt><dd>' + U.fmtDateLong(intv.occurredAt) + ' — ' + U.fmtTime(intv.occurredAt) + '</dd>' +
      '<dt>Agente responsable</dt><dd>' + U.esc(intv.agentName) + '</dd>' +
      '<dt>Registro creado</dt><dd>' + U.fmtDateTime(intv.createdAt) + '</dd>' +
      '</dl>' +

      '<h3>II. Identificación del animal</h3><dl>' +
      '<dt>Especie</dt><dd>' + U.esc(intv.speciesName) + '</dd>' +
      '<dt>Nombre científico</dt><dd><em>' + U.esc(intv.scientificName || 'No determinada') + '</em></dd>' +
      '<dt>Identificación preliminar</dt><dd>' + U.esc(intv.preliminaryId) + '</dd>' +
      '<dt>Condiciones del hallazgo</dt><dd>' + (intv.conditions.length ? U.esc(intv.conditions.join(', ')) : 'Sin condiciones registradas') + '</dd>' +
      '</dl>' +

      '<h3>III. Descripción de la intervención</h3>' +
      '<p style="font-size:.78rem;line-height:1.55;margin:0 0 .4rem">' + U.esc(intv.description) + '</p>' +

      '<h3>IV. Ubicación georreferenciada</h3><dl>' +
      '<dt>Coordenadas</dt><dd>' + (hasGeo(intv) ? intv.location.lat + ', ' + intv.location.lng + ' (±' + (intv.location.accuracy || '—') + ' m)' : 'No registradas') + '</dd>' +
      '<dt>Zona</dt><dd>' + U.esc((intv.location && intv.location.zone) || 'No determinada') + '</dd>' +
      '<dt>Referencia</dt><dd>' + U.esc((intv.location && intv.location.reference) || 'No especificada') + '</dd>' +
      '<dt>Fuente</dt><dd>' + (intv.location && intv.location.source === 'gps' ? 'GPS del dispositivo' : intv.location && intv.location.source === 'map' ? 'Selección manual en mapa' : 'No disponible') + '</dd>' +
      '</dl>' +

      '<h3>V. Triaje inicial (RD011)</h3><dl>' +
      '<dt>Puntaje total</dt><dd><strong>' + U.num(intv.priority.score) + ' / 8</strong></dd>' +
      '<dt>Categoría asignada</dt><dd><strong style="color:' + pri.color + '">' + U.esc(pri.name) + ' — ' + U.esc(pri.tag) + '</strong></dd>' +
      '<dt>Regla aplicada</dt><dd>' + U.esc(intv.priority.reason || '') + '</dd>' +
      '<dt>Criterios</dt><dd>' + D.CRITERIA.map(function (c) {
        var pts = U.num(intv.priority.criteria && intv.priority.criteria[c.key]);
        var opt = c.options[pts] || c.options[0];
        return U.esc(c.label) + ': ' + pts + ' pt (' + U.esc(opt.label) + ')';
      }).join(' · ') + '</dd></dl>' +

      '<h3>VI. Evidencias fotográficas</h3>' +
      (intv.photos.length ? '<div class="pa-photos">' + intv.photos.map(function (p) {
        return '<img src="' + U.attr(p.dataUrl) + '" alt="Evidencia">';
      }).join('') + '</div><div class="pa-note">Se registraron ' + intv.photos.length + ' evidencia(s). Cada archivo conserva fecha y hora de captura.</div>' :
        '<p style="font-size:.75rem;color:#5f7068;margin:0">No se adjuntaron evidencias fotográficas.</p>') +

      '<h3>VII. Datos del registro</h3><dl>' +
      '<dt>Estado actual</dt><dd>' + U.esc(D.STATUS[intv.status].label) + '</dd>' +
      '<dt>Registros clínicos</dt><dd>' + Store.clinicalSummary(intv.id).count + '</dd>' +
      '<dt>Última actualización</dt><dd>' + U.fmtDateTime(intv.updatedAt) + '</dd>' +
      '</dl>' +

      '<div class="pa-sign"><div>Firma del Agente de Campo<br><strong>' + U.esc(intv.agentName) + '</strong></div>' +
      '<div>Revisión y validación<br>ATFFS Sierra Central — SERFOR Huancayo</div></div>' +
      '<div class="pa-note">Documento generado electrónicamente por SIFAS a partir de la información registrada en el lugar de los hechos. Conserva los datos, la ubicación, las evidencias y la identificación del agente responsable para su revisión y validación posterior. Código único de intervención: ' + U.esc(intv.code) + ' · Ley N.° 29763 — Ley Forestal y de Fauna Silvestre.</div>' +
      '</div>';

    return {
      html: h,
      mount: function (root) {
        root.querySelector('#pa-print').addEventListener('click', function () { window.print(); });
        root.querySelector('#pa-download').addEventListener('click', function () {
          var content = root.querySelector('#preacta-doc').outerHTML;
          var doc = '<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>' + U.esc(intv.code) + ' · Pre-acta</title>' +
            '<link rel="stylesheet" href="css/styles.css"></head><body style="padding:2rem;background:#fff">' + content + '</body></html>';
          U.download('preacta-' + intv.code + '.html', doc, 'text/html;charset=utf-8');
          U.download('preacta-' + intv.code + '.csv', U.toCSV([intv], [
            { key: 'code', label: 'Código' }, { key: 'speciesName', label: 'Especie' },
            { key: 'occurredAt', label: 'Fecha' }, { key: 'agentName', label: 'Agente' },
            { key: 'description', label: 'Descripción' }
          ]), 'text/csv;charset=utf-8');
          UI.toast('Documento descargado. Puede imprimirlo o guardarlo como PDF desde el navegador.', 'success');
        });
      }
    };
  }

  function notFound(message) {
    return '<div class="page"><div class="card card-pad" style="max-width:600px;margin:2rem auto">' +
      UI.empty('search', 'Registro no encontrado', message, '<a class="btn btn-primary" href="#/app/rescates">Volver a rescates</a>') + '</div></div>';
  }

  Views.field = {
    dashboard: dashboard, rescates: rescates, nuevo: nuevo, detalle: detalle,
    editar: editar, preacta: preacta, scoreRing: scoreRing, criteriaRows: criteriaRows,
    notFound: notFound, notificationsList: notificationsList, lastMonthsSeries: lastMonthsSeries,
    countBy: countBy, statCard: statCard, decisionSummary: decisionSummary
  };
})(typeof window !== 'undefined' ? window : this);

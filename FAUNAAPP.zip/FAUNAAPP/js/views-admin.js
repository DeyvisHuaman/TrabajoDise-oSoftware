/* Módulos de administración: mapa, reportes, denuncias, usuarios, roles,
   auditoría, respaldo, catálogo de especies y trazabilidad de requisitos.
   RF001, RF009–RF015 · RD001–RD011 · RNF001–RNF007. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util, D = S.Domain, Store = S.Store, UI = S.UI, Auth = S.Auth, Charts = S.Charts, MapView = S.Map;
  var Views = S.Views = S.Views || {};

  function user() { return Auth.current(); }
  function linkBtn(href, icon, label, cls) {
    return '<a class="btn ' + (cls || 'btn-secondary') + '" href="' + href + '">' + U.icon(icon) + label + '</a>';
  }
  function pageHead(title, sub, actions) {
    return '<div class="page-head"><div class="ph-text"><h1>' + U.esc(title) + '</h1>' +
      '<div class="sub">' + sub + '</div></div><div class="ph-actions">' + (actions || '') + '</div></div>';
  }
  function stat(icon, label, value, foot, tone) {
    return Views.field.statCard(icon, label, value, foot, tone);
  }
  function downloadCSV(filename, rows, columns) {
    U.download(filename, U.toCSV(rows, columns), 'text/csv;charset=utf-8');
    UI.toast('Archivo CSV generado correctamente.', 'success', 'Exportación completada');
  }
  function typeLabel(key) {
    var t = D.DENUNCIA_TYPES.filter(function (x) { return x.key === key; })[0];
    return t ? t.label : key;
  }
  function statusMeta(key) { return D.DENUNCIA_STATUS[key] || { label: key, tone: 'gray' }; }
  function hasGeo(obj) {
    var loc = obj && obj.location;
    return !!(loc && loc.lat !== null && loc.lat !== undefined && loc.lng !== null && loc.lng !== undefined &&
      isFinite(loc.lat) && isFinite(loc.lng));
  }

  /* ==================================================================
     MAPA DE INTERVENCIONES (RF011 / RD009)
     ================================================================== */
  function mapa() {
    var all = Store.interventions();
    var denuncias = Store.denuncias();
    var state = { priority: '', status: '', type: '', q: '', showDen: true, selected: null };
    var mapApi = null;

    var h = pageHead('Mapa de intervenciones',
      'Zonas y carreteras de Huancayo con registros georreferenciados · RF011 / RD009',
      '<button class="btn btn-secondary" data-export-map>' + U.icon('download') + 'Exportar puntos</button>' +
      linkBtn('#/app/reportes', 'chart', 'Reportes', 'btn-primary'));

    h += '<div class="grid grid-4 section">' +
      stat('pin', 'Puntos georreferenciados', all.filter(hasGeo).length, 'Intervenciones con coordenadas GPS', '') +
      stat('alert', 'Prioridad I', all.filter(function (i) { return i.priority.level === 'I' && hasGeo(i); }).length, 'Casos críticos ubicados en el mapa', 'tone-red') +
      stat('map', 'Zonas con registros', U.unique(all.map(function (i) { return (i.location && i.location.zone) || ''; }).filter(Boolean)).length, 'Distritos y sectores identificados', 'tone-blue') +
      stat('alert', 'Denuncias ubicadas', denuncias.filter(hasGeo).length, 'Reportes ciudadanos con punto en el mapa', 'tone-purple') +
      '</div>';

    h += '<div class="card section"><div class="card-body">' +
      '<div class="toolbar">' +
      '<div class="search-box">' + U.icon('search') + '<input class="input" id="map-q" type="search" placeholder="Buscar código, especie o zona…" aria-label="Buscar en el mapa"></div>' +
      '<select class="select" id="map-pri" aria-label="Filtrar prioridad"><option value="">Toda prioridad</option><option value="I">Prioridad I</option><option value="II">Prioridad II</option><option value="III">Prioridad III</option></select>' +
      '<select class="select" id="map-status" aria-label="Filtrar estado"><option value="">Todo estado</option>' +
      Object.keys(D.STATUS).map(function (k) { return '<option value="' + k + '">' + D.STATUS[k].label + '</option>'; }).join('') + '</select>' +
      '<select class="select" id="map-type" aria-label="Filtrar tipo"><option value="">Todo tipo</option>' +
      D.INTERVENTION_TYPES.map(function (t) { return '<option value="' + t.key + '">' + t.label + '</option>'; }).join('') + '</select>' +
      '<label class="check" style="font-size:.75rem"><input type="checkbox" id="map-den" checked> Mostrar denuncias</label>' +
      '<span class="spacer"></span><span class="result-count" id="map-count"></span>' +
      '</div>' +
      '<div class="split" style="grid-template-columns:minmax(0,1.75fr) minmax(260px,.85fr);align-items:start">' +
      '<div><div id="map-holder"></div><div id="map-detail" class="mt-2"></div></div>' +
      '<aside><div class="map-side" id="map-side"></div>' +
      '<div class="card mt-2"><div class="card-head"><h3>Concentración por zona</h3></div><div class="card-body" id="map-zones" style="padding-top:.7rem"></div></div></aside>' +
      '</div></div></div>';

    function filtered() {
      var q = U.normalize(state.q);
      var ints = all.filter(function (i) {
        if (!hasGeo(i)) return false;
        var text = U.normalize(i.code + ' ' + i.speciesName + ' ' + (i.location.zone || '') + ' ' + (i.location.reference || ''));
        return (!q || text.indexOf(q) >= 0) && (!state.priority || i.priority.level === state.priority) &&
          (!state.status || i.status === state.status) && (!state.type || i.type === state.type);
      });
      var dens = state.showDen ? denuncias.filter(function (d) {
        if (!hasGeo(d)) return false;
        var text = U.normalize(d.code + ' ' + d.species + ' ' + (d.location.reference || ''));
        return !q || text.indexOf(q) >= 0;
      }) : [];
      return { ints: ints, dens: dens };
    }

    function markerForInt(i) {
      return {
        id: i.id, lat: i.location.lat, lng: i.location.lng, color: D.normalizePriority(i.priority).color,
        title: i.code, subtitle: i.speciesName + ' · ' + U.fmtDate(i.occurredAt)
      };
    }
    function markerForDen(d) {
      return {
        id: 'den:' + d.id, lat: d.location.lat, lng: d.location.lng, color: '#6f5bd0',
        title: d.code, subtitle: 'Denuncia · ' + typeLabel(d.type)
      };
    }

    function renderSide(data) {
      var side = document.getElementById('map-side');
      if (!side) return;
      var points = data.ints.map(function (i) {
        return {
          id: i.id, color: D.normalizePriority(i.priority).color, kind: 'int',
          title: i.speciesName, sub: i.code + ' · ' + (i.location.zone || 'Sin zona') + ' · ' + U.fmtDate(i.occurredAt)
        };
      }).concat(data.dens.map(function (d) {
        return {
          id: 'den:' + d.id, color: '#6f5bd0', kind: 'den',
          title: 'Denuncia · ' + typeLabel(d.type), sub: d.code + ' · ' + (d.location.reference || 'Sin referencia')
        };
      }));
      side.innerHTML = points.length ? points.map(function (p) {
        var sel = state.selected === p.id;
        return '<button type="button" class="map-point" data-select="' + U.attr(p.id) + '" style="' +
          (sel ? 'border-color:var(--green-500);background:var(--green-50)' : '') + '">' +
          '<span class="mp-dot" style="background:' + p.color + '"></span>' +
          '<span><span class="mp-title">' + U.esc(p.title) + '</span><span class="mp-sub">' + U.esc(p.sub) + '</span></span></button>';
      }).join('') : '<p class="hint" style="padding:.6rem">No hay puntos que coincidan con los filtros.</p>';
    }

    function renderDetail() {
      var box = document.getElementById('map-detail');
      if (!box) return;
      if (!state.selected) {
        box.innerHTML = '<div class="card card-pad"><div class="note">' + U.icon('info') +
          '<span>Selecciona un punto del mapa o de la lista para revisar la ficha asociada. Las burbujas indican la concentración de intervenciones por zona.</span></div></div>';
        return;
      }
      if (state.selected.indexOf('den:') === 0) {
        var den = Store.denuncia(state.selected.slice(4));
        if (!den) { box.innerHTML = ''; return; }
        var st = statusMeta(den.status);
        box.innerHTML = '<div class="card"><div class="card-head"><h3>' + U.icon('alert') + ' ' + U.esc(den.code) + '</h3>' +
          '<div class="ch-actions">' + UI.badge(st.label, st.tone) + '</div></div><div class="card-body">' +
          '<div class="meta-grid">' + UI.infoRow('Tipo', U.esc(typeLabel(den.type))) + UI.infoRow('Especie', U.esc(den.species)) +
          UI.infoRow('Fecha', U.fmtDateTime(den.ts)) + UI.infoRow('Referencia', U.esc((den.location && den.location.reference) || '—')) + '</div>' +
          '<div class="divider"></div><p class="fs-75" style="margin:0;color:var(--ink-soft)">' + U.esc(U.truncate(den.description, 260)) + '</p>' +
          '<div class="mt-2">' + linkBtn('#/app/denuncias', 'arrowRight', 'Revisar denuncia', 'btn-soft') + '</div></div></div>';
        return;
      }
      var intv = Store.intervention(state.selected);
      if (!intv) { box.innerHTML = ''; return; }
      box.innerHTML = '<div class="card"><div class="card-head"><h3>' + U.icon('paw') + ' ' + U.esc(intv.speciesName) + '</h3>' +
        '<div class="ch-actions">' + UI.priorityBadge(intv.priority.level) + UI.statusBadge(intv.status) + '</div></div><div class="card-body">' +
        '<div class="meta-grid">' + UI.infoRow('Código', '<span class="mono">' + U.esc(intv.code) + '</span>') +
        UI.infoRow('Zona', U.esc((intv.location && intv.location.zone) || '—')) +
        UI.infoRow('Coordenadas', hasGeo(intv) ? intv.location.lat + ', ' + intv.location.lng : '-') +
        UI.infoRow('Fecha', U.fmtDate(intv.occurredAt)) +
        UI.infoRow('Agente', U.esc(intv.agentName)) + UI.infoRow('Tipo', U.esc((D.INTERVENTION_TYPES.filter(function (t) { return t.key === intv.type; })[0] || {}).label || intv.type)) + '</div>' +
        '<div class="mt-2" style="display:flex;gap:.4rem;flex-wrap:wrap">' + linkBtn('#/app/rescates/' + intv.id, 'file', 'Abrir ficha', 'btn-soft') +
        linkBtn('#/app/clinica/' + intv.id, 'stethoscope', 'Historia clínica', 'btn-secondary') + '</div></div></div>';
    }

    function renderZones(data) {
      var holder = document.getElementById('map-zones');
      if (!holder) return;
      var counts = {};
      data.ints.forEach(function (i) {
        var near = D.nearestZone(i.location.lat, i.location.lng);
        var key = near ? near.zone.name : 'Sin zona';
        counts[key] = (counts[key] || 0) + 1;
      });
      var rows = Object.keys(counts).map(function (k) { return { label: k, value: counts[k] }; })
        .sort(function (a, b) { return b.value - a.value; }).slice(0, 8);
      holder.innerHTML = Charts.barList(rows, { color: '#b7791f' });
    }

    function update() {
      var data = filtered();
      var markers = data.ints.map(markerForInt).concat(data.dens.map(markerForDen));
      if (state.selected && !markers.some(function (m) { return m.id === state.selected; })) state.selected = null;
      if (mapApi) mapApi.update({ markers: markers, selectedId: state.selected });
      renderSide(data);
      renderDetail();
      renderZones(data);
      var count = document.getElementById('map-count');
      if (count) count.textContent = data.ints.length + ' intervenciones · ' + data.dens.length + ' denuncias';
    }

    return {
      html: h,
      mount: function (root) {
        Store.log(user(), 'Consulta de mapa de intervenciones', 'reporte', 'mapa', 'Visualización geográfica de intervenciones y denuncias.', false);
        var holder = root.querySelector('#map-holder');
        var initial = filtered();
        mapApi = MapView.create(holder, {
          markers: initial.ints.map(markerForInt).concat(initial.dens.map(markerForDen)),
          showZones: true, legend: true,
          onSelect: function (id) {
            state.selected = id;
            if (mapApi) mapApi.update({ selectedId: id });
            renderSide(filtered());
            renderDetail();
          }
        });
        function bind(id, event, handler) {
          var el = root.querySelector(id);
          if (el) el.addEventListener(event, handler);
        }
        bind('#map-q', 'input', U.debounce(function () { state.q = this.value; update(); }, 140));
        bind('#map-pri', 'change', function () { state.priority = this.value; update(); });
        bind('#map-status', 'change', function () { state.status = this.value; update(); });
        bind('#map-type', 'change', function () { state.type = this.value; update(); });
        bind('#map-den', 'change', function () { state.showDen = this.checked; update(); });
        U.on(root, '[data-select]', 'click', function () {
          state.selected = this.getAttribute('data-select');
          if (mapApi) mapApi.update({ selectedId: state.selected });
          renderSide(filtered());
          renderDetail();
        });
        U.on(root, '[data-export-map]', 'click', function () {
          var data = filtered();
          downloadCSV('mapa-intervenciones-sifas.csv', data.ints, [
            { key: 'code', label: 'Código' }, { key: 'speciesName', label: 'Especie' },
            { key: 'occurredAt', label: 'Fecha', value: function (r) { return U.fmtDate(r.occurredAt); } },
            { key: 'priority', label: 'Prioridad', value: function (r) { return r.priority.level; } },
            { key: 'status', label: 'Estado', value: function (r) { return D.STATUS[r.status].label; } },
            { key: 'zone', label: 'Zona', value: function (r) { return (r.location && r.location.zone) || ''; } },
            { key: 'lat', label: 'Latitud', value: function (r) { return r.location.lat; } },
            { key: 'lng', label: 'Longitud', value: function (r) { return r.location.lng; } },
            { key: 'reference', label: 'Referencia', value: function (r) { return (r.location && r.location.reference) || ''; } }
          ]);
        });
        update();
      }
    };
  }

  /* ==================================================================
     REPORTES E INDICADORES (RF012)
     ================================================================== */
  function reportes() {
    var all = Store.interventions();
    var today = new Date();
    var fromDefault = U.dayKey(U.addDays(today, -180));
    var toDefault = U.dayKey(today);
    var h = pageHead('Reportes e indicadores',
      'Indicadores consolidados de rescates, rehabilitación y liberaciones · RF012',
      '<button class="btn btn-secondary" data-print-report>' + U.icon('print') + 'Imprimir</button>' +
      '<button class="btn btn-primary" data-export-report>' + U.icon('download') + 'Exportar CSV</button>');
    h += '<div class="card section"><div class="card-body"><div class="toolbar" style="margin:0">' +
      '<div class="field" style="min-width:150px"><label for="rep-from">Desde</label><input class="input" type="date" id="rep-from" value="' + fromDefault + '"></div>' +
      '<div class="field" style="min-width:150px"><label for="rep-to">Hasta</label><input class="input" type="date" id="rep-to" value="' + toDefault + '"></div>' +
      '<div class="field" style="min-width:160px"><label for="rep-pri">Prioridad</label><select class="select" id="rep-pri"><option value="">Todas</option><option value="I">Prioridad I</option><option value="II">Prioridad II</option><option value="III">Prioridad III</option></select></div>' +
      '<div class="field" style="min-width:180px"><label for="rep-zone">Zona</label><select class="select" id="rep-zone"><option value="">Todas</option>' +
      D.ZONES.map(function (z) { return '<option value="' + U.attr(z.name) + '">' + U.esc(z.name) + '</option>'; }).join('') +
      '<option value="__none">Sin zona</option></select></div>' +
      '<div class="field" style="justify-content:flex-end"><label>&nbsp;</label><button class="btn btn-primary" data-apply-report>' + U.icon('filter') + 'Aplicar filtros</button></div>' +
      '<span class="spacer"></span><span class="result-count" id="rep-count" style="align-self:flex-end"></span>' +
      '</div></div></div><div id="rep-content"></div>';

    function currentRows() {
      var fromEl = document.getElementById('rep-from'), toEl = document.getElementById('rep-to');
      var priEl = document.getElementById('rep-pri'), zoneEl = document.getElementById('rep-zone');
      var from = fromEl && fromEl.value ? new Date(fromEl.value + 'T00:00:00') : null;
      var to = toEl && toEl.value ? new Date(toEl.value + 'T23:59:59') : null;
      var pri = priEl ? priEl.value : '';
      var zone = zoneEl ? zoneEl.value : '';
      return all.filter(function (i) {
        var t = new Date(i.occurredAt || i.createdAt);
        if (from && t < from) return false;
        if (to && t > to) return false;
        if (pri && i.priority.level !== pri) return false;
        if (zone === '__none' && i.location && i.location.zone) return false;
        if (zone && zone !== '__none' && (!i.location || i.location.zone !== zone)) return false;
        return true;
      });
    }

    function draw() {
      var rows = currentRows();
      var holder = document.getElementById('rep-content');
      if (!holder) return;
      var inCare = rows.filter(D.isInCare);
      var released = rows.filter(function (i) { return i.status === 'liberado'; });
      var custody = rows.filter(function (i) { return i.status === 'custodia'; });
      var euth = rows.filter(function (i) { return i.status === 'eutanasia'; });
      var critical = inCare.filter(function (i) { return i.priority.level === 'I'; });
      var georef = rows.filter(hasGeo);
      var withPhotos = rows.filter(function (i) { return i.photos && i.photos.length; });
      var withClinical = rows.filter(function (i) { return Store.clinicalSummary(i.id).count > 0; });
      var withDecision = rows.filter(function (i) { return !!i.decisionId; });
      var byPriority = ['I', 'II', 'III'].map(function (lvl) {
        return { label: 'Prioridad ' + lvl, value: rows.filter(function (i) { return i.priority.level === lvl; }).length, color: D.PRIORITY[lvl].color };
      });
      var bySpecies = Views.field.countBy(rows, function (i) { return i.speciesName; }).slice(0, 8);
      var byZone = Views.field.countBy(rows, function (i) { return (i.location && i.location.zone) || 'Sin zona'; }).slice(0, 8);
      var monthly = Views.field.lastMonthsSeries(rows, 6);
      var outcomes = [
        { label: 'En atención', value: inCare.length, color: '#d99a18' },
        { label: 'Liberados', value: released.length, color: '#2a9169' },
        { label: 'Custodia', value: custody.length, color: '#6f5bd0' },
        { label: 'Eutanasia', value: euth.length, color: '#7b8a82' }
      ];
      function pct(a, b) { return b ? Math.round((a / b) * 100) : 0; }
      var countEl = document.getElementById('rep-count');
      if (countEl) countEl.textContent = rows.length + ' de ' + all.length + ' intervenciones';

      holder.innerHTML =
        '<div class="print-report-head"><strong>SIFAS — Reporte de indicadores</strong><div class="fs-75">' +
        U.esc(Store.get().settings.institution) + ' · Generado el ' + U.fmtDateTime(U.nowISO()) + '</div></div>' +
        '<div class="grid grid-4 section">' +
        stat('paw', 'Intervenciones', rows.length, 'Periodo seleccionado', '') +
        stat('heart', 'En rehabilitación', inCare.length, 'Cuarentena o atención activa', 'tone-amber') +
        stat('leaf', 'Liberaciones', released.length, pct(released.length, rows.length) + '% del total', 'tone-blue') +
        stat('alert', 'Prioridad I', critical.length, 'Casos críticos en atención', 'tone-red') +
        '</div>' +
        '<div class="grid grid-4 section">' +
        stat('shield', 'Custodia permanente', custody.length, 'Derivados a centros autorizados', 'tone-purple') +
        stat('scale', 'Eutanasia', euth.length, 'Decisiones humanitarias justificadas', '') +
        stat('camera', 'Con evidencia fotográfica', withPhotos.length, pct(withPhotos.length, rows.length) + '% de cobertura', 'tone-blue') +
        stat('pin', 'Georreferenciadas', georef.length, pct(georef.length, rows.length) + '% con coordenadas', 'tone-amber') +
        '</div>' +
        '<div class="split section"><div class="card"><div class="card-head"><h3>' + U.icon('activity') + ' Evolución mensual</h3><span class="hint" style="margin-left:auto">Últimos 6 meses</span></div>' +
        '<div class="card-body">' + Charts.line([{ points: monthly, color: '#1b7a56', label: 'Intervenciones registradas por mes' }], { height: 210 }) + '</div></div>' +
        '<div class="card"><div class="card-head"><h3>Distribución por prioridad</h3></div><div class="card-body">' + Charts.donut(byPriority, { centerLabel: 'intervenciones', size: 145 }) + '</div></div></div>' +
        '<div class="split-even section"><div class="card"><div class="card-head"><h3>Especies atendidas</h3><span class="hint" style="margin-left:auto">Top 8</span></div><div class="card-body">' + Charts.barList(bySpecies, { color: '#2a9169' }) + '</div></div>' +
        '<div class="card"><div class="card-head"><h3>Zonas de procedencia</h3><span class="hint" style="margin-left:auto">Según GPS</span></div><div class="card-body">' + Charts.barList(byZone, { color: '#b7791f' }) + '</div></div></div>' +
        '<div class="split section"><div class="card"><div class="card-head"><h3>Resultado de las intervenciones</h3></div><div class="card-body">' +
        Charts.statusBar(outcomes, {}) + '<p class="hint" style="margin:.8rem 0 0">La liberación solo se registra cuando existe alta médica y comportamiento apto (RD005).</p></div></div>' +
        '<div class="card"><div class="card-head"><h3>Calidad del registro</h3></div><div class="card-body">' +
        '<div class="kpi-row">' +
        '<div class="kpi-mini"><div class="km-val">' + pct(withClinical.length, rows.length) + '%</div><div class="km-lbl">Con historia clínica</div></div>' +
        '<div class="kpi-mini"><div class="km-val">' + pct(withDecision.length, rows.length) + '%</div><div class="km-lbl">Con decisión técnica</div></div>' +
        '<div class="kpi-mini"><div class="km-val">' + pct(withPhotos.length, rows.length) + '%</div><div class="km-lbl">Con fotografías</div></div>' +
        '<div class="kpi-mini"><div class="km-val">' + pct(georef.length, rows.length) + '%</div><div class="km-lbl">Con GPS</div></div>' +
        '</div><p class="hint" style="margin:.8rem 0 0">Indicadores de trazabilidad calculados sobre las intervenciones del periodo.</p></div></div></div>' +
        '<div class="card section"><div class="card-head"><h3>Detalle de intervenciones</h3><span class="hint" style="margin-left:auto">' + rows.length + ' registros</span></div>' +
        '<div class="table-wrap"><table class="tbl"><thead><tr><th>Código</th><th>Especie</th><th>Zona</th><th>Prioridad</th><th>Estado</th><th>Decisión</th><th>Fecha</th></tr></thead><tbody>' +
        (rows.length ? U.sortBy(rows, function (i) { return new Date(i.occurredAt); }, true).slice(0, 40).map(function (i) {
          var dec = Store.decisionFor(i.id);
          return '<tr><td class="t-code">' + U.esc(i.code) + '</td><td class="t-main">' + U.esc(i.speciesName) + '</td>' +
            '<td class="t-sub">' + U.esc((i.location && i.location.zone) || '—') + '</td><td>' + UI.priorityBadge(i.priority.level) + '</td>' +
            '<td>' + UI.statusBadge(i.status) + '</td><td class="t-sub">' + (dec ? U.esc(dec.type === 'liberacion' ? 'Liberación' : dec.type === 'custodia' ? 'Custodia' : 'Eutanasia') : 'Pendiente') + '</td>' +
            '<td class="t-sub t-nowrap">' + U.fmtDate(i.occurredAt) + '</td></tr>';
        }).join('') : '<tr><td colspan="7"><div class="table-empty">' + U.icon('chart') + 'No hay intervenciones en el periodo seleccionado.</div></td></tr>') +
        '</tbody></table></div></div>';

      holder._rows = rows;
    }

    return {
      html: h,
      mount: function (root) {
        Store.log(user(), 'Consulta de reportes', 'reporte', 'indicadores', 'Generación de indicadores consolidados.', false);
        draw();
        root.querySelector('[data-apply-report]').addEventListener('click', draw);
        root.querySelector('[data-print-report]').addEventListener('click', function () { window.print(); });
        root.querySelector('[data-export-report]').addEventListener('click', function () {
          var holder = root.querySelector('#rep-content');
          var rows = (holder && holder._rows) || currentRows();
          downloadCSV('reporte-intervenciones-sifas.csv', rows, [
            { key: 'code', label: 'Código' }, { key: 'speciesName', label: 'Especie' },
            { key: 'scientificName', label: 'Nombre científico' },
            { key: 'priority', label: 'Prioridad', value: function (r) { return r.priority.level; } },
            { key: 'score', label: 'Puntaje triaje', value: function (r) { return r.priority.score; } },
            { key: 'status', label: 'Estado', value: function (r) { return D.STATUS[r.status].label; } },
            { key: 'zone', label: 'Zona', value: function (r) { return (r.location && r.location.zone) || ''; } },
            { key: 'agentName', label: 'Agente' },
            { key: 'occurredAt', label: 'Fecha', value: function (r) { return U.fmtDate(r.occurredAt); } },
            { key: 'decision', label: 'Decisión', value: function (r) { var d = Store.decisionFor(r.id); return d ? d.type : 'Pendiente'; } }
          ]);
        });
      }
    };
  }

  /* ==================================================================
     DENUNCIAS CIUDADANAS (RF013 / RF014 / RD008)
     ================================================================== */
  function denuncias() {
    var all = Store.denuncias();
    var u = user();
    var h = pageHead('Denuncias ciudadanas',
      'Reportes anónimos recibidos por el portal · sin datos personales del ciudadano (RD008)',
      '<button class="btn btn-secondary" data-export-den>' + U.icon('download') + 'Exportar</button>' +
      linkBtn('#/denunciar', 'external', 'Ver portal ciudadano', 'btn-ghost'));
    h += '<div class="grid grid-4 section">' +
      stat('alert', 'Denuncias recibidas', all.length, 'Total histórico del canal ciudadano', '') +
      stat('clock', 'Nuevas', all.filter(function (d) { return d.status === 'nueva'; }).length, 'Pendientes de revisión', 'tone-blue') +
      stat('activity', 'En revisión', all.filter(function (d) { return d.status === 'en_revision'; }).length, 'En verificación por el equipo', 'tone-amber') +
      stat('shield', 'Derivadas', all.filter(function (d) { return d.status === 'derivada'; }).length, 'Enviadas a fiscalización', 'tone-purple') +
      '</div>';
    h += '<div class="card"><div class="card-body"><div class="toolbar">' +
      '<div class="search-box">' + U.icon('search') + '<input class="input" id="den-q" type="search" placeholder="Buscar por código, especie o lugar…" aria-label="Buscar denuncia"></div>' +
      '<select class="select" id="den-status" aria-label="Filtrar estado"><option value="">Todo estado</option>' +
      Object.keys(D.DENUNCIA_STATUS).map(function (k) { return '<option value="' + k + '">' + D.DENUNCIA_STATUS[k].label + '</option>'; }).join('') + '</select>' +
      '<select class="select" id="den-type" aria-label="Filtrar tipo"><option value="">Todo tipo</option>' +
      D.DENUNCIA_TYPES.map(function (t) { return '<option value="' + t.key + '">' + t.label + '</option>'; }).join('') + '</select>' +
      '<span class="spacer"></span><span class="result-count" id="den-count"></span></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Código</th><th>Tipo / especie</th><th>Ubicación</th><th>Estado</th><th>Recibida</th><th></th></tr></thead><tbody id="den-body"></tbody></table></div>' +
      '</div></div>';

    return {
      html: h,
      mount: function (root) {
        Store.log(u, 'Consulta de denuncias ciudadanas', 'denuncia', 'bandeja', 'Acceso a la bandeja de reportes anónimos.', true);
        var body = root.querySelector('#den-body');
        var q = root.querySelector('#den-q'), st = root.querySelector('#den-status'), tp = root.querySelector('#den-type');
        var count = root.querySelector('#den-count');
        function draw() {
          var query = U.normalize(q.value);
          var rows = U.sortBy(all, function (d) { return new Date(d.ts); }, true).filter(function (d) {
            var text = U.normalize(d.code + ' ' + d.species + ' ' + d.description + ' ' + ((d.location && d.location.reference) || ''));
            return (!query || text.indexOf(query) >= 0) && (!st.value || d.status === st.value) && (!tp.value || d.type === tp.value);
          });
          count.textContent = rows.length + ' de ' + all.length + ' denuncias';
          body.innerHTML = rows.length ? rows.map(function (d) {
            var meta = statusMeta(d.status);
            return '<tr><td class="t-code">' + U.esc(d.code) + '</td>' +
              '<td><div class="t-main">' + U.esc(typeLabel(d.type)) + '</div><div class="t-sub">' + U.esc(d.species) + '</div></td>' +
              '<td class="t-sub">' + U.esc((d.location && d.location.reference) || 'No especificada') + '</td>' +
              '<td>' + UI.badge(meta.label, meta.tone) + '</td>' +
              '<td class="t-sub t-nowrap">' + U.fmtDateTime(d.ts) + '</td>' +
              '<td class="t-right"><button class="btn btn-sm btn-soft" data-review="' + U.attr(d.id) + '">Revisar ' + U.icon('arrowRight') + '</button></td></tr>';
          }).join('') : '<tr><td colspan="6"><div class="table-empty">' + U.icon('alert') + 'No se encontraron denuncias con los filtros aplicados.</div></td></tr>';
        }
        q.addEventListener('input', U.debounce(draw, 150));
        st.addEventListener('change', draw);
        tp.addEventListener('change', draw);
        U.on(root, '[data-review]', 'click', function () { openDenunciaModal(this.getAttribute('data-review')); });
        root.querySelector('[data-export-den]').addEventListener('click', function () {
          downloadCSV('denuncias-ciudadanas-sifas.csv', Store.denuncias(), [
            { key: 'code', label: 'Código' }, { key: 'ts', label: 'Fecha', value: function (d) { return U.fmtDateTime(d.ts); } },
            { key: 'type', label: 'Tipo', value: function (d) { return typeLabel(d.type); } },
            { key: 'species', label: 'Especie' }, { key: 'description', label: 'Descripción' },
            { key: 'reference', label: 'Referencia', value: function (d) { return (d.location && d.location.reference) || ''; } },
            { key: 'status', label: 'Estado', value: function (d) { return statusMeta(d.status).label; } },
            { key: 'notes', label: 'Actualizaciones', value: function (d) { return d.notes.length; } }
          ]);
        });
        draw();
      }
    };
  }

  function openDenunciaModal(id) {
    var den = Store.denuncia(id);
    if (!den) return;
    var u = user();
    var meta = statusMeta(den.status);
    var body = '<div class="pill-row" style="margin-bottom:.9rem">' + UI.badge(meta.label, meta.tone) +
      '<span class="chip">' + U.icon('lock') + 'Denuncia anónima</span><span class="chip">' + U.esc(den.code) + '</span></div>' +
      '<div class="meta-grid">' + UI.infoRow('Tipo de infracción', U.esc(typeLabel(den.type))) +
      UI.infoRow('Especie reportada', U.esc(den.species)) + UI.infoRow('Fecha de registro', U.fmtDateTime(den.ts)) +
      UI.infoRow('Referencia', U.esc((den.location && den.location.reference) || 'No especificada')) + '</div>' +
      '<div class="divider"></div><strong class="fs-75">Descripción del hecho</strong>' +
      '<p style="font-size:.82rem;color:var(--ink-soft);line-height:1.6;margin:.35rem 0 0">' + U.esc(den.description) + '</p>' +
      (den.photos && den.photos.length ? '<div class="divider"></div><strong class="fs-75">Evidencias fotográficas</strong>' + UI.photoGrid(den.photos) : '') +
      (hasGeo(den) ? '<div class="divider"></div><strong class="fs-75">Ubicación registrada</strong><div id="den-modal-map" class="mt-1"></div>' : '') +
      '<div class="divider"></div><strong class="fs-75">Historial de atención</strong><div class="timeline mt-1">' +
      '<div class="tl-item"><div class="tl-head"><span class="tl-title">Denuncia recibida</span><span class="tl-time">' + U.fmtDateTime(den.ts) + '</span></div>' +
      '<div class="tl-body">Registrada por el canal ciudadano anónimo. No se almacenan datos personales.</div></div>' +
      den.notes.map(function (n) {
        return '<div class="tl-item"><div class="tl-head"><span class="tl-title">Actualización</span><span class="tl-time">' + U.fmtDateTime(n.ts) + '</span></div>' +
          '<div class="tl-body">' + U.esc(n.text) + ' <span class="text-muted">— ' + U.esc(n.author) + '</span></div></div>';
      }).join('') + '</div>' +
      '<div class="divider"></div><div class="form-grid">' +
      '<div class="field"><label for="den-new-status">Nuevo estado</label><select class="select" id="den-new-status">' +
      Object.keys(D.DENUNCIA_STATUS).map(function (k) {
        return '<option value="' + k + '"' + (den.status === k ? ' selected' : '') + '>' + D.DENUNCIA_STATUS[k].label + '</option>';
      }).join('') + '</select></div>' +
      '<div class="field"><label for="den-new-note">Nota de seguimiento</label><input class="input" id="den-new-note" maxlength="240" placeholder="Ej. Derivada a la FEMA para verificación en campo."></div>' +
      '</div><div class="alert-banner ab-blue" style="margin:1rem 0 0">' + U.icon('lock') +
      '<span>La identidad del ciudadano no se registra ni se muestra. No solicite datos personales para atender este reporte (RD008).</span></div>';
    var m = UI.modal({
      title: den.code, subtitle: 'Revisión de denuncia ciudadana', size: 'lg', body: body,
      footer: '<button class="btn btn-secondary" type="button" data-close-den>Cancelar</button>' +
        '<button class="btn btn-primary" type="button" data-save-den>' + U.icon('save') + 'Guardar cambios</button>'
    });
    if (hasGeo(den)) {
      MapView.create(m.body.querySelector('#den-modal-map'), {
        markers: [{ id: den.id, lat: den.location.lat, lng: den.location.lng, color: '#6f5bd0', title: den.code, subtitle: typeLabel(den.type) }],
        showZones: false, legend: false, zoom: true, selectedId: den.id
      });
    }
    m.el.querySelector('[data-close-den]').addEventListener('click', UI.closeModal);
    m.el.querySelector('[data-save-den]').addEventListener('click', function () {
      var status = m.el.querySelector('#den-new-status').value;
      var note = m.el.querySelector('#den-new-note').value.trim();
      try {
        Store.updateDenuncia(den.id, { status: status, note: note }, u);
        UI.closeModal();
        UI.toast('La denuncia ' + den.code + ' fue actualizada.', 'success');
        S.App.refresh();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
    U.on(m.el, '[data-photo]', 'click', function () { UI.lightbox(this.getAttribute('data-photo'), this.getAttribute('data-caption')); });
  }

  /* ==================================================================
     USUARIOS (RF001 / RNF001 / RD010)
     ================================================================== */
  function usuarios() {
    var users = Store.users();
    var h = pageHead('Gestión de usuarios',
      'Altas, roles y estado de las cuentas institucionales · RF001 / RD010',
      '<button class="btn btn-primary" data-new-user>' + U.icon('plus') + 'Nuevo usuario</button>');
    h += '<div class="grid grid-4 section">' +
      stat('users', 'Usuarios registrados', users.length, 'Cuentas del sistema', '') +
      stat('shieldCheck', 'Activos', users.filter(function (u) { return u.active; }).length, 'Con acceso habilitado', 'tone-blue') +
      stat('stethoscope', 'Veterinarios', users.filter(function (u) { return u.role === 'vet'; }).length, 'Historias clínicas y decisiones', 'tone-amber') +
      stat('paw', 'Agentes de campo', users.filter(function (u) { return u.role === 'field'; }).length, 'Registro de intervenciones', 'tone-purple') +
      '</div>';
    h += '<div class="card"><div class="card-body"><div class="toolbar">' +
      '<div class="search-box">' + U.icon('search') + '<input class="input" id="usr-q" type="search" placeholder="Buscar por nombre o correo…" aria-label="Buscar usuario"></div>' +
      '<select class="select" id="usr-role" aria-label="Filtrar rol"><option value="">Todos los roles</option>' +
      Object.keys(D.ROLE_DEFS).map(function (k) { return '<option value="' + k + '">' + D.ROLE_DEFS[k].label + '</option>'; }).join('') + '</select>' +
      '<select class="select" id="usr-active" aria-label="Filtrar estado"><option value="">Todos</option><option value="1">Activos</option><option value="0">Inactivos</option></select>' +
      '<span class="spacer"></span><span class="result-count" id="usr-count"></span></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Usuario</th><th>Rol</th><th>Teléfono</th><th>Estado</th><th>Último acceso</th><th>Creado</th><th></th></tr></thead><tbody id="usr-body"></tbody></table></div>' +
      '</div></div>';

    return {
      html: h,
      mount: function (root) {
        Store.log(user(), 'Consulta de usuarios', 'usuario', 'lista', 'Acceso a la gestión de cuentas.', true);
        var body = root.querySelector('#usr-body');
        var q = root.querySelector('#usr-q'), role = root.querySelector('#usr-role'), active = root.querySelector('#usr-active');
        var count = root.querySelector('#usr-count');
        function draw() {
          var query = U.normalize(q.value);
          var rows = users.filter(function (u) {
            var text = U.normalize(u.name + ' ' + u.email);
            return (!query || text.indexOf(query) >= 0) && (!role.value || u.role === role.value) &&
              (active.value === '' || String(u.active ? 1 : 0) === active.value);
          });
          count.textContent = rows.length + ' de ' + users.length + ' usuarios';
          body.innerHTML = rows.length ? rows.map(function (u) {
            return '<tr><td><div style="display:flex;align-items:center;gap:.55rem"><span class="avatar sm">' + U.esc(U.initials(u.name)) + '</span>' +
              '<div><div class="t-main">' + U.esc(u.name) + '</div><div class="t-sub">' + U.esc(u.email) + '</div></div></div></td>' +
              '<td>' + UI.badge(D.roleLabel(u.role), UI.roleTone(u.role)) + '</td>' +
              '<td class="t-sub">' + U.esc(u.phone || '—') + '</td>' +
              '<td>' + (u.active ? UI.badge('Activo', 'green') : UI.badge('Inactivo', 'gray')) + '</td>' +
              '<td class="t-sub t-nowrap">' + (u.lastLogin ? U.fmtDateTime(u.lastLogin) : 'Sin acceso') + '</td>' +
              '<td class="t-sub t-nowrap">' + U.fmtDate(u.createdAt) + '</td>' +
              '<td class="t-right" style="white-space:nowrap"><button class="btn btn-sm btn-soft" data-edit-user="' + U.attr(u.id) + '">' + U.icon('edit') + '</button> ' +
              (u.id === user().id ? '' : '<button class="btn btn-sm ' + (u.active ? 'btn-danger-soft' : 'btn-secondary') + '" data-toggle-user="' + U.attr(u.id) + '">' +
                (u.active ? 'Desactivar' : 'Activar') + '</button>') + '</td></tr>';
          }).join('') : '<tr><td colspan="7"><div class="table-empty">' + U.icon('users') + 'No se encontraron usuarios.</div></td></tr>';
        }
        q.addEventListener('input', U.debounce(draw, 150));
        role.addEventListener('change', draw);
        active.addEventListener('change', draw);
        U.on(root, '[data-new-user]', 'click', function () { openUserModal(null); });
        U.on(root, '[data-edit-user]', 'click', function () { openUserModal(this.getAttribute('data-edit-user')); });
        U.on(root, '[data-toggle-user]', 'click', function () {
          var id = this.getAttribute('data-toggle-user');
          var target = Store.findUser(id);
          if (!target) return;
          UI.confirm({
            title: target.active ? 'Desactivar cuenta' : 'Activar cuenta',
            message: (target.active ? 'El usuario ' + target.name + ' no podrá iniciar sesión mientras la cuenta esté desactivada.' :
              'Se habilitará nuevamente el acceso de ' + target.name + '.'),
            confirmLabel: target.active ? 'Desactivar' : 'Activar', danger: target.active
          }).then(function (ok) {
            if (!ok) return;
            try {
              Store.updateUser(id, { active: !target.active }, user());
              UI.toast('Estado de la cuenta actualizado.', 'success');
              S.App.refresh();
            } catch (e) { UI.toast(e.message, 'error'); }
          });
        });
        draw();
      }
    };
  }

  function openUserModal(userId) {
    var editing = userId ? Store.findUser(userId) : null;
    var me = user();
    var isSelf = editing && editing.id === me.id;
    var body = '<div class="form-grid">' +
      '<div class="field span-2"><label for="us-name">Nombre completo <span class="req">*</span></label><input class="input" id="us-name" maxlength="90" value="' + U.attr(editing ? editing.name : '') + '" placeholder="Nombres y apellidos"></div>' +
      '<div class="field"><label for="us-email">Correo institucional <span class="req">*</span></label><input class="input" id="us-email" type="email" maxlength="120" value="' + U.attr(editing ? editing.email : '') + '" placeholder="nombre@serfor.gob.pe"></div>' +
      '<div class="field"><label for="us-phone">Teléfono</label><input class="input" id="us-phone" maxlength="30" value="' + U.attr(editing ? (editing.phone || '') : '') + '" placeholder="964 000 000"></div>' +
      '<div class="field"><label for="us-role">Rol <span class="req">*</span></label><select class="select" id="us-role"' + (isSelf ? ' disabled' : '') + '>' +
      Object.keys(D.ROLE_DEFS).map(function (k) {
        return '<option value="' + k + '"' + (editing && editing.role === k ? ' selected' : '') + '>' + D.ROLE_DEFS[k].label + '</option>';
      }).join('') + '</select><span class="hint">' + U.esc((D.ROLE_DEFS[editing ? editing.role : 'field'] || {}).desc || '') + '</span></div>' +
      '<div class="field"><label for="us-pass">' + (editing ? 'Nueva contraseña (opcional)' : 'Contraseña <span class="req">*</span>') + '</label>' +
      '<input class="input" id="us-pass" type="password" autocomplete="new-password" placeholder="' + (editing ? 'Dejar en blanco para conservar' : 'Mínimo 8 caracteres') + '">' +
      '<span class="hint">Debe incluir mayúscula, minúscula, número y símbolo.</span></div>' +
      '<div class="field"><label for="us-pass2">Confirmar contraseña</label><input class="input" id="us-pass2" type="password" autocomplete="new-password" placeholder="Repita la contraseña"></div>' +
      '</div>' +
      (editing ? '<div class="divider"></div><label class="check"><input type="checkbox" id="us-active"' + (editing.active ? ' checked' : '') + (isSelf ? ' disabled' : '') + '> Cuenta habilitada para iniciar sesión</label>' +
        (isSelf ? '<p class="hint" style="margin:.4rem 0 0">No puedes desactivar tu propia cuenta ni cambiar tu propio rol.</p>' : '') : '') +
      '<div class="alert-banner ab-blue" style="margin:1rem 0 0">' + U.icon('lock') +
      '<span>Las contraseñas se almacenan con derivación criptográfica y sal; nunca en texto plano (RNF002).</span></div>';
    var m = UI.modal({
      title: editing ? 'Editar usuario' : 'Registrar nuevo usuario',
      subtitle: editing ? editing.email : 'Alta de cuenta institucional',
      size: 'lg', body: body,
      footer: '<button class="btn btn-secondary" type="button" data-cancel-user>Cancelar</button>' +
        '<button class="btn btn-primary" type="button" data-save-user>' + U.icon('save') + (editing ? 'Guardar cambios' : 'Crear usuario') + '</button>'
    });
    m.el.querySelector('[data-cancel-user]').addEventListener('click', UI.closeModal);
    m.el.querySelector('[data-save-user]').addEventListener('click', function () {
      var name = m.el.querySelector('#us-name').value.trim();
      var email = m.el.querySelector('#us-email').value.trim();
      var phone = m.el.querySelector('#us-phone').value.trim();
      var role = m.el.querySelector('#us-role').value;
      var pass = m.el.querySelector('#us-pass').value;
      var pass2 = m.el.querySelector('#us-pass2').value;
      if (!name) { UI.toast('Ingrese el nombre completo del usuario.', 'error'); return; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { UI.toast('Ingrese un correo electrónico válido.', 'error'); return; }
      if ((!editing || pass) && pass !== pass2) { UI.toast('Las contraseñas no coinciden.', 'error'); return; }
      if (!editing && !pass) { UI.toast('Defina una contraseña inicial para el usuario.', 'error'); return; }
      if (pass) {
        var check = D.validatePassword(pass);
        if (!check.ok) { UI.toast('Contraseña insegura: ' + check.errors.join(' '), 'error'); return; }
      }
      try {
        if (editing) {
          Store.updateUser(editing.id, {
            name: name, email: email, phone: phone,
            role: isSelf ? editing.role : role,
            active: isSelf ? editing.active : m.el.querySelector('#us-active').checked,
            password: pass || undefined
          }, me);
          UI.toast('Los datos del usuario fueron actualizados.', 'success');
        } else {
          Store.createUser({ name: name, email: email, phone: phone, role: role, password: pass }, me);
          UI.toast('Usuario creado correctamente.', 'success');
        }
        UI.closeModal();
        S.App.refresh();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
  }

  /* ==================================================================
     ROLES Y PERMISOS (RNF001 / RD010)
     ================================================================== */
  function roles() {
    var perms = Store.get().rolePermissions;
    var groups = U.groupBy(D.PERMISSIONS, function (p) { return p.group; });
    var roleKeys = ['vet', 'field', 'logistics'];
    var h = pageHead('Roles y permisos',
      'Control de acceso basado en roles · los cambios se aplican a todas las cuentas del rol',
      '<button class="btn btn-secondary" data-reset-perms>' + U.icon('refresh') + 'Restaurar valores</button>' +
      '<button class="btn btn-primary" data-save-perms>' + U.icon('save') + 'Guardar cambios</button>');
    h += '<div class="alert-banner ab-blue">' + U.icon('shield') +
      '<span><strong>RD010.</strong> Las funciones administrativas solo están disponibles para el rol Administrador. Los permisos del Administrador no se pueden restringir.</span></div>';
    h += '<div class="grid grid-4 section">' +
      Object.keys(D.ROLE_DEFS).map(function (k) {
        var count = k === 'admin' ? D.PERMISSIONS.length : (perms[k] || []).length;
        return '<article class="stat"><div class="st-top"><span class="st-icon">' + U.icon(k === 'admin' ? 'shieldCheck' : k === 'vet' ? 'stethoscope' : k === 'field' ? 'paw' : 'box') + '</span>' +
          '<span class="st-label">' + U.esc(D.ROLE_DEFS[k].label) + '</span></div>' +
          '<div class="st-value">' + count + '</div><div class="st-foot">' + count + ' permisos asignados</div></article>';
      }).join('') + '</div>';
    h += '<div class="card"><div class="card-head"><h3>' + U.icon('lock') + ' Matriz de permisos</h3>' +
      '<span class="hint" style="margin-left:auto">Marque los permisos que debe tener cada rol</span></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Permiso</th>' +
      roleKeys.map(function (r) { return '<th style="text-align:center">' + U.esc(D.ROLE_DEFS[r].label) + '</th>'; }).join('') +
      '<th style="text-align:center">Administrador</th></tr></thead><tbody>' +
      Object.keys(groups).map(function (group) {
        return '<tr><td colspan="5" style="background:var(--sand-50);font-size:.68rem;font-weight:800;text-transform:uppercase;letter-spacing:.07em;color:var(--green-800)">' + U.esc(group) + '</td></tr>' +
          groups[group].map(function (p) {
            return '<tr><td><div class="t-main" style="font-size:.78rem">' + U.esc(p.label) + '</div><div class="t-sub mono">' + U.esc(p.key) + '</div></td>' +
              roleKeys.map(function (r) {
                var checked = (perms[r] || []).indexOf(p.key) >= 0;
                return '<td style="text-align:center"><input type="checkbox" class="perm-check" data-role="' + r + '" data-perm="' + U.attr(p.key) + '"' +
                  (checked ? ' checked' : '') + ' aria-label="' + U.attr(D.ROLE_DEFS[r].label + ': ' + p.label) + '" style="width:16px;height:16px;accent-color:var(--green-700)"></td>';
              }).join('') +
              '<td style="text-align:center"><input type="checkbox" checked disabled aria-label="Administrador: acceso total" style="width:16px;height:16px;accent-color:var(--green-700)"></td></tr>';
          }).join('');
      }).join('') + '</tbody></table></div></div>';
    h += '<p class="hint mt-2">Los permisos se validan en el servidor de aplicación en un despliegue institucional. En este prototipo la validación se ejecuta en el cliente y queda registrada en la auditoría.</p>';

    return {
      html: h,
      mount: function (root) {
        root.querySelector('[data-save-perms]').addEventListener('click', function () {
          try {
            roleKeys.forEach(function (r) {
              var selected = U.$$('.perm-check[data-role="' + r + '"]', root)
                .filter(function (c) { return c.checked; })
                .map(function (c) { return c.getAttribute('data-perm'); });
              Store.setRolePermissions(r, selected, user());
            });
            UI.toast('Los permisos de los roles fueron actualizados.', 'success');
            S.App.refresh();
          } catch (e) { UI.toast(e.message, 'error'); }
        });
        root.querySelector('[data-reset-perms]').addEventListener('click', function () {
          UI.confirm({
            title: 'Restaurar permisos predeterminados',
            message: 'Se reemplazarán los permisos personalizados de los roles por la configuración inicial del sistema.',
            confirmLabel: 'Restaurar'
          }).then(function (ok) {
            if (!ok) return;
            try {
              roleKeys.forEach(function (r) { Store.setRolePermissions(r, D.DEFAULT_PERMS[r], user()); });
              UI.toast('Permisos restaurados a la configuración inicial.', 'success');
              S.App.refresh();
            } catch (e) { UI.toast(e.message, 'error'); }
          });
        });
      }
    };
  }

  /* ==================================================================
     AUDITORÍA (RNF001 / RNF002 / RNF006 / RD010)
     ================================================================== */
  function auditoria() {
    var logs = Store.get().audit;
    var u = user();
    var h = pageHead('Auditoría del sistema',
      'Registro de acciones sobre información sensible · usuario, fecha y hora (RNF006)',
      '<button class="btn btn-secondary" data-export-audit>' + U.icon('download') + 'Exportar</button>');
    h += '<div class="grid grid-4 section">' +
      stat('file', 'Eventos registrados', logs.length, 'Bitácora del sistema', '') +
      stat('shield', 'Acciones sensibles', logs.filter(function (l) { return l.sensitive; }).length, 'Acceso o modificación de datos protegidos', 'tone-red') +
      stat('users', 'Usuarios con actividad', U.unique(logs.map(function (l) { return l.userName; })).length, 'Responsables identificados', 'tone-blue') +
      stat('clock', 'Últimas 24 horas', logs.filter(function (l) { return Date.now() - new Date(l.ts).getTime() < 86400000; }).length, 'Eventos recientes', 'tone-amber') +
      '</div>';
    h += '<div class="card"><div class="card-body"><div class="toolbar">' +
      '<div class="search-box">' + U.icon('search') + '<input class="input" id="aud-q" type="search" placeholder="Buscar acción, usuario o detalle…" aria-label="Buscar en auditoría"></div>' +
      '<select class="select" id="aud-role" aria-label="Filtrar rol"><option value="">Todos los roles</option>' +
      Object.keys(D.ROLE_DEFS).map(function (k) { return '<option value="' + k + '">' + D.ROLE_DEFS[k].label + '</option>'; }).join('') +
      '<option value="public">Ciudadano / público</option></select>' +
      '<label class="check" style="font-size:.75rem"><input type="checkbox" id="aud-sens"> Solo acciones sensibles</label>' +
      '<span class="spacer"></span><span class="result-count" id="aud-count"></span></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Fecha y hora</th><th>Usuario</th><th>Acción</th><th>Entidad</th><th>Detalle</th><th>Tipo</th></tr></thead><tbody id="aud-body"></tbody></table></div>' +
      '<div class="mt-2" style="display:flex;justify-content:center"><button class="btn btn-secondary" id="aud-more">Mostrar más eventos</button></div>' +
      '</div></div>';

    return {
      html: h,
      mount: function (root) {
        Store.log(u, 'Consulta de auditoría', 'auditoria', 'bitacora', 'Acceso a la bitácora del sistema.', true);
        var body = root.querySelector('#aud-body');
        var q = root.querySelector('#aud-q'), role = root.querySelector('#aud-role'), sens = root.querySelector('#aud-sens');
        var count = root.querySelector('#aud-count'), more = root.querySelector('#aud-more');
        var limit = 60;
        function filtered() {
          var query = U.normalize(q.value);
          return logs.filter(function (l) {
            var text = U.normalize(l.action + ' ' + l.userName + ' ' + l.detail + ' ' + l.entityId);
            return (!query || text.indexOf(query) >= 0) && (!role.value || l.role === role.value) && (!sens.checked || l.sensitive);
          });
        }
        function draw() {
          var rows = filtered();
          count.textContent = rows.length + ' eventos';
          body.innerHTML = rows.length ? rows.slice(0, limit).map(function (l) {
            return '<tr><td class="t-sub t-nowrap">' + U.fmtDateTime(l.ts) + '</td>' +
              '<td><div class="t-main">' + U.esc(l.userName) + '</div><div class="t-sub">' + U.esc(D.roleLabel(l.role) === l.role ? (l.role === 'public' ? 'Ciudadano' : l.role) : D.roleLabel(l.role)) + '</div></td>' +
              '<td><div class="t-main" style="font-size:.78rem">' + U.esc(l.action) + '</div></td>' +
              '<td class="t-sub"><span class="mono">' + U.esc(l.entity) + '</span><br>' + U.esc(l.entityId) + '</td>' +
              '<td class="t-sub" style="max-width:340px">' + U.esc(l.detail) + '</td>' +
              '<td>' + (l.sensitive ? UI.badge('Sensible', 'red') : UI.badge('General', 'gray')) + '</td></tr>';
          }).join('') : '<tr><td colspan="6"><div class="table-empty">' + U.icon('shield') + 'No hay eventos que coincidan con los filtros.</div></td></tr>';
          more.style.display = rows.length > limit ? '' : 'none';
        }
        q.addEventListener('input', U.debounce(draw, 150));
        role.addEventListener('change', draw);
        sens.addEventListener('change', draw);
        more.addEventListener('click', function () { limit += 60; draw(); });
        root.querySelector('[data-export-audit]').addEventListener('click', function () {
          downloadCSV('auditoria-sifas.csv', filtered(), [
            { key: 'ts', label: 'Fecha y hora', value: function (l) { return U.fmtDateTime(l.ts); } },
            { key: 'userName', label: 'Usuario' }, { key: 'role', label: 'Rol' },
            { key: 'action', label: 'Acción' }, { key: 'entity', label: 'Entidad' },
            { key: 'entityId', label: 'ID entidad' }, { key: 'detail', label: 'Detalle' },
            { key: 'sensitive', label: 'Sensible', value: function (l) { return l.sensitive ? 'Sí' : 'No'; } }
          ]);
        });
        draw();
      }
    };
  }

  /* ==================================================================
     RESPALDO Y CONFIGURACIÓN (RNF002 / RNF006)
     ================================================================== */
  function respaldo() {
    var u = user();
    var db = Store.get();
    var bytes = U.storageBytes();
    var photos = Store.interventions().reduce(function (acc, i) { return acc + (i.photos ? i.photos.length : 0); }, 0) +
      Store.denuncias().reduce(function (acc, d) { return acc + (d.photos ? d.photos.length : 0); }, 0);
    var h = pageHead('Respaldo y configuración',
      'Copia de seguridad, restauración y parámetros del sistema · RNF002 / RNF006',
      '<button class="btn btn-primary" data-export-backup>' + U.icon('download') + 'Descargar respaldo</button>');
    h += '<div class="grid grid-4 section">' +
      stat('database', 'Almacenamiento usado', U.formatBytes(bytes), 'Datos locales del navegador', '') +
      stat('paw', 'Intervenciones', db.interventions.length, 'Registros incluidos en el respaldo', 'tone-blue') +
      stat('camera', 'Evidencias', photos, 'Fotografías asociadas', 'tone-amber') +
      stat('users', 'Usuarios', db.users.length, 'Cuentas institucionales', 'tone-purple') +
      '</div>';
    h += '<div class="split-even section">' +
      '<div class="card"><div class="card-head"><h3>' + U.icon('download') + ' Exportar información</h3></div><div class="card-body">' +
      '<p class="fs-75" style="color:var(--ink-soft);line-height:1.6">Descarga una copia completa en formato JSON. Incluye usuarios (con contraseñas derivadas), intervenciones, historias clínicas, decisiones, inventario, denuncias, notificaciones y auditoría.</p>' +
      '<div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.8rem"><button class="btn btn-primary" data-export-backup>' + U.icon('download') + 'Respaldo JSON</button>' +
      '<button class="btn btn-secondary" data-export-all-csv>' + U.icon('file') + 'Intervenciones CSV</button></div>' +
      '<p class="hint" style="margin-top:.7rem">Recomendación: descargue un respaldo antes de restaurar o reiniciar el sistema.</p></div></div>' +
      '<div class="card"><div class="card-head"><h3>' + U.icon('refresh') + ' Restaurar respaldo</h3></div><div class="card-body">' +
      '<p class="fs-75" style="color:var(--ink-soft);line-height:1.6">Seleccione un archivo JSON generado por SIFAS. La restauración reemplaza la información actual del navegador y queda registrada en la auditoría.</p>' +
      '<input type="file" id="import-file" accept="application/json,.json" class="is-hidden">' +
      '<div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.8rem"><button class="btn btn-secondary" data-import-backup>' + U.icon('save') + 'Seleccionar archivo</button>' +
      '<button class="btn btn-danger-soft" data-reset-db>' + U.icon('trash') + 'Reiniciar datos demo</button></div>' +
      '<p class="hint" style="margin-top:.7rem">El reinicio elimina los cambios locales y vuelve a cargar la semilla de demostración.</p></div></div>' +
      '</div>';
    h += '<div class="card section"><div class="card-head"><h3>' + U.icon('settings') + ' Parámetros del sistema</h3></div><div class="card-body">' +
      '<div class="form-grid">' +
      '<div class="field span-2"><label for="cfg-inst">Institución responsable</label><input class="input" id="cfg-inst" maxlength="140" value="' + U.attr(db.settings.institution || '') + '"></div>' +
      '<div class="field"><label for="cfg-hours">Duración de la sesión (horas)</label><input class="input" id="cfg-hours" type="number" min="1" max="24" value="' + U.attr(db.settings.sessionHours || 8) + '"></div>' +
      '<div class="field"><label for="cfg-exp">Periodo de advertencia de vencimiento</label><input class="input" id="cfg-exp" value="30 días (fijado por RD007)" readonly></div>' +
      '</div>' +
      '<div class="form-actions"><button class="btn btn-primary" data-save-config>' + U.icon('save') + 'Guardar configuración</button></div>' +
      '</div></div>';
    h += '<div class="alert-banner ab-amber">' + U.icon('alert') +
      '<span><strong>Alcance del prototipo.</strong> Los datos se almacenan en <span class="mono">localStorage</span> del navegador. En producción, esta capa se reemplaza por una API REST con PostgreSQL, autenticación centralizada y respaldos programados en servidor.</span></div>';

    return {
      html: h,
      mount: function (root) {
        function exportBackup() {
          var data = Store.exportAll();
          U.download('sifas-respaldo-' + U.dayKey(U.nowISO()) + '.json', JSON.stringify(data, null, 2), 'application/json');
          Store.log(u, 'Respaldo descargado', 'sistema', '—', 'Exportación completa de la base local.', true);
          UI.toast('Respaldo descargado. Conserve el archivo en un lugar seguro.', 'success', 'Copia de seguridad');
        }
        U.on(root, '[data-export-backup]', 'click', exportBackup);
        root.querySelector('[data-export-all-csv]').addEventListener('click', function () {
          downloadCSV('intervenciones-sifas.csv', Store.interventions(), [
            { key: 'code', label: 'Código' }, { key: 'speciesName', label: 'Especie' },
            { key: 'scientificName', label: 'Nombre científico' },
            { key: 'priority', label: 'Prioridad', value: function (r) { return r.priority.level; } },
            { key: 'status', label: 'Estado', value: function (r) { return D.STATUS[r.status].label; } },
            { key: 'agentName', label: 'Agente' }, { key: 'occurredAt', label: 'Fecha', value: function (r) { return U.fmtDate(r.occurredAt); } },
            { key: 'zone', label: 'Zona', value: function (r) { return (r.location && r.location.zone) || ''; } }
          ]);
        });
        root.querySelector('[data-import-backup]').addEventListener('click', function () { root.querySelector('#import-file').click(); });
        root.querySelector('#import-file').addEventListener('change', function () {
          var file = this.files && this.files[0];
          if (!file) return;
          var input = this;
          var reader = new FileReader();
          reader.onerror = function () { UI.toast('No se pudo leer el archivo seleccionado.', 'error'); };
          reader.onload = function () {
            var data;
            try { data = JSON.parse(reader.result); }
            catch (e) { UI.toast('El archivo no contiene un JSON válido.', 'error'); return; }
            UI.confirm({
              title: 'Restaurar respaldo',
              message: 'Se reemplazará toda la información actual por la del archivo. Esta acción no se puede deshacer. ¿Desea continuar?',
              confirmLabel: 'Restaurar', danger: true
            }).then(function (ok) {
              if (!ok) { input.value = ''; return; }
              try {
                Store.importAll(data, u);
                UI.toast('Respaldo restaurado correctamente.', 'success');
                location.hash = '#/app/panel';
                S.App.refresh();
              } catch (e) { UI.toast(e.message, 'error'); }
              input.value = '';
            });
          };
          reader.readAsText(file);
        });
        root.querySelector('[data-reset-db]').addEventListener('click', function () {
          UI.confirm({
            title: 'Reiniciar datos de demostración',
            message: 'Se eliminarán todas las intervenciones, historias clínicas, movimientos y denuncias registradas en este navegador. La semilla de demostración se cargará nuevamente.',
            confirmLabel: 'Reiniciar', danger: true
          }).then(function (ok) {
            if (!ok) return;
            Store.reset();
            UI.toast('Datos de demostración restaurados.', 'success');
            location.hash = '#/app/panel';
            S.App.refresh();
          });
        });
        root.querySelector('[data-save-config]').addEventListener('click', function () {
          var inst = root.querySelector('#cfg-inst').value.trim();
          var hours = U.num(root.querySelector('#cfg-hours').value, 8);
          if (!inst) { UI.toast('Ingrese la institución responsable.', 'error'); return; }
          if (hours < 1 || hours > 24) { UI.toast('La duración de la sesión debe estar entre 1 y 24 horas.', 'error'); return; }
          Store.get().settings.institution = inst;
          Store.get().settings.sessionHours = hours;
          Store.log(u, 'Configuración actualizada', 'sistema', 'parametros', 'Institución y duración de sesión modificadas.', true);
          Store.persist();
          UI.toast('Configuración guardada.', 'success');
        });
      }
    };
  }

  /* ==================================================================
     CATÁLOGO DE ESPECIES (RF015)
     ================================================================== */
  function catalogo() {
    var species = Store.species();
    var u = user();
    var h = pageHead('Catálogo de especies',
      'Especies silvestres protegidas de Junín · información publicada en el portal ciudadano (RF015)',
      '<button class="btn btn-primary" data-new-species>' + U.icon('plus') + 'Nueva especie</button>');
    h += '<div class="grid grid-4 section">' +
      stat('book', 'Especies registradas', species.length, 'Fichas del catálogo regional', '') +
      stat('shield', 'En peligro crítico', species.filter(function (s) { return s.prot === 'CR'; }).length, 'Categoría CR', 'tone-red') +
      stat('leaf', 'Endémicas del Perú', species.filter(function (s) { return s.endemic; }).length, 'Distribución restringida', 'tone-amber') +
      stat('globe', 'Aves', species.filter(function (s) { return s.cat === 'ave'; }).length, 'Fichas de aves protegidas', 'tone-blue') +
      '</div>';
    h += '<div class="card"><div class="card-body"><div class="toolbar">' +
      '<div class="search-box">' + U.icon('search') + '<input class="input" id="cat-q" type="search" placeholder="Buscar por nombre común o científico…" aria-label="Buscar especie"></div>' +
      '<span class="spacer"></span><a class="btn btn-ghost" href="#/especies" target="_blank" rel="noopener">' + U.icon('external') + 'Ver portal público</a>' +
      '<span class="result-count" id="cat-count"></span></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Especie</th><th>Nombre científico</th><th>Categoría</th><th>Protección</th><th>CITES</th><th>Endémica</th><th></th></tr></thead><tbody id="cat-body"></tbody></table></div>' +
      '</div></div>';
    return {
      html: h,
      mount: function (root) {
        var body = root.querySelector('#cat-body'), q = root.querySelector('#cat-q'), count = root.querySelector('#cat-count');
        function draw() {
          var query = U.normalize(q.value);
          var rows = species.filter(function (s) { return !query || U.normalize(s.common + ' ' + s.sci).indexOf(query) >= 0; });
          count.textContent = rows.length + ' especies';
          body.innerHTML = rows.map(function (s) {
            var prot = D.PROTECTION[s.prot] || D.PROTECTION.DD;
            return '<tr><td><div style="display:flex;align-items:center;gap:.55rem"><span style="width:30px;height:30px;border-radius:8px;display:grid;place-items:center;font-size:1.2rem;background:linear-gradient(145deg,' + s.color[0] + ',' + s.color[1] + ')">' + s.emoji + '</span>' +
              '<span class="t-main">' + U.esc(s.common) + '</span></div></td>' +
              '<td class="t-sub" style="font-style:italic">' + U.esc(s.sci) + '</td>' +
              '<td class="t-sub">' + U.esc(s.cat === 'ave' ? 'Ave' : s.cat === 'mamifero' ? 'Mamífero' : s.cat === 'reptil' ? 'Reptil' : 'Anfibio') + '</td>' +
              '<td>' + UI.badge(prot.label, prot.tone) + '</td><td class="t-sub">' + U.esc(s.cites) + '</td>' +
              '<td>' + (s.endemic ? UI.badge('Sí', 'amber') : UI.badge('No', 'gray')) + '</td>' +
              '<td class="t-right"><button class="btn btn-sm btn-soft" data-edit-species="' + U.attr(s.id) + '">' + U.icon('edit') + ' Editar</button></td></tr>';
          }).join('') || '<tr><td colspan="7"><div class="table-empty">' + U.icon('book') + 'No se encontraron especies.</div></td></tr>';
        }
        q.addEventListener('input', U.debounce(draw, 150));
        U.on(root, '[data-edit-species]', 'click', function () { openSpeciesModal(this.getAttribute('data-edit-species')); });
        root.querySelector('[data-new-species]').addEventListener('click', function () { openSpeciesModal(null); });
        draw();
      }
    };
  }

  function openSpeciesModal(id) {
    var editing = id ? Store.findSpecies(id) : null;
    var cats = [{ key: 'mamifero', label: 'Mamífero' }, { key: 'ave', label: 'Ave' }, { key: 'reptil', label: 'Reptil' }, { key: 'anfibio', label: 'Anfibio' }];
    var body = '<div class="form-grid">' +
      '<div class="field"><label for="sp-common">Nombre común <span class="req">*</span></label><input class="input" id="sp-common" maxlength="80" value="' + U.attr(editing ? editing.common : '') + '"></div>' +
      '<div class="field"><label for="sp-sci">Nombre científico <span class="req">*</span></label><input class="input" id="sp-sci" maxlength="100" value="' + U.attr(editing ? editing.sci : '') + '"></div>' +
      '<div class="field"><label for="sp-cat">Categoría</label><select class="select" id="sp-cat">' + cats.map(function (c) {
        return '<option value="' + c.key + '"' + (editing && editing.cat === c.key ? ' selected' : '') + '>' + c.label + '</option>';
      }).join('') + '</select></div>' +
      '<div class="field"><label for="sp-prot">Condición de protección</label><select class="select" id="sp-prot">' +
      Object.keys(D.PROTECTION).map(function (k) { return '<option value="' + k + '"' + (editing && editing.prot === k ? ' selected' : '') + '>' + D.PROTECTION[k].label + ' (' + k + ')</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label for="sp-cites">Apéndice CITES</label><select class="select" id="sp-cites"><option value="—"' + (editing && editing.cites === '—' ? ' selected' : '') + '>—</option><option value="I"' + (editing && editing.cites === 'I' ? ' selected' : '') + '>I</option><option value="II"' + (editing && editing.cites === 'II' ? ' selected' : '') + '>II</option><option value="III"' + (editing && editing.cites === 'III' ? ' selected' : '') + '>III</option></select></div>' +
      '<div class="field"><label for="sp-emoji">Emoji / ícono</label><input class="input" id="sp-emoji" maxlength="4" value="' + U.attr(editing ? editing.emoji : '🐾') + '"></div>' +
      '<div class="field span-2"><label for="sp-habitat">Hábitat</label><textarea class="textarea" id="sp-habitat" maxlength="500">' + U.esc(editing ? editing.habitat : '') + '</textarea></div>' +
      '<div class="field span-2"><label for="sp-chars">Características principales</label><textarea class="textarea" id="sp-chars" maxlength="600">' + U.esc(editing ? editing.chars : '') + '</textarea></div>' +
      '<div class="field"><label for="sp-threats">Amenazas</label><textarea class="textarea" id="sp-threats" maxlength="500">' + U.esc(editing ? editing.threats : '') + '</textarea></div>' +
      '<div class="field"><label for="sp-rec">Recomendaciones al ciudadano</label><textarea class="textarea" id="sp-rec" maxlength="500">' + U.esc(editing ? editing.rec : '') + '</textarea></div>' +
      '<div class="field span-2"><label class="check"><input type="checkbox" id="sp-endemic"' + (editing && editing.endemic ? ' checked' : '') + '> Especie endémica del Perú</label></div>' +
      '</div>';
    var m = UI.modal({
      title: editing ? 'Editar especie' : 'Registrar nueva especie',
      subtitle: editing ? editing.sci : 'Ficha del catálogo público',
      size: 'lg', body: body,
      footer: '<button class="btn btn-secondary" type="button" data-cancel-sp>Cancelar</button>' +
        '<button class="btn btn-primary" type="button" data-save-sp>' + U.icon('save') + 'Guardar ficha</button>'
    });
    m.el.querySelector('[data-cancel-sp]').addEventListener('click', UI.closeModal);
    m.el.querySelector('[data-save-sp]').addEventListener('click', function () {
      var common = m.el.querySelector('#sp-common').value.trim();
      var sci = m.el.querySelector('#sp-sci').value.trim();
      var cat = m.el.querySelector('#sp-cat').value;
      if (!common || !sci) { UI.toast('Complete el nombre común y científico.', 'error'); return; }
      var palette = { mamifero: ['#7b6247', '#33271b'], ave: ['#4e6a74', '#1d2b33'], reptil: ['#6b5a3b', '#241f10'], anfibio: ['#5b6b34', '#222a12'] };
      var data = {
        common: common, sci: sci, cat: cat,
        prot: m.el.querySelector('#sp-prot').value,
        cites: m.el.querySelector('#sp-cites').value,
        emoji: m.el.querySelector('#sp-emoji').value || '🐾',
        color: editing ? editing.color : palette[cat],
        habitat: m.el.querySelector('#sp-habitat').value.trim() || 'Información pendiente de completar.',
        chars: m.el.querySelector('#sp-chars').value.trim() || 'Información pendiente de completar.',
        threats: m.el.querySelector('#sp-threats').value.trim() || 'Información pendiente de completar.',
        rec: m.el.querySelector('#sp-rec').value.trim() || 'Reportar cualquier caso a la ATFFS Sierra Central.',
        endemic: m.el.querySelector('#sp-endemic').checked
      };
      try {
        if (editing) {
          Object.keys(data).forEach(function (k) { editing[k] = data[k]; });
          Store.log(user(), 'Especie actualizada', 'especie', editing.id, editing.common + ' · ' + editing.sci, false);
        } else {
          var slug = U.normalize(common).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'especie';
          var id = 'sp-' + slug;
          var n = 2;
          while (Store.findSpecies(id)) { id = 'sp-' + slug + '-' + n; n++; }
          data.id = id;
          Store.species().push(data);
          Store.log(user(), 'Especie registrada', 'especie', id, common + ' · ' + sci, false);
        }
        Store.persist();
        UI.closeModal();
        UI.toast('El catálogo de especies fue actualizado.', 'success');
        S.App.refresh();
      } catch (e) { UI.toast(e.message, 'error'); }
    });
  }

  /* ==================================================================
     TRAZABILIDAD DE REQUISITOS
     ================================================================== */
  var REQS = [
    { code: 'RF001', type: 'RF', title: 'Autenticación y control de acceso', desc: 'Inicio de sesión, sesión con expiración, bloqueo por intentos fallidos y permisos por rol.', where: '#/login', evidence: 'Módulo de acceso y shell con RBAC', state: 'Implementado' },
    { code: 'RF002', type: 'RF', title: 'Registro de rescates y decomisos', desc: 'Ficha de intervención con código único, especie, condiciones, agente y fecha.', where: '#/app/rescates/nuevo', evidence: 'Asistente de registro en 5 pasos', state: 'Implementado' },
    { code: 'RF003', type: 'RF', title: 'Ubicación GPS automática', desc: 'Captura de coordenadas del dispositivo o selección manual en el mapa.', where: '#/app/rescates/nuevo', evidence: 'Geolocalización + mapa de Huancayo', state: 'Implementado' },
    { code: 'RF004', type: 'RF', title: 'Fotografías como evidencia', desc: 'Carga y compresión de imágenes del animal y del lugar, asociadas a la intervención.', where: '#/app/rescates', evidence: 'Evidencias con fecha y hora', state: 'Implementado' },
    { code: 'RF005', type: 'RF', title: 'Pre-acta digital', desc: 'Documento imprimible con datos, ubicación, triaje y evidencias de la intervención.', where: '#/app/rescates', evidence: 'Pre-acta imprimible y descargable', state: 'Implementado' },
    { code: 'RF006', type: 'RF', title: 'Historia clínica digital', desc: 'Registro de evaluaciones, diagnósticos, tratamientos, vacunas y dietas.', where: '#/app/clinica', evidence: 'Historia clínica con pestañas', state: 'Implementado' },
    { code: 'RF007', type: 'RF', title: 'Seguimiento en cuarentena', desc: 'Controles periódicos con signos vitales, peso y evolución del animal.', where: '#/app/clinica', evidence: 'Controles y evolución graficada', state: 'Implementado' },
    { code: 'RF008', type: 'RF', title: 'Decisión técnica final', desc: 'Liberación, custodia permanente o eutanasia con justificación y validaciones.', where: '#/app/clinica', evidence: 'Modal de decisión con reglas RD005', state: 'Implementado' },
    { code: 'RF009', type: 'RF', title: 'Inventario de insumos', desc: 'Alta de alimentos, medicamentos y herramientas; entradas, salidas e historial.', where: '#/app/inventario', evidence: 'Inventario con trazabilidad de movimientos', state: 'Implementado' },
    { code: 'RF010', type: 'RF', title: 'Alertas de stock y vencimiento', desc: 'Alertas automáticas por stock mínimo y vencimiento dentro de 30 días.', where: '#/app/inventario?tab=alertas', evidence: 'Alertas y notificaciones al responsable', state: 'Implementado' },
    { code: 'RF011', type: 'RF', title: 'Mapa de zonas y carreteras', desc: 'Visualización geográfica de intervenciones y denuncias en Huancayo.', where: '#/app/mapa', evidence: 'Mapa SVG con burbujas por zona', state: 'Implementado' },
    { code: 'RF012', type: 'RF', title: 'Indicadores en tiempo real', desc: 'Rescates, animales en rehabilitación, liberaciones, especies y zonas.', where: '#/app/reportes', evidence: 'Panel y reportes con filtros', state: 'Implementado' },
    { code: 'RF013', type: 'RF', title: 'Denuncia ciudadana anónima', desc: 'Formulario público sin datos personales y código de seguimiento.', where: '#/denunciar', evidence: 'Portal ciudadano y seguimiento', state: 'Implementado' },
    { code: 'RF014', type: 'RF', title: 'Evidencias y ubicación en denuncias', desc: 'Fotografías y ubicación por GPS o mapa asociadas al reporte.', where: '#/denunciar', evidence: 'Carga de fotos y mapa de selección', state: 'Implementado' },
    { code: 'RF015', type: 'RF', title: 'Consulta pública de especies', desc: 'Catálogo informativo con búsqueda, hábitat, amenazas y protección.', where: '#/especies', evidence: 'Catálogo público sin autenticación', state: 'Implementado' },
    { code: 'RD001', type: 'RD', title: 'Identificador único', desc: 'Código ATFFS-HYO-AAAA-NNNN irrepetible por intervención.', where: '#/app/rescates', evidence: 'Generación secuencial y verificación', state: 'Implementado' },
    { code: 'RD002', type: 'RD', title: 'Historia clínica solo para animales registrados', desc: 'No se puede crear una historia sin intervención existente.', where: '#/app/clinica', evidence: 'Validación en Store.addRecord', state: 'Implementado' },
    { code: 'RD003', type: 'RD', title: 'Conservación del historial', desc: 'Los registros previos se conservan y ordenan cronológicamente.', where: '#/app/clinica', evidence: 'Registros inmutables y ordenados', state: 'Implementado' },
    { code: 'RD004', type: 'RD', title: 'Controles de cuarentena', desc: 'Controles asociados al animal con fecha y responsable.', where: '#/app/clinica', evidence: 'Controles con veterinario y fecha', state: 'Implementado' },
    { code: 'RD005', type: 'RD', title: 'Condiciones de la decisión técnica', desc: 'Liberación con alta médica y comportamiento apto; custodia y eutanasia justificadas.', where: '#/app/clinica', evidence: 'Validación de requisitos previos', state: 'Implementado' },
    { code: 'RD006', type: 'RD', title: 'Control de salidas de inventario', desc: 'No se permiten salidas superiores al stock disponible.', where: '#/app/inventario', evidence: 'Validación de stock antes de mover', state: 'Implementado' },
    { code: 'RD007', type: 'RD', title: 'Alerta de vencimiento a 30 días', desc: 'Identificación de productos vencidos o próximos a vencer.', where: '#/app/inventario?tab=alertas', evidence: 'Cálculo de días y alerta automática', state: 'Implementado' },
    { code: 'RD008', type: 'RD', title: 'Denuncia sin identificación', desc: 'Evidencias y ubicación sin exigir datos personales.', where: '#/denunciar', evidence: 'Formulario anónimo sin campos personales', state: 'Implementado' },
    { code: 'RD009', type: 'RD', title: 'Asociación de coordenadas GPS', desc: 'Cada intervención georreferenciada se representa en el mapa.', where: '#/app/mapa', evidence: 'Proyección lat/lng y marcadores', state: 'Implementado' },
    { code: 'RD010', type: 'RD', title: 'Validación del rol Administrador', desc: 'Funciones administrativas restringidas y auditadas.', where: '#/app/usuarios', evidence: 'Guardas de ruta y permisos', state: 'Implementado' },
    { code: 'RD011', type: 'RD', title: 'Triaje clínico de cuatro criterios', desc: 'Puntaje 0–8 con regla de excepción de signos vitales y prioridades I–III.', where: '#/app/rescates/nuevo', evidence: 'Cálculo automático y pruebas unitarias', state: 'Implementado' },
    { code: 'RNF001', type: 'RNF', title: 'Control de acceso por rol', desc: 'Módulos y datos clínicos restringidos; acciones auditadas.', where: '#/app/roles', evidence: 'RBAC, guardas y bitácora', state: 'Implementado' },
    { code: 'RNF002', type: 'RNF', title: 'Protección de información sensible', desc: 'Contraseñas derivadas con sal; denuncias sin identidad; auditoría de accesos.', where: '#/app/auditoria', evidence: 'SHA-256 iterado y bitácora', state: 'Implementado' },
    { code: 'RNF003', type: 'RNF', title: 'Respuesta menor a 3 segundos', desc: 'Operaciones locales y renderizado inmediato en el prototipo.', where: '#/app/pruebas', evidence: 'Pruebas de dominio y operaciones síncronas', state: 'Verificado en prototipo' },
    { code: 'RNF004', type: 'RNF', title: '100 usuarios concurrentes', desc: 'La arquitectura cliente-servidor propuesta separa la interfaz de la API y la base de datos.', where: '#/app/requisitos', evidence: 'Diseño de despliegue institucional', state: 'Depende de infraestructura' },
    { code: 'RNF005', type: 'RNF', title: 'Disponibilidad del 99 % mensual', desc: 'Requiere hosting institucional, monitoreo y mantenimientos programados.', where: '#/app/requisitos', evidence: 'Plan de operación y respaldos', state: 'Depende de infraestructura' },
    { code: 'RNF006', type: 'RNF', title: 'Integridad de la información', desc: 'Registro de autor, fecha y hora; historial clínico conservado; permisos de edición.', where: '#/app/auditoria', evidence: 'Auditoría y registros append-only', state: 'Implementado' },
    { code: 'RNF007', type: 'RNF', title: 'Interfaz adaptable a móviles', desc: 'Diseño responsive con navegación lateral, formularios y mapa táctil.', where: '#/app/rescates/nuevo', evidence: 'CSS responsive y controles accesibles', state: 'Implementado' }
  ];

  function requisitos() {
    var u = user();
    var counts = { RF: 0, RD: 0, RNF: 0, total: REQS.length };
    REQS.forEach(function (r) { counts[r.type]++; });
    var implemented = REQS.filter(function (r) { return r.state === 'Implementado' || r.state === 'Verificado en prototipo'; }).length;
    var h = pageHead('Trazabilidad de requisitos',
      'Correspondencia entre el informe del proyecto y las funcionalidades implementadas · RF, RD y RNF',
      '<a class="btn btn-secondary" href="#/app/pruebas">' + U.icon('checkCircle') + 'Ejecutar pruebas</a>' +
      '<button class="btn btn-primary" data-print-req>' + U.icon('print') + 'Imprimir matriz</button>');
    h += '<div class="grid grid-4 section">' +
      stat('file', 'Requisitos cubiertos', counts.total, 'RF, RD y RNF del informe', '') +
      stat('checkCircle', 'Implementados', implemented, 'Con evidencia funcional en la aplicación', 'tone-blue') +
      stat('paw', 'Funcionales', counts.RF, 'RF001 – RF015', 'tone-amber') +
      stat('scale', 'Reglas de dominio', counts.RD, 'RD001 – RD011', 'tone-purple') +
      '</div>';
    h += '<div class="alert-banner ab-green">' + U.icon('checkCircle') +
      '<span><strong>Cobertura verificable.</strong> Cada requisito enlaza al módulo que lo implementa. Las reglas de dominio cuentan además con pruebas automatizadas en <a href="#/app/pruebas">Pruebas del sistema</a>.</span></div>';
    h += '<div class="card"><div class="card-body"><div class="toolbar">' +
      '<div class="search-box">' + U.icon('search') + '<input class="input" id="req-q" type="search" placeholder="Buscar por código o descripción…" aria-label="Buscar requisito"></div>' +
      '<div class="btn-group" id="req-filter"><button type="button" class="active" data-rtype="">Todos</button><button type="button" data-rtype="RF">RF</button><button type="button" data-rtype="RD">RD</button><button type="button" data-rtype="RNF">RNF</button></div>' +
      '<span class="spacer"></span><span class="result-count" id="req-count"></span></div>' +
      '<div class="table-wrap"><table class="tbl req-table"><thead><tr><th>Código</th><th>Requisito</th><th>Implementación</th><th>Evidencia</th><th>Estado</th><th></th></tr></thead><tbody id="req-body"></tbody></table></div>' +
      '</div></div>';
    h += '<div class="card section"><div class="card-head"><h3>' + U.icon('info') + ' Arquitectura y alcance</h3></div><div class="card-body fs-75" style="color:var(--ink-soft);line-height:1.7">' +
      '<p style="margin:0 0 .6rem"><strong>Capa de presentación:</strong> aplicación web SPA en HTML5, CSS3 y JavaScript sin dependencias externas, con navegación por hash, componentes accesibles y diseño adaptable.</p>' +
      '<p style="margin:0 0 .6rem"><strong>Capa de dominio:</strong> reglas RD001–RD011 implementadas como funciones puras y validadas antes de cada operación; pruebas automatizadas ejecutables desde el módulo de pruebas.</p>' +
      '<p style="margin:0 0 .6rem"><strong>Capa de datos:</strong> en el prototipo se usa <span class="mono">localStorage</span> con respaldo/restauración JSON. En producción se reemplaza por una API REST sobre PostgreSQL, con autenticación centralizada, control de concurrencia y respaldos programados.</p>' +
      '<p style="margin:0"><strong>Seguridad:</strong> contraseñas con SHA-256 iterado (6 000 rondas) y sal aleatoria, sesión con expiración, bloqueo temporal por intentos fallidos y auditoría de accesos a información sensible.</p>' +
      '</div></div>';
    return {
      html: h,
      mount: function (root) {
        Store.log(u, 'Consulta de trazabilidad de requisitos', 'reporte', 'requisitos', 'Acceso a la matriz RF/RD/RNF.', false);
        var body = root.querySelector('#req-body'), q = root.querySelector('#req-q'), count = root.querySelector('#req-count');
        var rtype = '';
        function draw() {
          var query = U.normalize(q.value);
          var rows = REQS.filter(function (r) {
            return (!rtype || r.type === rtype) && (!query || U.normalize(r.code + ' ' + r.title + ' ' + r.desc).indexOf(query) >= 0);
          });
          count.textContent = rows.length + ' de ' + REQS.length + ' requisitos';
          body.innerHTML = rows.map(function (r) {
            var tone = r.state === 'Implementado' ? 'green' : r.state === 'Verificado en prototipo' ? 'blue' : 'amber';
            return '<tr><td><span class="req-id">' + U.esc(r.code) + '</span></td>' +
              '<td><div class="t-main">' + U.esc(r.title) + '</div><div class="t-sub" style="max-width:420px">' + U.esc(r.desc) + '</div></td>' +
              '<td class="t-sub" style="max-width:300px">' + U.esc(r.evidence) + '</td>' +
              '<td><a class="btn btn-sm btn-ghost" href="' + U.attr(r.where) + '">' + U.icon('external') + 'Ver módulo</a></td>' +
              '<td>' + UI.badge(r.state, tone) + '</td>' +
              '<td class="t-sub">' + (r.type === 'RF' ? 'Funcional' : r.type === 'RD' ? 'Dominio' : 'No funcional') + '</td></tr>';
          }).join('') || '<tr><td colspan="6"><div class="table-empty">' + U.icon('search') + 'No se encontraron requisitos.</div></td></tr>';
        }
        q.addEventListener('input', U.debounce(draw, 140));
        U.on(root, '#req-filter [data-rtype]', 'click', function () {
          rtype = this.getAttribute('data-rtype');
          U.$$('#req-filter [data-rtype]', root).forEach(function (b) { b.classList.toggle('active', b === this); }, this);
          draw();
        });
        root.querySelector('[data-print-req]').addEventListener('click', function () { window.print(); });
        draw();
      }
    };
  }

  Views.admin = {
    mapa: mapa, reportes: reportes, denuncias: denuncias, usuarios: usuarios,
    roles: roles, auditoria: auditoria, respaldo: respaldo, catalogo: catalogo,
    requisitos: requisitos, openDenunciaModal: openDenunciaModal, openUserModal: openUserModal,
    REQS: REQS
  };
})(typeof window !== 'undefined' ? window : this);

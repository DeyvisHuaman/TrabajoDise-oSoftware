/* Gráficos SVG sin dependencias externas. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util;

  function barList(data, opts) {
    opts = opts || {};
    var max = Math.max.apply(null, data.map(function (d) { return U.num(d.value); }).concat([1]));
    if (!data.length) return '<p class="text-muted fs-75" style="padding:.4rem 0">Sin datos para mostrar.</p>';
    return data.map(function (d) {
      var pct = Math.max(2, Math.round((U.num(d.value) / max) * 100));
      var color = d.color || opts.color || '#1b7a56';
      return '<div class="bar-row">' +
        '<span class="br-label" title="' + U.attr(d.label) + '">' + U.esc(d.label) + '</span>' +
        '<span class="br-track"><span class="br-fill" style="width:' + pct + '%;background:' + color + '"></span></span>' +
        '<span class="br-val">' + U.esc(d.value) + '</span>' +
        '</div>';
    }).join('');
  }

  function donut(data, opts) {
    opts = opts || {};
    var size = opts.size || 132;
    var thickness = opts.thickness || 15;
    var total = data.reduce(function (a, d) { return a + U.num(d.value); }, 0);
    var r = (size / 2) - thickness / 2 - 1;
    var c = 2 * Math.PI * r;
    var offset = 0;
    var circles = '';
    if (!total) {
      circles = '<circle cx="' + (size / 2) + '" cy="' + (size / 2) + '" r="' + r + '" fill="none" stroke="#eef1ed" stroke-width="' + thickness + '"/>';
    } else {
      data.forEach(function (d) {
        var frac = U.num(d.value) / total;
        var dash = frac * c;
        circles += '<circle cx="' + (size / 2) + '" cy="' + (size / 2) + '" r="' + r + '" fill="none" stroke="' + (d.color || '#1b7a56') +
          '" stroke-width="' + thickness + '" stroke-dasharray="' + dash + ' ' + (c - dash) + '" stroke-dashoffset="' + (-offset) +
          '" transform="rotate(-90 ' + (size / 2) + ' ' + (size / 2) + ')" stroke-linecap="butt"/>';
        offset += dash;
      });
    }
    var center = '<text x="50%" y="48%" text-anchor="middle" font-size="' + (size * 0.2) + '" font-weight="800" fill="#152420">' + (opts.centerValue !== undefined ? opts.centerValue : total) + '</text>' +
      '<text x="50%" y="62%" text-anchor="middle" font-size="' + (size * 0.077) + '" fill="#65776f" font-weight="600">' + U.esc(opts.centerLabel || 'total') + '</text>';
    var legend = data.map(function (d) {
      return '<div class="dl"><i style="background:' + (d.color || '#1b7a56') + '"></i><span>' + U.esc(d.label) + '</span><b>' + U.esc(d.value) + '</b></div>';
    }).join('');
    return '<div style="display:flex;gap:1.1rem;align-items:center;flex-wrap:wrap">' +
      '<svg viewBox="0 0 ' + size + ' ' + size + '" width="' + size + '" height="' + size + '" role="img" aria-label="' + U.attr(opts.aria || 'Gráfico circular') + '">' + circles + center + '</svg>' +
      '<div class="donut-legend" style="flex:1;min-width:120px">' + legend + '</div></div>';
  }

  function lineChart(series, opts) {
    opts = opts || {};
    var width = 680, height = opts.height || 210;
    var padL = 34, padR = 12, padT = 14, padB = 30;
    var all = series.reduce(function (acc, s) { return acc.concat(s.points || []); }, []);
    if (!all.length) return '<p class="text-muted fs-75" style="padding:.6rem 0">Aún no hay datos suficientes para graficar la evolución.</p>';
    var values = all.map(function (p) { return U.num(p.value); });
    var min = Math.min.apply(null, values), max = Math.max.apply(null, values);
    if (min === max) { min = Math.max(0, min - 1); max = max + 1; }
    var span = max - min;
    var innerW = width - padL - padR, innerH = height - padT - padB;
    var count = Math.max.apply(null, series.map(function (s) { return (s.points || []).length; }));
    function x(i) { return padL + (count <= 1 ? innerW / 2 : (i / (count - 1)) * innerW); }
    function y(v) { return padT + innerH - ((U.num(v) - min) / span) * innerH; }
    var grid = '';
    for (var g = 0; g <= 3; g++) {
      var gy = padT + (innerH / 3) * g;
      var val = max - (span / 3) * g;
      grid += '<line x1="' + padL + '" y1="' + gy + '" x2="' + (width - padR) + '" y2="' + gy + '" stroke="#e8ece8" stroke-width="1"/>' +
        '<text x="' + (padL - 7) + '" y="' + (gy + 3.5) + '" text-anchor="end" font-size="9" fill="#8a9992">' + U.round(val, 1) + '</text>';
    }
    var body = '';
    series.forEach(function (s) {
      var pts = s.points || [];
      if (!pts.length) return;
      var color = s.color || '#1b7a56';
      var coords = pts.map(function (p, i) { return [x(i), y(p.value)]; });
      var line = coords.map(function (pt, i) { return (i ? 'L' : 'M') + U.round(pt[0], 1) + ' ' + U.round(pt[1], 1); }).join(' ');
      var area = line + ' L' + U.round(coords[coords.length - 1][0], 1) + ' ' + (padT + innerH) + ' L' + U.round(coords[0][0], 1) + ' ' + (padT + innerH) + ' Z';
      if (opts.area !== false) {
        body += '<path d="' + area + '" fill="' + color + '" opacity=".09"/>';
      }
      body += '<path d="' + line + '" fill="none" stroke="' + color + '" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>';
      coords.forEach(function (pt, i) {
        body += '<circle cx="' + U.round(pt[0], 1) + '" cy="' + U.round(pt[1], 1) + '" r="3.2" fill="#fff" stroke="' + color + '" stroke-width="2"><title>' +
          U.esc(U.fmtDate(pts[i].ts) + ': ' + pts[i].value) + '</title></circle>';
      });
    });
    var labels = '';
    var ref = series[0].points || [];
    var step = Math.ceil(ref.length / 6);
    ref.forEach(function (p, i) {
      if (i % step !== 0 && i !== ref.length - 1) return;
      labels += '<text x="' + U.round(x(i), 1) + '" y="' + (height - 9) + '" text-anchor="middle" font-size="9" fill="#8a9992">' + U.esc(U.fmtShort(p.ts).slice(0, 5)) + '</text>';
    });
    var legend = series.length > 1 ? '<div class="pill-row" style="margin-top:.4rem">' + series.map(function (s) {
      return '<span class="chip"><i class="dotp" style="background:' + (s.color || '#1b7a56') + '"></i>' + U.esc(s.label) + '</span>';
    }).join('') + '</div>' : (series[0].label ? '<div class="hint" style="margin-top:.3rem">' + U.esc(series[0].label) + '</div>' : '');
    return '<div class="chart-wrap">' +
      '<svg viewBox="0 0 ' + width + ' ' + height + '" role="img" aria-label="' + U.attr(opts.aria || 'Gráfico de evolución') + '">' +
      grid + body + labels + '</svg>' + legend + '</div>';
  }

  function sparkline(values, opts) {
    opts = opts || {};
    if (!values.length) return '';
    var w = opts.width || 120, h = opts.height || 32;
    var min = Math.min.apply(null, values), max = Math.max.apply(null, values);
    var span = max - min || 1;
    var pts = values.map(function (v, i) {
      var x = (i / Math.max(1, values.length - 1)) * (w - 4) + 2;
      var y = h - 3 - ((v - min) / span) * (h - 6);
      return U.round(x, 1) + ',' + U.round(y, 1);
    }).join(' ');
    return '<svg viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h + '" aria-hidden="true"><polyline points="' + pts +
      '" fill="none" stroke="' + (opts.color || '#2a9169') + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  }

  function statusBar(segments, opts) {
    opts = opts || {};
    var total = segments.reduce(function (a, s) { return a + U.num(s.value); }, 0);
    if (!total) return '<div class="br-track" style="height:10px"><span class="br-fill" style="width:100%;background:#eef1ed"></span></div>';
    return '<div style="display:flex;height:10px;border-radius:99px;overflow:hidden;background:#eef1ed">' +
      segments.map(function (s) {
        return '<span title="' + U.attr(s.label + ': ' + s.value) + '" style="width:' + (U.num(s.value) / total * 100) + '%;background:' + (s.color || '#1b7a56') + '"></span>';
      }).join('') + '</div>' +
      '<div class="pill-row" style="margin-top:.55rem">' + segments.map(function (s) {
        return '<span class="chip"><i class="dotp" style="background:' + (s.color || '#1b7a56') + '"></i>' + U.esc(s.label) + ' <b>' + U.esc(s.value) + '</b></span>';
      }).join('') + '</div>';
  }

  S.Charts = { barList: barList, donut: donut, line: lineChart, sparkline: sparkline, statusBar: statusBar };
})(typeof window !== 'undefined' ? window : this);

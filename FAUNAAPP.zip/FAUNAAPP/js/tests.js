/* Pruebas automatizadas de reglas de dominio, seguridad y permisos.
   Se ejecutan sobre funciones puras y datos de solo lectura: no modifican
   la información registrada. RD001–RD011 · RNF001, RNF002, RNF006. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util, D = S.Domain, Store = S.Store, H = S.Hash, UI = S.UI, Auth = S.Auth;

  function assert(condition, message) {
    if (!condition) throw new Error(message || 'La condición esperada no se cumple.');
  }
  function assertEqual(actual, expected, message) {
    if (actual !== expected) {
      throw new Error((message || 'Valor incorrecto') + ' — esperado: ' + expected + ', obtenido: ' + actual + '.');
    }
  }
  function now() {
    return (global.performance && global.performance.now) ? global.performance.now() : Date.now();
  }

  function run() {
    var results = [];
    var started = now();

    function test(code, name, fn, detail) {
      var t0 = now();
      try {
        var extra = fn();
        results.push({
          code: code, name: name, ok: true,
          detail: typeof extra === 'string' ? extra : (detail || 'Comportamiento conforme a la regla.'),
          ms: Math.max(0, Math.round((now() - t0) * 100) / 100)
        });
      } catch (e) {
        results.push({
          code: code, name: name, ok: false,
          detail: e && e.message ? e.message : 'Error no identificado.',
          ms: Math.max(0, Math.round((now() - t0) * 100) / 100)
        });
      }
    }

    /* ---------------- RD001 ---------------- */
    test('RD001', 'Código único por intervención', function () {
      var codes = Store.interventions().map(function (i) { return i.code; });
      var unique = U.unique(codes);
      assertEqual(unique.length, codes.length, 'Existen códigos duplicados');
      codes.forEach(function (c) {
        assert(/^ATFFS-HYO-\d{4}-\d{4}$/.test(c), 'Formato de código inválido: ' + c);
      });
      var next = Store.nextInterventionCode();
      assert(codes.indexOf(next) < 0, 'El siguiente código ya existe: ' + next);
      return codes.length + ' códigos verificados; el siguiente es ' + next + '.';
    });

    /* ---------------- RD002 ---------------- */
    test('RD002', 'Historia clínica solo para animales registrados', function () {
      var records = Store.get().clinicalRecords;
      records.forEach(function (r) {
        assert(!!Store.intervention(r.interventionId), 'Registro huérfano: ' + r.id);
      });
      var rejected = false;
      try {
        Store.addRecord('int-inexistente', {
          type: 'evaluacion', diagnosis: 'Prueba de regla',
          vitals: { fc: 80, fr: 20, temp: 37.5 }
        }, { id: 'test', name: 'Prueba', role: 'vet' });
      } catch (e) { rejected = /no registrado|no existe|No se puede/i.test(e.message); }
      assert(rejected, 'El sistema permitió crear una historia para un animal inexistente');
      return records.length + ' registros clínicos asociados; alta inexistente rechazada.';
    });

    /* ---------------- RD003 ---------------- */
    test('RD003', 'Conservación y orden cronológico del historial', function () {
      var checked = 0;
      Store.interventions().forEach(function (i) {
        var recs = Store.recordsFor(i.id);
        for (var k = 1; k < recs.length; k++) {
          assert(new Date(recs[k - 1].ts) <= new Date(recs[k].ts), 'Historial desordenado en ' + i.code);
        }
        recs.forEach(function (r) {
          assert(!!r.vetId && !!r.vetName && !!r.ts, 'Registro sin responsable o fecha en ' + i.code);
          checked++;
        });
      });
      return checked + ' registros clínicos conservados, ordenados y atribuidos.';
    });

    /* ---------------- RD004 ---------------- */
    test('RD004', 'Controles de cuarentena asociados al animal', function () {
      var inCare = Store.interventions().filter(D.isInCare);
      var controls = 0;
      inCare.forEach(function (i) {
        Store.recordsFor(i.id).forEach(function (r) {
          if (r.type === 'control') {
            assert(r.interventionId === i.id, 'Control mal asociado en ' + i.code);
            assert(!!r.ts && !!r.vetName, 'Control sin fecha o responsable en ' + i.code);
            controls++;
          }
        });
      });
      return controls + ' controles de cuarentena verificados en ' + inCare.length + ' animales en atención.';
    });

    /* ---------------- RD005 ---------------- */
    test('RD005', 'Condiciones de la decisión técnica', function () {
      var blocked = D.decisionAvailability({ status: 'en_cuarentena', decisionId: null }, []);
      assertEqual(blocked.liberacion.enabled, false, 'Liberación habilitada sin alta médica');
      assertEqual(blocked.custodia.enabled, true, 'Custodia debería estar habilitada');
      assertEqual(blocked.eutanasia.enabled, true, 'Eutanasia debería estar habilitada');
      var ready = D.decisionAvailability({ status: 'en_cuarentena', decisionId: null }, [
        { discharge: true, behaviorApt: true }
      ]);
      assertEqual(ready.liberacion.enabled, true, 'Liberación no habilitada con requisitos completos');
      assertEqual(D.validateDecision('liberacion', { releaseDate: '2026-01-01', releasePlace: 'Reserva', justification: 'Cumple requisitos clínicos.' }).ok, true, 'Liberación válida rechazada');
      assertEqual(D.validateDecision('liberacion', { releaseDate: '', releasePlace: '', justification: '' }).ok, false, 'Liberación incompleta aceptada');
      assertEqual(D.validateDecision('custodia', { destination: '', justification: 'Traslado por impronta.' }).ok, false, 'Custodia sin destino aceptada');
      assertEqual(D.validateDecision('eutanasia', { justification: '' }).ok, false, 'Eutanasia sin justificación aceptada');
      var finalized = D.decisionAvailability({ status: 'liberado', decisionId: 'dec-1' }, [{ discharge: true, behaviorApt: true }]);
      assertEqual(finalized.liberacion.enabled, false, 'Se habilitó una segunda decisión');
      return 'Liberación bloqueada sin alta/conducta apta; custodia y eutanasia exigen justificación.';
    });

    /* ---------------- RD006 ---------------- */
    test('RD006', 'Salidas de inventario sin sobrestock', function () {
      assertEqual(D.validateExit(10, 11).ok, false, 'Se permitió una salida mayor al stock');
      assertEqual(D.validateExit(10, 10).ok, true, 'Se rechazó una salida igual al stock');
      assertEqual(D.validateExit(10, 0).ok, false, 'Se permitió una salida de cero');
      assertEqual(D.validateExit(10, -2).ok, false, 'Se permitió una cantidad negativa');
      return 'Validación de stock disponible, cantidades positivas y saldo suficiente.';
    });

    /* ---------------- RD007 ---------------- */
    test('RD007', 'Alerta de vencimiento dentro de 30 días', function () {
      var soon = U.addDays(new Date(), 10).toISOString();
      var expired = U.addDays(new Date(), -1).toISOString();
      var far = U.addDays(new Date(), 90).toISOString();
      assertEqual(D.expiryStatus(soon).state, 'por_vencer', 'No se detectó un producto próximo a vencer');
      assertEqual(D.expiryStatus(expired).state, 'vencido', 'No se detectó un producto vencido');
      assertEqual(D.expiryStatus(far).state, 'ok', 'Se alertó un producto fuera del periodo');
      assertEqual(D.expiryStatus(null).state, 'sin', 'Fecha nula mal clasificada');
      var alerts = D.inventoryAlerts(Store.items());
      assert(Array.isArray(alerts), 'Las alertas de inventario no se generaron');
      return 'Periodo de advertencia de 30 días y detección de vencidos verificados.';
    });

    /* ---------------- RD008 ---------------- */
    test('RD008', 'Denuncia anónima sin datos personales', function () {
      var forbidden = ['name', 'nombre', 'email', 'correo', 'phone', 'telefono', 'document', 'dni', 'userId', 'reporter'];
      Store.denuncias().forEach(function (d) {
        forbidden.forEach(function (k) {
          assert(!(k in d), 'La denuncia ' + d.code + ' contiene el campo personal "' + k + '"');
        });
        assert(/^DEN-\d{4}-\d{4}$/.test(d.code), 'Código de denuncia inválido: ' + d.code);
        assert(!!d.description && d.description.length >= 20, 'Denuncia sin descripción suficiente');
      });
      return Store.denuncias().length + ' denuncias verificadas sin campos de identificación ciudadana.';
    });

    /* ---------------- RD009 ---------------- */
    test('RD009', 'Coordenadas GPS asociadas y proyectables', function () {
      var points = Store.interventions().filter(function (i) { return i.location && i.location.lat !== null && i.location.lat !== undefined && i.location.lng !== null && i.location.lng !== undefined && isFinite(i.location.lat) && isFinite(i.location.lng); });
      points.forEach(function (i) {
        var b = S.Map.BOUNDS;
        assert(i.location.lat >= b.minLat && i.location.lat <= b.maxLat, 'Latitud fuera del ámbito de Huancayo en ' + i.code);
        assert(i.location.lng >= b.minLng && i.location.lng <= b.maxLng, 'Longitud fuera del ámbito de Huancayo en ' + i.code);
        var p = S.Map.project(i.location.lat, i.location.lng);
        assert(isFinite(p.x) && isFinite(p.y), 'Proyección inválida en ' + i.code);
      });
      return points.length + ' puntos georreferenciados dentro del ámbito y proyectables al mapa.';
    });

    /* ---------------- RD010 / RNF001 ---------------- */
    test('RD010', 'Restricción de funciones administrativas', function () {
      assertEqual(Store.can('admin', 'users.manage'), true, 'El Administrador no puede gestionar usuarios');
      assertEqual(Store.can('admin', 'roles.manage'), true, 'El Administrador no puede gestionar roles');
      assertEqual(Store.can('vet', 'users.manage'), false, 'Un veterinario puede gestionar usuarios');
      assertEqual(Store.can('vet', 'roles.manage'), false, 'Un veterinario puede gestionar roles');
      assertEqual(Store.can('field', 'audit.view'), false, 'Un agente de campo puede ver la auditoría');
      assertEqual(Store.can('logistics', 'settings.manage'), false, 'Logística puede modificar la configuración');
      assertEqual(Store.can('logistics', 'inventory.manage'), true, 'Logística no puede gestionar inventario');
      assertEqual(Store.can('field', 'rescates.create'), true, 'El agente de campo no puede registrar rescates');
      assertEqual(Store.can('vet', 'clinical.edit'), true, 'El veterinario no puede editar la historia clínica');
      return 'Permisos administrativos denegados a roles operativos; permisos propios habilitados.';
    });

    /* ---------------- RD011 ---------------- */
    test('RD011', 'Regla de triaje clínico de cuatro criterios', function () {
      function level(c) { return D.triage(c).level; }
      assertEqual(level({ signs: 2, lesions: 0, response: 0, mobility: 0 }), 'I', 'Regla de excepción de signos vitales');
      assertEqual(level({ signs: 1, lesions: 2, response: 1, mobility: 1 }), 'I', 'Total 5 debe ser Prioridad I');
      assertEqual(level({ signs: 1, lesions: 1, response: 0, mobility: 0 }), 'II', 'Total 2 debe ser Prioridad II');
      assertEqual(level({ signs: 1, lesions: 0, response: 1, mobility: 0 }), 'II', 'Total 2 debe ser Prioridad II');
      assertEqual(level({ signs: 0, lesions: 0, response: 0, mobility: 1 }), 'III', 'Total 1 debe ser Prioridad III');
      assertEqual(level({ signs: 0, lesions: 0, response: 0, mobility: 0 }), 'III', 'Total 0 debe ser Prioridad III');
      assertEqual(level({ signs: 2, lesions: 2, response: 2, mobility: 2 }), 'I', 'Total 8 debe ser Prioridad I');
      assertEqual(D.triage({ signs: 3, lesions: 0, response: 0, mobility: 0 }).valid, false, 'Puntaje fuera de escala aceptado');
      assertEqual(D.triage({ signs: 1, lesions: 1, response: 1, mobility: 1 }).score, 4, 'Suma de criterios incorrecta');
      return 'Excepción de signos vitales, rangos 5–8 / 2–4 / 0–1 y validación de escala verificados.';
    });

    /* ---------------- RNF002 ---------------- */
    test('RNF002', 'Contraseñas resguardadas y auditoría sensible', function () {
      Store.users().forEach(function (u) {
        assert(!!u.passHash && u.passHash.indexOf('sha256i$') === 0, 'Hash de contraseña inválido para ' + u.email);
        assertEqual(u.passHash.split('$').length, 4, 'Formato de hash incorrecto para ' + u.email);
        assert(u.passHash.indexOf('Admin2026!') < 0 && u.passHash.indexOf('Clinica2026!') < 0, 'Se almacenó una contraseña en texto plano');
      });
      assertEqual(H.verifyPassword('Admin2026!', Store.findUserByEmail('admin@serfor.gob.pe').passHash), true, 'No se pudo verificar la contraseña de demostración');
      assertEqual(H.verifyPassword('incorrecta', Store.findUserByEmail('admin@serfor.gob.pe').passHash), false, 'Se aceptó una contraseña incorrecta');
      var h1 = H.hashPassword('Fauna2026!');
      var h2 = H.hashPassword('Fauna2026!');
      assert(h1 !== h2, 'Dos hashes de la misma contraseña son iguales: falta sal aleatoria');
      var sensitive = Store.get().audit.filter(function (l) { return l.sensitive; });
      assert(sensitive.length > 0, 'No existen eventos sensibles auditados');
      sensitive.slice(0, 20).forEach(function (l) {
        assert(!!l.userId && !!l.userName && !!l.ts, 'Evento de auditoría incompleto');
      });
      return Store.users().length + ' contraseñas derivadas con sal; ' + sensitive.length + ' eventos sensibles auditados.';
    });

    /* ---------------- RNF001 ---------------- */
    test('RNF001', 'Matriz de permisos por rol', function () {
      Object.keys(D.ROLE_DEFS).forEach(function (role) {
        var perms = role === 'admin' ? D.PERMISSIONS.map(function (p) { return p.key; }) : Store.permissionsFor(role);
        assert(Array.isArray(perms), 'Permisos no definidos para ' + role);
        perms.forEach(function (p) {
          assert(D.PERMISSIONS.some(function (x) { return x.key === p; }), 'Permiso desconocido en ' + role + ': ' + p);
        });
      });
      assertEqual(Store.permissionsFor('admin').length, D.PERMISSIONS.length, 'El Administrador no tiene todos los permisos');
      return 'Roles y permisos consistentes con el catálogo del sistema.';
    });

    /* ---------------- RNF006 ---------------- */
    test('RNF006', 'Integridad y trazabilidad de modificaciones', function () {
      var logs = Store.get().audit;
      assert(logs.length > 0, 'La bitácora está vacía');
      logs.slice(0, 30).forEach(function (l) {
        assert(!!l.action && !!l.userName && !!l.ts, 'Evento sin acción, responsable o fecha');
      });
      Store.interventions().slice(0, 20).forEach(function (i) {
        assert(Array.isArray(i.history) && i.history.length > 0, 'Intervención sin historial: ' + i.code);
        i.history.forEach(function (h) {
          assert(!!h.ts && !!h.userName && !!h.action, 'Entrada de historial incompleta en ' + i.code);
        });
      });
      return logs.length + ' eventos auditados y ' + Store.interventions().length + ' intervenciones con historial.';
    });

    /* ---------------- Política de contraseñas ---------------- */
    test('RNF002', 'Política de contraseñas seguras', function () {
      assertEqual(D.validatePassword('abc').ok, false, 'Se aceptó una contraseña débil');
      assertEqual(D.validatePassword('debil123').ok, false, 'Se aceptó una contraseña sin mayúscula ni símbolo');
      assertEqual(D.validatePassword('Fauna2026!').ok, true, 'Se rechazó una contraseña válida');
      var check = D.validatePassword('Fauna2026!');
      assert(check.score >= 3, 'La fortaleza calculada es demasiado baja');
      return 'Longitud mínima, mayúscula, minúscula, número y símbolo verificados.';
    });

    /* ---------------- RNF003 ---------------- */
    test('RNF003', 'Tiempo de respuesta de operaciones principales', function () {
      var t0 = now();
      Store.interventions();
      Store.stats();
      Store.items();
      Store.denuncias();
      Store.get().audit.slice(0, 100);
      var elapsed = now() - t0;
      assert(elapsed < 3000, 'Las consultas principales tardaron ' + Math.round(elapsed) + ' ms');
      return 'Consultas de panel, inventario, denuncias y auditoría en ' + (Math.round(elapsed * 100) / 100) + ' ms.';
    });

    /* ---------------- RNF007 ---------------- */
    test('RNF007', 'Interfaz adaptable a dispositivos móviles', function () {
      var viewport = document.querySelector('meta[name="viewport"]');
      assert(!!viewport, 'No se declaró el viewport para dispositivos móviles');
      assert(/width=device-width/i.test(viewport.getAttribute('content') || ''), 'El viewport no es adaptable');
      var sheets = Array.prototype.slice.call(document.styleSheets || []);
      var responsive = sheets.some(function (sheet) {
        try {
          return Array.prototype.some.call(sheet.cssRules || [], function (rule) {
            return rule.type === 4 || (rule.media && /max-width/.test(rule.conditionText || rule.media.mediaText || ''));
          });
        } catch (e) { return false; }
      });
      assert(responsive, 'No se detectaron reglas de diseño responsive');
      return 'Viewport móvil y reglas responsive detectadas en la hoja de estilos.';
    });

    var passed = results.filter(function (r) { return r.ok; }).length;
    var failed = results.length - passed;
    return {
      results: results, passed: passed, failed: failed, total: results.length,
      ms: Math.round((now() - started) * 100) / 100,
      ts: U.nowISO()
    };
  }

  /* ==================================================================
     Vista del módulo de pruebas
     ================================================================== */
  function page() {
    var h = '<div class="page-head"><div class="ph-text"><h1>Pruebas del sistema</h1>' +
      '<div class="sub">Verificación automatizada de reglas de dominio, seguridad y permisos · no modifica los datos</div></div>' +
      '<div class="ph-actions"><button class="btn btn-secondary" id="test-export">' + U.icon('download') + 'Exportar resultados</button>' +
      '<button class="btn btn-primary" id="test-run">' + U.icon('refresh') + 'Ejecutar pruebas</button></div></div>' +
      '<div id="test-summary" class="test-summary"></div>' +
      '<div class="grid grid-4 section" id="test-kpis"></div>' +
      '<div class="card"><div class="card-head"><h3>' + U.icon('checkCircle') + ' Resultados por regla</h3>' +
      '<span class="hint" style="margin-left:auto" id="test-stamp"></span></div><div class="card-body" id="test-results">' +
      '<p class="hint">Presione «Ejecutar pruebas» para verificar las reglas del sistema.</p></div></div>' +
      '<div class="alert-banner ab-blue mt-2">' + U.icon('info') +
      '<span><strong>Alcance.</strong> Las pruebas trabajan con funciones puras y datos de solo lectura. Los casos de escritura se limitan a operaciones que deben ser rechazadas antes de modificar el almacenamiento.</span></div>';

    return {
      html: h,
      mount: function (root) {
        var summary = root.querySelector('#test-summary');
        var kpis = root.querySelector('#test-kpis');
        var resultsBox = root.querySelector('#test-results');
        var stamp = root.querySelector('#test-stamp');
        var last = null;

        function render(res) {
          last = res;
          summary.innerHTML = '<div class="test-stat"><div class="tsv" style="color:var(--green-700)">' + res.passed + '</div><div class="tsl">Pruebas aprobadas</div></div>' +
            '<div class="test-stat"><div class="tsv" style="color:' + (res.failed ? 'var(--red-700)' : 'var(--muted)') + '">' + res.failed + '</div><div class="tsl">Pruebas fallidas</div></div>' +
            '<div class="test-stat"><div class="tsv">' + res.total + '</div><div class="tsl">Total ejecutadas</div></div>' +
            '<div class="test-stat"><div class="tsv">' + res.ms + ' ms</div><div class="tsl">Tiempo total</div></div>';
          kpis.innerHTML =
            ViewsStat('checkCircle', 'Cobertura', Math.round((res.passed / res.total) * 100) + '%', 'Casos aprobados sobre el total', '') +
            ViewsStat('scale', 'Reglas de dominio', res.results.filter(function (r) { return /^RD/.test(r.code); }).length, 'RD001 – RD011', 'tone-amber') +
            ViewsStat('shield', 'Seguridad y permisos', res.results.filter(function (r) { return /^RNF/.test(r.code); }).length, 'RNF001, RNF002, RNF006, RNF007', 'tone-blue') +
            ViewsStat('alert', 'Incidencias', res.failed, res.failed ? 'Revise el detalle de los casos fallidos' : 'Sin incidencias detectadas', res.failed ? 'tone-red' : '');
          stamp.textContent = 'Última ejecución: ' + U.fmtDateTime(res.ts);
          resultsBox.innerHTML = res.results.map(function (r) {
            return '<div class="test-row">' +
              '<span class="tr-ic" style="color:' + (r.ok ? 'var(--green-700)' : 'var(--red-700)') + '">' + U.icon(r.ok ? 'checkCircle' : 'alert') + '</span>' +
              '<div style="flex:1"><div class="tr-name"><span class="req-id">' + U.esc(r.code) + '</span> ' + U.esc(r.name) + '</div>' +
              '<div class="tr-detail" style="color:' + (r.ok ? 'var(--muted)' : 'var(--red-700)') + '">' + U.esc(r.detail) + '</div></div>' +
              '<span class="tr-time">' + r.ms + ' ms</span></div>';
          }).join('') || '<p class="hint">No se ejecutaron pruebas.</p>';
        }

        function ViewsStat(icon, label, value, foot, tone) {
          return S.Views.field.statCard(icon, label, value, foot, tone);
        }

        function execute() {
          resultsBox.innerHTML = '<p class="hint">Ejecutando pruebas…</p>';
          setTimeout(function () {
            try {
              var res = run();
              render(res);
              if (res.failed) UI.toast(res.failed + ' prueba(s) fallaron. Revise el detalle.', 'warn', 'Resultado de pruebas');
              else UI.toast('Todas las pruebas se ejecutaron correctamente.', 'success', 'Resultado de pruebas');
            } catch (e) {
              resultsBox.innerHTML = '<div class="alert-banner ab-red">' + U.icon('alert') + '<span>' + U.esc(e.message) + '</span></div>';
            }
          }, 40);
        }

        root.querySelector('#test-run').addEventListener('click', execute);
        root.querySelector('#test-export').addEventListener('click', function () {
          if (!last) { UI.toast('Ejecute las pruebas antes de exportar los resultados.', 'warn'); return; }
          U.download('pruebas-sifas.csv', U.toCSV(last.results, [
            { key: 'code', label: 'Requisito' }, { key: 'name', label: 'Prueba' },
            { key: 'ok', label: 'Resultado', value: function (r) { return r.ok ? 'Aprobada' : 'Fallida'; } },
            { key: 'detail', label: 'Detalle' }, { key: 'ms', label: 'Tiempo (ms)' }
          ]), 'text/csv;charset=utf-8');
          UI.toast('Resultados exportados en formato CSV.', 'success');
        });
        execute();
      }
    };
  }

  S.Tests = { run: run, page: page };
})(typeof window !== 'undefined' ? window : this);

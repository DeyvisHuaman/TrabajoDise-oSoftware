/* Mapa esquemático de Huancayo (SVG) con proyección geográfica, burbujas de
   concentración por zona, red vial y selección de puntos. RF011 / RD009. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util, D = S.Domain;

  var W = 820, H = 540;
  var BOUNDS = { minLat: -12.20, maxLat: -11.96, minLng: -75.34, maxLng: -75.12 };

  function project(lat, lng) {
    var x = ((lng - BOUNDS.minLng) / (BOUNDS.maxLng - BOUNDS.minLng)) * W;
    var y = ((BOUNDS.maxLat - lat) / (BOUNDS.maxLat - BOUNDS.minLat)) * H;
    return { x: Math.max(8, Math.min(W - 8, x)), y: Math.max(8, Math.min(H - 8, y)) };
  }
  function unproject(x, y) {
    var lng = BOUNDS.minLng + (x / W) * (BOUNDS.maxLng - BOUNDS.minLng);
    var lat = BOUNDS.maxLat - (y / H) * (BOUNDS.maxLat - BOUNDS.minLat);
    return { lat: +lat.toFixed(5), lng: +lng.toFixed(5) };
  }
  function pathFrom(points, close) {
    return points.map(function (p, i) {
      var pt = project(p[0], p[1]);
      return (i ? 'L' : 'M') + U.round(pt.x, 1) + ' ' + U.round(pt.y, 1);
    }).join(' ') + (close ? ' Z' : '');
  }

  var ROADS = [
    { name: 'Carretera Central', pts: [[-11.972, -75.262], [-12.006, -75.244], [-12.031, -75.228], [-12.052, -75.216], [-12.068, -75.204], [-12.095, -75.192], [-12.132, -75.178], [-12.176, -75.158]], hw: true },
    { name: 'Av. Giráldez', pts: [[-12.062, -75.214], [-12.064, -75.207], [-12.066, -75.199], [-12.068, -75.191]], hw: false },
    { name: 'Av. Huancavelica', pts: [[-12.057, -75.211], [-12.061, -75.204], [-12.063, -75.196], [-12.058, -75.188]], hw: false },
    { name: 'Av. Ferrocarril', pts: [[-12.041, -75.221], [-12.049, -75.214], [-12.058, -75.206], [-12.072, -75.196]], hw: false },
    { name: 'Av. San Carlos', pts: [[-12.053, -75.206], [-12.051, -75.214], [-12.048, -75.224], [-12.045, -75.234]], hw: false },
    { name: 'Ruta a Pilcomayo', pts: [[-12.058, -75.213], [-12.055, -75.226], [-12.052, -75.240], [-12.050, -75.251]], hw: false },
    { name: 'Ruta a Sapallanga', pts: [[-12.081, -75.199], [-12.102, -75.191], [-12.124, -75.183], [-12.142, -75.177]], hw: false },
    { name: 'Ruta a Pucará', pts: [[-12.081, -75.195], [-12.108, -75.184], [-12.136, -75.170], [-12.161, -75.155]], hw: false },
    { name: 'Ruta a Chupaca', pts: [[-12.062, -75.222], [-12.058, -75.238], [-12.063, -75.254], [-12.070, -75.270]], hw: false }
  ];
  var RIVER = [[-11.985, -75.281], [-12.018, -75.266], [-12.043, -75.254], [-12.068, -75.238], [-12.092, -75.236], [-12.118, -75.242], [-12.152, -75.228], [-12.19, -75.215]];

  function terrain() {
    var shapes = [
      { pts: [[-11.965, -75.20], [-11.965, -75.13], [-12.05, -75.13], [-12.03, -75.18], [-11.99, -75.215]], fill: '#dfe9d8', opacity: .7 },
      { pts: [[-12.10, -75.34], [-12.01, -75.34], [-12.04, -75.27], [-12.10, -75.25]], fill: '#e4ecd9', opacity: .8 },
      { pts: [[-12.20, -75.34], [-12.12, -75.30], [-12.10, -75.22], [-12.15, -75.18], [-12.20, -75.16]], fill: '#e7efdd', opacity: .9 },
      { pts: [[-11.96, -75.26], [-11.96, -75.19], [-12.00, -75.21], [-12.01, -75.26]], fill: '#dbe8d2', opacity: .65 }
    ];
    return shapes.map(function (s) {
      return '<path d="' + pathFrom(s.pts, true) + '" fill="' + s.fill + '" opacity="' + s.opacity + '" stroke="#d3e0c9" stroke-width="1"/>';
    }).join('');
  }

  function urbanTexture() {
    var blocks = '';
    var centers = [[-12.065, -75.205], [-12.045, -75.214], [-12.082, -75.204]];
    centers.forEach(function (c, ci) {
      for (var i = 0; i < 10; i++) {
        for (var j = 0; j < 8; j++) {
          if ((i * 7 + j * 3 + ci) % 4 === 0) continue;
          var lat = c[0] + (j - 4) * 0.0026;
          var lng = c[1] + (i - 5) * 0.0022;
          var p = project(lat, lng);
          blocks += '<rect x="' + U.round(p.x - 3, 1) + '" y="' + U.round(p.y - 2.4, 1) + '" width="6" height="4.8" rx=".8" fill="#d5dfd0" opacity=".8"/>';
        }
      }
    });
    return blocks;
  }

  function roads() {
    return '<g>' + ROADS.map(function (r) {
      var d = pathFrom(r.pts);
      return '<path d="' + d + '" fill="none" stroke="#ffffff" stroke-width="' + (r.hw ? 7 : 4.6) + '" stroke-linecap="round" stroke-linejoin="round" opacity=".95"/>' +
        '<path d="' + d + '" fill="none" stroke="' + (r.hw ? '#e2b877' : '#e7cfa9') + '" stroke-width="' + (r.hw ? 4 : 2.4) + '" stroke-linecap="round" stroke-linejoin="round"/>';
    }).join('') + '</g>';
  }

  function roadLabels() {
    return '<g font-size="8.5" fill="#8d7a5d" font-weight="700" letter-spacing=".03em">' +
      '<text x="560" y="330" transform="rotate(40 560 330)">CARRETERA CENTRAL</text>' +
      '<text x="215" y="300" transform="rotate(-30 215 300)">RUTA A PILCOMAYO</text>' +
      '<text x="390" y="440" transform="rotate(28 390 440)">RUTA A SAPALLANGA</text>' +
      '<text x="600" y="185" transform="rotate(28 600 185)">AV. GIRÁLDEZ</text>' +
      '</g>';
  }

  function river() {
    var d = pathFrom(RIVER);
    return '<path d="' + d + '" fill="none" stroke="#b9d3e2" stroke-width="13" stroke-linecap="round" opacity=".9"/>' +
      '<path d="' + d + '" fill="none" stroke="#d8e9f2" stroke-width="7" stroke-linecap="round"/>' +
      '<text x="130" y="250" font-size="9" fill="#6f97ad" font-style="italic" font-weight="600" transform="rotate(-52 130 250)">Río Mantaro</text>';
  }

  function zoneLayer(zoneStats, showZones) {
    if (!showZones) return '';
    var maxCount = Math.max.apply(null, Object.keys(zoneStats).map(function (k) { return zoneStats[k]; }).concat([1]));
    return D.ZONES.map(function (z) {
      var p = project(z.lat, z.lng);
      var count = zoneStats[z.key] || 0;
      var r = 10 + (count / maxCount) * 30;
      var tone = count === 0 ? '#b9c9bf' : count >= maxCount * 0.66 ? '#c0392b' : count >= maxCount * 0.33 ? '#d99a18' : '#2a9169';
      var isAnchor = z.key === 'huancayo' || z.key === 'el-tambo' || z.key === 'chilca' || z.key === 'pilcomayo';
      return '<g class="zone-bubble">' +
        (count > 0 ? '<circle cx="' + p.x + '" cy="' + p.y + '" r="' + r + '" fill="' + tone + '" opacity=".13" stroke="' + tone + '" stroke-width="1.2" stroke-dasharray="3 3"/>' : '') +
        '<text x="' + p.x + '" y="' + (p.y - r - 5) + '" text-anchor="middle" font-size="' + (isAnchor ? 10 : 8.5) + '" font-weight="800" fill="#40564c" letter-spacing=".03em">' + U.esc(z.name.toUpperCase()) + '</text>' +
        (count > 0 ? '<text x="' + p.x + '" y="' + (p.y + 3.5) + '" text-anchor="middle" font-size="10" font-weight="800" fill="' + tone + '">' + count + '</text>' : '') +
        '</g>';
    }).join('');
  }

  function markersLayer(markers, selectedId) {
    return markers.map(function (m) {
      if (m.lat === null || m.lat === undefined || !isFinite(m.lat) || !isFinite(m.lng)) return '';
      var p = project(m.lat, m.lng);
      var color = m.color || '#2a9169';
      var selected = selectedId && selectedId === m.id;
      var title = (m.title || '') + (m.subtitle ? ' · ' + m.subtitle : '');
      return '<g class="map-marker' + (selected ? ' selected' : '') + '" data-marker-id="' + U.attr(m.id) + '" transform="translate(' + U.round(p.x) + ' ' + U.round(p.y) + ')" tabindex="0" role="button" aria-label="' + U.attr(title) + '">' +
        '<title>' + U.esc(title) + '</title>' +
        '<circle r="14" fill="' + color + '" opacity=".16"/>' +
        '<circle r="7" fill="' + color + '" stroke="#fff" stroke-width="2.2"/>' +
        '<circle r="2.2" fill="#fff" opacity=".85"/>' +
        '</g>';
    }).join('');
  }

  function svgMarkup(markers, zoneStats, opts) {
    return '<svg class="map-svg' + (opts.pick ? ' map-pick' : '') + '" viewBox="' + opts.vb.x + ' ' + opts.vb.y + ' ' + opts.vb.w + ' ' + opts.vb.h + '" role="img" aria-label="Mapa de intervenciones en Huancayo">' +
      '<defs><filter id="mapShadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="1" stdDeviation="1.4" flood-color="#0b3d2c" flood-opacity=".22"/></filter></defs>' +
      terrain() + urbanTexture() + river() + roads() + roadLabels() +
      zoneLayer(zoneStats, opts.showZones !== false) +
      '<g filter="url(#mapShadow)">' + markersLayer(markers, opts.selectedId) + '</g>' +
      (opts.pickMarker ? (function () {
        var p = project(opts.pickMarker.lat, opts.pickMarker.lng);
        return '<g transform="translate(' + p.x + ' ' + p.y + ')" pointer-events="none">' +
          '<circle r="15" fill="#1b7a56" opacity=".18"/><circle r="7" fill="#1b7a56" stroke="#fff" stroke-width="2.4"/>' +
          '<circle r="2.4" fill="#fff"/></g>';
      })() : '') +
      '<g class="map-attrib" font-size="7.5" fill="#94a49b"><text x="' + (W - 8) + '" y="' + (H - 6) + '" text-anchor="end">SIFAS · ATFFS Sierra Central · Huancayo</text></g>' +
      '</svg>';
  }

  function create(container, options) {
    var opts = Object.assign({
      markers: [], height: null, pick: false, selectedId: null,
      showZones: true, onSelect: null, onPick: null, pickMarker: null,
      legend: true, zoom: true
    }, options || {});
    var vb = { x: 0, y: 0, w: W, h: H };
    container.innerHTML = '';
    var card = document.createElement('div');
    card.className = 'map-card';
    card.style.position = 'relative';
    container.appendChild(card);

    function zoneStats() {
      var out = {};
      opts.markers.forEach(function (m) {
        if (!isFinite(m.lat) || !isFinite(m.lng)) return;
        var near = D.nearestZone(m.lat, m.lng);
        if (near) out[near.zone.key] = (out[near.zone.key] || 0) + 1;
      });
      return out;
    }

    function draw() {
      var stats = zoneStats();
      card.innerHTML =
        svgMarkup(opts.markers, stats, { pick: opts.pick, selectedId: opts.selectedId, pickMarker: opts.pickMarker, showZones: opts.showZones, vb: vb }) +
        (opts.zoom ? '<div class="map-tools"><button type="button" data-map-zoom="in" aria-label="Acercar">+</button><button type="button" data-map-zoom="out" aria-label="Alejar">−</button><button type="button" data-map-zoom="reset" aria-label="Restablecer">⟲</button></div>' : '') +
        (opts.legend ? '<div class="map-legend">' +
          '<span class="lg"><i style="background:#c0392b"></i>Prioridad I</span>' +
          '<span class="lg"><i style="background:#d99a18"></i>Prioridad II</span>' +
          '<span class="lg"><i style="background:#2a9169"></i>Prioridad III</span>' +
          '<span class="lg" style="color:#65776f"><i style="background:#c0392b;opacity:.18;border:1px dashed #c0392b"></i>Burbuja: concentración por zona</span>' +
          '</div>' : '') +
        (opts.pick ? '<div class="map-pick-help" data-pick-help>Haga clic en el mapa para fijar la ubicación del hecho.</div>' : '');

      var svg = card.querySelector('svg');
      if (opts.onSelect) {
        svg.addEventListener('click', function (ev) {
          var g = ev.target.closest('[data-marker-id]');
          if (g) {
            ev.stopPropagation();
            opts.onSelect(g.getAttribute('data-marker-id'));
            return;
          }
          if (opts.pick) pickAt(ev);
        });
        svg.addEventListener('keydown', function (ev) {
          if (ev.key !== 'Enter' && ev.key !== ' ') return;
          var g = ev.target.closest('[data-marker-id]');
          if (g) { ev.preventDefault(); opts.onSelect(g.getAttribute('data-marker-id')); }
        });
      } else if (opts.pick) {
        svg.addEventListener('click', pickAt);
      }
      card.querySelectorAll('[data-map-zoom]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var action = btn.getAttribute('data-map-zoom');
          if (action === 'reset') { vb = { x: 0, y: 0, w: W, h: H }; }
          else if (action === 'in') zoom(0.8);
          else zoom(1.25);
          draw();
        });
      });
    }
    function zoom(factor) {
      var cx = vb.x + vb.w / 2, cy = vb.y + vb.h / 2;
      var nw = U.clamp(vb.w * factor, 260, W), nh = U.clamp(vb.h * factor, 170, H);
      vb = { x: cx - nw / 2, y: cy - nh / 2, w: nw, h: nh };
      if (vb.x < 0) vb.x = 0;
      if (vb.y < 0) vb.y = 0;
      if (vb.x + vb.w > W) vb.x = W - vb.w;
      if (vb.y + vb.h > H) vb.y = H - vb.h;
    }
    function pickAt(ev) {
      var svg = card.querySelector('svg');
      var rect = svg.getBoundingClientRect();
      var x = ((ev.clientX - rect.left) / rect.width) * vb.w + vb.x;
      var y = ((ev.clientY - rect.top) / rect.height) * vb.h + vb.y;
      var ll = unproject(x, y);
      if (opts.onPick) opts.onPick(ll);
    }

    draw();
    return {
      update: function (next) { opts = Object.assign(opts, next || {}); draw(); },
      destroy: function () { container.innerHTML = ''; }
    };
  }

  S.Map = { create: create, project: project, unproject: unproject, BOUNDS: BOUNDS, W: W, H: H };
})(typeof window !== 'undefined' ? window : this);

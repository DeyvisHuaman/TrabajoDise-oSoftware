/* Inventario de alimentos, medicamentos y herramientas de contención.
   RF009, RF010, RD006, RD007. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util, D = S.Domain, Store = S.Store, UI = S.UI, Auth = S.Auth;
  var Views = S.Views = S.Views || {};

  function user() { return Auth.current(); }

  function index(params) {
    var u = user();
    var canManage = Store.can(u.role, 'inventory.manage');
    var tab = (params.query && params.query.tab) || 'insumos';
    var items = Store.items();
    var alerts = D.inventoryAlerts(items);
    var active = items.filter(function (i) { return i.active; });
    var low = alerts.filter(function (a) { return a.type === 'stock'; });
    var exp = alerts.filter(function (a) { return a.type === 'por_vencer' || a.type === 'vencido'; });
    var h = '<div class="page-head"><div class="ph-text"><h1>Inventario de insumos</h1>' +
      '<div class="sub">Alimentos, medicamentos veterinarios y herramientas de contención · alertas automáticas</div></div>' +
      '<div class="ph-actions">' + (canManage ? '<button class="btn btn-primary" data-new-item>' + U.icon('plus') + 'Registrar insumo</button>' : '') +
      '<button class="btn btn-secondary" data-export-items>' + U.icon('download') + 'Exportar</button></div></div>' +
      '<div class="grid grid-4 section">' +
      Views.field.statCard('box', 'Insumos activos', active.length, 'En las tres categorías', '') +
      Views.field.statCard('alert', 'Stock mínimo', low.length, 'Requieren reposición', 'tone-red') +
      Views.field.statCard('clock', 'Próximos a vencer', exp.filter(function (a) { return a.type === 'por_vencer'; }).length, 'Dentro de los próximos 30 días', 'tone-amber') +
      Views.field.statCard('x', 'Productos vencidos', exp.filter(function (a) { return a.type === 'vencido'; }).length, 'Retirar del inventario', 'tone-purple') +
      '</div>' +
      '<div class="card"><div class="card-head" style="padding-bottom:0;border-bottom:0">' + UI.tabs([
        { key: 'insumos', label: 'Insumos', count: active.length },
        { key: 'movimientos', label: 'Movimientos', count: Store.movements().length },
        { key: 'alertas', label: 'Alertas', count: alerts.length }
      ], tab) + '</div><div class="card-body">' +
      (tab === 'movimientos' ? movementsView(canManage) : tab === 'alertas' ? alertsView(alerts, canManage) : itemsView(active, canManage)) +
      '</div></div>';

    return {
      html: h,
      mount: function (root) {
        U.on(root, '[data-tab]', 'click', function () { location.hash = '#/app/inventario?tab=' + this.getAttribute('data-tab'); });
        U.on(root, '[data-new-item]', 'click', function () { openItemModal(null, function () { S.App.refresh(); }); });
        U.on(root, '[data-edit-item]', 'click', function () { openItemModal(this.getAttribute('data-edit-item'), function () { S.App.refresh(); }); });
        U.on(root, '[data-move]', 'click', function (ev) {
          ev.stopPropagation();
          openMoveModal(this.getAttribute('data-move'), this.getAttribute('data-move-type') || 'salida', function () { S.App.refresh(); });
        });
        U.on(root, '[data-item-history]', 'click', function (ev) {
          ev.stopPropagation();
          openHistoryModal(this.getAttribute('data-item-history'));
        });
        U.on(root, '[data-item-row]', 'click', function (ev) {
          if (ev.target.closest('button, a, input, select, label')) return;
          openHistoryModal(this.getAttribute('data-item-row'));
        });
        U.on(root, '[data-export-items]', 'click', function () {
          U.download('inventario-sifas.csv', U.toCSV(Store.items(), [
            { key: 'code', label: 'Código' }, { key: 'name', label: 'Insumo' }, { key: 'category', label: 'Categoría' },
            { key: 'unit', label: 'Unidad' }, { key: 'stock', label: 'Stock' }, { key: 'minStock', label: 'Stock mínimo' },
            { key: 'expiresAt', label: 'Vencimiento', value: function (r) { return r.expiresAt ? U.fmtShort(r.expiresAt) : '—'; } },
            { key: 'location', label: 'Ubicación' }
          ]), 'text/csv;charset=utf-8');
          UI.toast('Inventario exportado en formato CSV.', 'success');
        });
        U.on(root, '[data-export-movements]', 'click', function () {
          U.download('movimientos-inventario-sifas.csv', U.toCSV(Store.movements(), [
            { key: 'ts', label: 'Fecha', value: function (r) { return U.fmtDateTime(r.ts); } },
            { key: 'itemName', label: 'Insumo' }, { key: 'type', label: 'Tipo' }, { key: 'qty', label: 'Cantidad' },
            { key: 'balanceAfter', label: 'Saldo' }, { key: 'reason', label: 'Motivo' },
            { key: 'interventionCode', label: 'Intervención' }, { key: 'userName', label: 'Responsable' }
          ]), 'text/csv;charset=utf-8');
          UI.toast('Movimientos exportados en formato CSV.', 'success');
        });
        bindItemsTable(root);
        bindMovementsTable(root);
      }
    };
  }

  function stockStatus(item) {
    var stock = U.num(item.stock), min = U.num(item.minStock);
    if (stock <= 0) return { label: 'Agotado', tone: 'red', pct: 0, color: '#c0392b' };
    if (stock <= min) return { label: 'Stock mínimo', tone: 'amber', pct: Math.max(6, (stock / Math.max(min * 2, 1)) * 100), color: '#d99a18' };
    return { label: 'Disponible', tone: 'green', pct: Math.min(100, (stock / Math.max(min * 3, 1)) * 100), color: '#2a9169' };
  }

  function itemsView(items, canManage) {
    return '<div class="toolbar"><div class="search-box">' + U.icon('search') +
      '<input class="input" id="inv-search" placeholder="Buscar insumo, código o proveedor…" aria-label="Buscar insumo"></div>' +
      '<select class="select" id="inv-cat" aria-label="Filtrar categoría"><option value="">Todas las categorías</option>' +
      D.INVENTORY_CATEGORIES.map(function (c) { return '<option value="' + c.key + '">' + c.label + '</option>'; }).join('') + '</select>' +
      '<select class="select" id="inv-state" aria-label="Filtrar estado"><option value="">Todo estado</option><option value="low">Stock mínimo</option><option value="exp">Próximo a vencer</option><option value="expired">Vencido</option></select>' +
      '<span class="spacer"></span><span class="result-count" id="inv-count"></span></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Insumo</th><th>Categoría</th><th>Stock disponible</th><th>Mínimo</th><th>Vencimiento</th><th>Estado</th><th></th></tr></thead><tbody id="inv-body"></tbody></table></div>';
  }

  function movementsView() {
    var movs = Store.movements();
    return '<div class="toolbar"><div class="search-box">' + U.icon('search') +
      '<input class="input" id="mov-search" placeholder="Buscar por insumo, motivo o responsable…" aria-label="Buscar movimiento"></div>' +
      '<select class="select" id="mov-type" aria-label="Filtrar tipo"><option value="">Entradas y salidas</option><option value="entrada">Entradas</option><option value="salida">Salidas</option></select>' +
      '<span class="spacer"></span><button class="btn btn-secondary btn-sm" data-export-movements>' + U.icon('download') + 'Exportar CSV</button></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Fecha</th><th>Insumo</th><th>Movimiento</th><th>Cantidad</th><th>Saldo</th><th>Motivo</th><th>Intervención</th><th>Responsable</th></tr></thead><tbody id="mov-body"></tbody></table></div>';
  }

  function alertsView(alerts, canManage) {
    if (!alerts.length) return UI.empty('checkCircle', 'Sin alertas de inventario', 'Todos los insumos se encuentran sobre el stock mínimo y sin vencimientos próximos.');
    return '<div class="alert-banner ab-amber">' + U.icon('alert') +
      '<span>Las alertas se generan automáticamente cuando el stock alcanza el mínimo establecido o cuando un medicamento vence dentro de los próximos <strong>30 días calendario</strong> (RF010 / RD007).</span></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Tipo</th><th>Producto</th><th>Motivo de la alerta</th><th>Stock</th><th>Vencimiento</th><th></th></tr></thead><tbody>' +
      alerts.map(function (a) {
        var st = D.expiryStatus(a.item.expiresAt);
        return '<tr><td>' + UI.badge(a.title, a.severity === 1 ? 'red' : 'amber') + '</td>' +
          '<td><div class="t-main">' + U.esc(a.item.name) + '</div><div class="t-code">' + U.esc(a.item.code) + '</div></td>' +
          '<td class="t-sub">' + U.esc(a.reason) + '</td>' +
          '<td class="t-nowrap"><strong>' + a.item.stock + '</strong> ' + U.esc(a.item.unit) + '</td>' +
          '<td class="t-sub t-nowrap">' + (a.item.expiresAt ? U.fmtShort(a.item.expiresAt) + '<br>' + st.label : '—') + '</td>' +
          '<td class="t-right">' + (canManage ? '<button class="btn btn-sm btn-soft" data-move="' + U.attr(a.item.id) + '" data-move-type="entrada">Reponer</button>' : '') + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }

  function bindItemsTable(root) {
    var body = root.querySelector('#inv-body');
    if (!body) return;
    var all = Store.items().filter(function (i) { return i.active; });
    var search = root.querySelector('#inv-search');
    var cat = root.querySelector('#inv-cat');
    var state = root.querySelector('#inv-state');
    var count = root.querySelector('#inv-count');
    function draw() {
      var q = U.normalize(search.value);
      var list = all.filter(function (it) {
        var st = stockStatus(it);
        var exp = D.expiryStatus(it.expiresAt);
        var matchQ = !q || U.normalize(it.name + ' ' + it.code + ' ' + (it.supplier || '')).indexOf(q) >= 0;
        var matchCat = !cat.value || it.category === cat.value;
        var matchState = !state.value ||
          (state.value === 'low' && U.num(it.stock) <= U.num(it.minStock)) ||
          (state.value === 'exp' && exp.state === 'por_vencer') ||
          (state.value === 'expired' && exp.state === 'vencido');
        return matchQ && matchCat && matchState;
      });
      count.textContent = list.length + ' de ' + all.length + ' insumos';
      body.innerHTML = list.length ? list.map(function (it) {
        var st = stockStatus(it);
        var exp = D.expiryStatus(it.expiresAt);
        var category = D.INVENTORY_CATEGORIES.filter(function (c) { return c.key === it.category; })[0] || {};
        return '<tr data-item-row="' + it.id + '" style="cursor:pointer">' +
          '<td><div class="t-main">' + U.esc(it.name) + '</div><div class="t-code">' + U.esc(it.code) + ' · ' + U.esc(it.location || '') + '</div></td>' +
          '<td class="t-sub">' + U.icon(category.icon || 'box') + ' ' + U.esc(category.label || it.category) + '</td>' +
          '<td style="min-width:150px"><div style="display:flex;align-items:center;gap:.5rem"><strong>' + it.stock + '</strong><span class="hint">' + U.esc(it.unit) + '</span></div>' +
          '<div class="br-track" style="height:5px;margin-top:.25rem"><span class="br-fill" style="width:' + st.pct + '%;background:' + st.color + '"></span></div></td>' +
          '<td class="t-sub">' + it.minStock + '</td>' +
          '<td class="t-sub">' + (it.expiresAt ? U.fmtShort(it.expiresAt) + '<div class="hint" style="color:' + (exp.state === 'vencido' ? 'var(--red-700)' : exp.state === 'por_vencer' ? 'var(--amber-600)' : 'inherit') + '">' + U.esc(exp.label) + '</div>' : '—') + '</td>' +
          '<td>' + UI.badge(st.label, st.tone) + (exp.state === 'vencido' ? ' ' + UI.badge('Vencido', 'red') : exp.state === 'por_vencer' ? ' ' + UI.badge('Por vencer', 'amber') : '') + '</td>' +
          '<td class="t-right t-nowrap"><button class="btn btn-sm btn-soft" data-move="' + it.id + '" data-move-type="entrada" title="Registrar entrada">' + U.icon('download') + '</button> ' +
          '<button class="btn btn-sm btn-amber" data-move="' + it.id + '" data-move-type="salida" title="Registrar salida">' + U.icon('send') + '</button> ' +
          '<button class="btn btn-sm btn-secondary" data-edit-item="' + it.id + '" title="Editar insumo">' + U.icon('edit') + '</button></td></tr>';
      }).join('') : '<tr><td colspan="7"><div class="table-empty">' + U.icon('box') + 'No se encontraron insumos con los filtros seleccionados.</div></td></tr>';
    }
    search.addEventListener('input', U.debounce(draw, 150));
    cat.addEventListener('change', draw); state.addEventListener('change', draw);
    draw();
  }

  function bindMovementsTable(root) {
    var body = root.querySelector('#mov-body');
    if (!body) return;
    var all = Store.movements();
    var search = root.querySelector('#mov-search');
    var type = root.querySelector('#mov-type');
    function draw() {
      var q = U.normalize(search.value);
      var list = all.filter(function (m) {
        return (!q || U.normalize(m.itemName + ' ' + m.reason + ' ' + m.userName + ' ' + (m.interventionCode || '')).indexOf(q) >= 0) &&
          (!type.value || m.type === type.value);
      });
      body.innerHTML = list.length ? list.map(function (m) {
        return '<tr><td class="t-sub t-nowrap">' + U.fmtDateTime(m.ts) + '</td>' +
          '<td><div class="t-main">' + U.esc(m.itemName) + '</div></td>' +
          '<td>' + (m.type === 'entrada' ? UI.badge('Entrada', 'green') : UI.badge('Salida', 'amber')) + '</td>' +
          '<td class="fw-700" style="color:' + (m.type === 'entrada' ? 'var(--green-700)' : 'var(--red-700)') + '">' + (m.type === 'entrada' ? '+' : '−') + m.qty + '</td>' +
          '<td>' + m.balanceAfter + '</td><td class="t-sub">' + U.esc(m.reason) + '</td>' +
          '<td class="t-code">' + (m.interventionCode ? '<a href="#/app/rescates/' + U.attr(m.interventionId) + '">' + U.esc(m.interventionCode) + '</a>' : '—') + '</td>' +
          '<td class="t-sub">' + U.esc(m.userName) + '</td></tr>';
      }).join('') : '<tr><td colspan="8"><div class="table-empty">' + U.icon('activity') + 'Sin movimientos registrados con esos filtros.</div></td></tr>';
    }
    search.addEventListener('input', U.debounce(draw, 150));
    type.addEventListener('change', draw);
    draw();
  }

  /* ==================================================================
     Modal: registrar / editar insumo
     ================================================================== */
  function openItemModal(itemId, onDone) {
    var u = user();
    var it = itemId ? Store.item(itemId) : null;
    var isEdit = !!it;
    var body = '<div class="form-grid">' +
      '<div class="field span-2"><label for="it-name">Nombre del insumo <span class="req">*</span></label><input class="input" id="it-name" maxlength="100" value="' + U.attr(it ? it.name : '') + '" placeholder="Ej. Enrofloxacina 10%"></div>' +
      '<div class="field"><label for="it-cat">Categoría <span class="req">*</span></label><select class="select" id="it-cat"' + (isEdit ? ' disabled' : '') + '>' +
      D.INVENTORY_CATEGORIES.map(function (c) { return '<option value="' + c.key + '"' + (it && it.category === c.key ? ' selected' : '') + '>' + c.label + '</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label for="it-unit">Unidad de medida</label><input class="input" id="it-unit" value="' + U.attr(it ? it.unit : 'unidades') + '" placeholder="kg, ml, dosis, unidades…"></div>' +
      (isEdit ? '' : '<div class="field"><label for="it-stock">Stock inicial</label><input class="input" id="it-stock" type="number" min="0" step="0.01" value="0"></div>') +
      '<div class="field"><label for="it-min">Stock mínimo <span class="req">*</span></label><input class="input" id="it-min" type="number" min="0" step="0.01" value="' + U.attr(it ? it.minStock : 5) + '"></div>' +
      '<div class="field"><label for="it-exp">Fecha de vencimiento</label><input class="input" id="it-exp" type="date" value="' + U.attr(it && it.expiresAt ? it.expiresAt.slice(0, 10) : '') + '">' +
      '<span class="hint" id="it-exp-hint">Obligatoria para medicamentos.</span></div>' +
      '<div class="field"><label for="it-lot">Lote</label><input class="input" id="it-lot" value="' + U.attr(it ? (it.lot || '') : '') + '"></div>' +
      '<div class="field"><label for="it-supplier">Proveedor</label><input class="input" id="it-supplier" value="' + U.attr(it ? (it.supplier || '') : '') + '"></div>' +
      '<div class="field"><label for="it-location">Ubicación en almacén</label><input class="input" id="it-location" value="' + U.attr(it ? (it.location || '') : '') + '" placeholder="Ej. Refrigerador 1"></div>' +
      '</div>' +
      (isEdit ? '<div class="alert-banner ab-blue" style="margin:1rem 0 0">' + U.icon('info') + '<span>El stock no se edita directamente: toda variación debe registrarse como entrada o salida para conservar el historial (RD006).</span></div>' : '');

    var m = UI.modal({
      title: isEdit ? 'Editar insumo' : 'Registrar nuevo insumo',
      subtitle: isEdit ? it.code : 'Alta de insumo en el inventario institucional',
      body: body,
      footer: '<button class="btn btn-secondary" type="button" data-close-modal>Cancelar</button>' +
        '<button class="btn btn-primary" type="button" id="it-save">' + U.icon('save') + (isEdit ? 'Guardar cambios' : 'Registrar insumo') + '</button>'
    });
    m.el.querySelector('[data-close-modal]').addEventListener('click', UI.closeModal);
    m.el.querySelector('#it-save').addEventListener('click', function () {
      var data = {
        name: m.el.querySelector('#it-name').value.trim(),
        category: m.el.querySelector('#it-cat').value,
        unit: m.el.querySelector('#it-unit').value.trim() || 'unidades',
        minStock: U.num(m.el.querySelector('#it-min').value),
        expiresAt: m.el.querySelector('#it-exp').value || null,
        lot: m.el.querySelector('#it-lot').value.trim() || null,
        supplier: m.el.querySelector('#it-supplier').value.trim(),
        location: m.el.querySelector('#it-location').value.trim()
      };
      try {
        if (isEdit) {
          Store.updateItem(it.id, data, u);
          UI.toast('Insumo actualizado correctamente.', 'success');
        } else {
          data.stock = U.num(m.el.querySelector('#it-stock').value);
          Store.createItem(data, u);
          UI.toast('Insumo registrado en el inventario.', 'success');
        }
        UI.closeModal();
        if (onDone) onDone();
      } catch (err) { UI.toast(err.message, 'error'); }
    });
  }

  /* ==================================================================
     Modal: entrada / salida de stock
     ================================================================== */
  function openMoveModal(itemId, type, onDone) {
    var u = user();
    var it = Store.item(itemId);
    if (!it) return;
    if (!Store.can(u.role, 'inventory.manage')) { UI.toast('Tu rol no permite registrar movimientos de inventario.', 'error'); return; }
    var defaultType = type === 'entrada' ? 'entrada' : 'salida';
    var interventions = U.sortBy(Store.interventions().filter(D.isInCare), function (i) { return new Date(i.occurredAt); }, true);
    var body = '<div class="card card-pad" style="background:var(--sand-50);margin-bottom:1rem">' +
      '<div style="display:flex;gap:.8rem;align-items:center"><div style="width:40px;height:40px;border-radius:10px;background:var(--green-100);display:grid;place-items:center;color:var(--green-700)">' + U.icon('box') + '</div>' +
      '<div style="flex:1"><div style="font-weight:700;font-size:.9rem">' + U.esc(it.name) + '</div><div class="hint">' + U.esc(it.code) + ' · Stock actual: <strong>' + it.stock + ' ' + U.esc(it.unit) + '</strong></div></div>' +
      (it.expiresAt ? UI.badge(D.expiryStatus(it.expiresAt).label, D.expiryStatus(it.expiresAt).tone) : '') + '</div></div>' +
      '<div class="btn-group" style="margin-bottom:1rem" id="mv-type">' +
      '<button type="button" data-type="entrada" class="' + (defaultType === 'entrada' ? 'active' : '') + '">' + U.icon('download') + ' Entrada</button>' +
      '<button type="button" data-type="salida" class="' + (defaultType === 'salida' ? 'active' : '') + '">' + U.icon('send') + ' Salida</button></div>' +
      '<div class="form-grid">' +
      '<div class="field"><label for="mv-qty">Cantidad <span class="req">*</span></label><input class="input" id="mv-qty" type="number" min="0.01" step="0.01" placeholder="0.00">' +
      '<span class="hint" id="mv-avail">Disponible: ' + it.stock + ' ' + U.esc(it.unit) + '</span><div class="err" id="mv-err"></div></div>' +
      '<div class="field"><label for="mv-reason">Motivo <span class="req">*</span></label><input class="input" id="mv-reason" maxlength="120" placeholder="Ej. Tratamiento de animal en cuarentena"></div>' +
      '<div class="field span-2" id="mv-int-wrap"><label for="mv-int">Asociar a intervención / animal (opcional)</label><select class="select" id="mv-int">' +
      '<option value="">Sin asociación</option>' + interventions.map(function (i) {
        return '<option value="' + U.attr(i.id) + '">' + U.esc(i.code + ' · ' + i.speciesName) + '</option>';
      }).join('') + '</select><span class="hint">Requerido cuando el insumo se utiliza en el tratamiento de un animal (RF009).</span></div>' +
      '</div>' +
      '<div class="alert-banner ab-blue" style="margin-top:.4rem">' + U.icon('shieldCheck') + '<span>El sistema valida el stock disponible e impide registrar salidas superiores al inventario existente (RD006).</span></div>';

    var m = UI.modal({
      title: 'Registrar movimiento de inventario', subtitle: it.code + ' · ' + it.name,
      body: body,
      footer: '<button class="btn btn-secondary" type="button" data-close-modal>Cancelar</button>' +
        '<button class="btn btn-primary" type="button" id="mv-save">' + U.icon('save') + 'Registrar movimiento</button>'
    });
    m.el.querySelector('[data-close-modal]').addEventListener('click', UI.closeModal);
    var currentType = defaultType;
    function setType(t) {
      currentType = t;
      U.$$('#mv-type button', m.el).forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-type') === t); });
      m.el.querySelector('#mv-int-wrap').style.display = t === 'salida' ? '' : 'none';
      m.el.querySelector('#mv-avail').textContent = t === 'salida' ? 'Disponible: ' + it.stock + ' ' + it.unit : 'Stock actual: ' + it.stock + ' ' + it.unit;
      m.el.querySelector('#mv-err').classList.remove('show');
    }
    U.on(m.el, '#mv-type button', 'click', function () { setType(this.getAttribute('data-type')); });
    setType(defaultType);

    m.el.querySelector('#mv-save').addEventListener('click', function () {
      var qty = U.num(m.el.querySelector('#mv-qty').value);
      var reason = m.el.querySelector('#mv-reason').value.trim();
      var errEl = m.el.querySelector('#mv-err');
      errEl.classList.remove('show');
      if (!(qty > 0)) { errEl.textContent = 'Ingrese una cantidad mayor a cero.'; errEl.classList.add('show'); return; }
      if (!reason) { errEl.textContent = 'Indique el motivo del movimiento.'; errEl.classList.add('show'); return; }
      if (currentType === 'salida' && qty > U.num(it.stock)) {
        errEl.textContent = 'La cantidad solicitada (' + qty + ') supera el stock disponible (' + it.stock + ').';
        errEl.classList.add('show');
        UI.toast('Salida rechazada: no hay stock suficiente.', 'error');
        return;
      }
      try {
        Store.moveStock(it.id, {
          type: currentType, qty: qty, reason: reason,
          interventionId: m.el.querySelector('#mv-int').value || null
        }, u);
        UI.closeModal();
        UI.toast('Movimiento registrado. Nuevo stock: ' + Store.item(it.id).stock + ' ' + it.unit + '.', 'success');
        if (onDone) onDone();
      } catch (err) { errEl.textContent = err.message; errEl.classList.add('show'); UI.toast(err.message, 'error'); }
    });
  }

  /* ==================================================================
     Modal: historial del insumo
     ================================================================== */
  function openHistoryModal(itemId) {
    var it = Store.item(itemId);
    if (!it) return;
    var movs = Store.movements().filter(function (m) { return m.itemId === itemId; });
    var st = stockStatus(it);
    var exp = D.expiryStatus(it.expiresAt);
    var body = '<div class="meta-grid" style="margin-bottom:1rem">' +
      UI.infoRow('Código', U.esc(it.code)) + UI.infoRow('Categoría', U.esc((D.INVENTORY_CATEGORIES.filter(function (c) { return c.key === it.category; })[0] || {}).label || it.category)) +
      UI.infoRow('Stock disponible', '<strong>' + it.stock + ' ' + U.esc(it.unit) + '</strong>') + UI.infoRow('Stock mínimo', it.minStock + ' ' + U.esc(it.unit)) +
      UI.infoRow('Vencimiento', it.expiresAt ? U.fmtShort(it.expiresAt) + ' · ' + U.esc(exp.label) : 'No aplica') + UI.infoRow('Lote', U.esc(it.lot || '—')) +
      UI.infoRow('Proveedor', U.esc(it.supplier || '—')) + UI.infoRow('Ubicación', U.esc(it.location || '—')) +
      '</div>' +
      '<div class="pill-row" style="margin-bottom:.7rem">' + UI.badge(st.label, st.tone) + (it.expiresAt ? UI.badge(exp.label, exp.tone) : '') + '</div>' +
      '<div class="divider"></div><h3 style="font-size:.9rem;margin-bottom:.5rem">Historial de movimientos (' + movs.length + ')</h3>' +
      (movs.length ? '<div class="table-wrap"><table class="tbl tbl-compact"><thead><tr><th>Fecha</th><th>Tipo</th><th>Cantidad</th><th>Saldo</th><th>Motivo</th><th>Responsable</th></tr></thead><tbody>' +
        movs.map(function (m) {
          return '<tr><td class="t-sub">' + U.fmtDateTime(m.ts) + '</td><td>' + (m.type === 'entrada' ? UI.badge('Entrada', 'green') : UI.badge('Salida', 'amber')) + '</td>' +
            '<td>' + (m.type === 'entrada' ? '+' : '−') + m.qty + '</td><td>' + m.balanceAfter + '</td>' +
            '<td class="t-sub">' + U.esc(m.reason) + (m.interventionCode ? ' · <span class="t-code">' + U.esc(m.interventionCode) + '</span>' : '') + '</td>' +
            '<td class="t-sub">' + U.esc(m.userName) + '</td></tr>';
        }).join('') + '</tbody></table></div>' : '<p class="hint">Sin movimientos registrados para este insumo.</p>');
    var m = UI.modal({
      title: it.name, subtitle: 'Historial y trazabilidad del insumo', size: 'lg', body: body,
      footer: '<div class="mf-left"><button class="btn btn-secondary btn-sm" type="button" data-edit-from-history>' + U.icon('edit') + 'Editar insumo</button></div>' +
        '<button class="btn btn-secondary" type="button" data-close-modal>Cerrar</button>' +
        '<button class="btn btn-primary" type="button" data-move-from-history>' + U.icon('plus') + 'Registrar movimiento</button>'
    });
    m.el.querySelector('[data-close-modal]').addEventListener('click', UI.closeModal);
    m.el.querySelector('[data-move-from-history]').addEventListener('click', function () {
      UI.closeModal();
      openMoveModal(it.id, 'salida', function () { S.App.refresh(); });
    });
    m.el.querySelector('[data-edit-from-history]').addEventListener('click', function () {
      UI.closeModal();
      openItemModal(it.id, function () { S.App.refresh(); });
    });
  }

  /* Se invocan desde el panel de control */
  document.addEventListener('DOMContentLoaded', function () {
    U.on(document, '[data-move]', 'click', function () {
      if (!this.closest('#inv-body')) return;
    });
  });

  Views.inventory = {
    index: index, openItemModal: openItemModal, openMoveModal: openMoveModal,
    openHistoryModal: openHistoryModal, bindItemsTable: bindItemsTable, bindMovementsTable: bindMovementsTable,
    stockStatus: stockStatus
  };
})(typeof window !== 'undefined' ? window : this);

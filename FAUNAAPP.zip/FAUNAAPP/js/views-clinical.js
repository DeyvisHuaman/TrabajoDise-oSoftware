/* Gestión clínica: historia digital, cuarentena, vacunas, dietas,
   decisión técnica y monitoreo post-liberación (RF006–RF008, RD002–RD005). */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util, D = S.Domain, Store = S.Store, UI = S.UI, Auth = S.Auth, Charts = S.Charts;
  var Views = S.Views = S.Views || {};

  function user() { return Auth.current(); }

  function list() {
    var u = user();
    var all = Store.interventions();
    var rows = all.filter(function (i) { return Store.clinicalSummary(i.id).count > 0 || D.isInCare(i); });
    var h = '<div class="page-head"><div class="ph-text"><h1>Historias clínicas</h1>' +
      '<div class="sub">Seguimiento veterinario de animales rescatados · cuarentena y rehabilitación</div></div>' +
      '<div class="ph-actions"><a class="btn btn-secondary" href="#/app/rescates">' + U.icon('paw') + 'Ver rescates</a></div></div>' +
      '<div class="grid grid-4 section">' +
      Views.field.statCard('stethoscope', 'Historias abiertas', rows.filter(function (i) { return D.isInCare(i); }).length, 'Animales en atención activa', '') +
      Views.field.statCard('alert', 'Prioridad I', rows.filter(function (i) { return D.isInCare(i) && i.priority.level === 'I'; }).length, 'Atención inmediata', 'tone-red') +
      Views.field.statCard('activity', 'Controles registrados', Store.get().clinicalRecords.filter(function (r) { return r.type === 'control'; }).length, 'Seguimiento de cuarentena', 'tone-blue') +
      Views.field.statCard('checkCircle', 'Altas médicas', all.filter(function (i) { return i.discharge; }).length, 'Aptos para evaluación de liberación', 'tone-amber') +
      '</div>' +
      '<div class="card"><div class="card-head"><h3>' + U.icon('stethoscope') + ' Pacientes</h3>' +
      '<div class="ch-actions"><div class="search-box" style="position:relative"><input class="input" id="hc-search" placeholder="Buscar por código o especie…" style="min-height:34px;padding:.3rem .6rem;font-size:.78rem" aria-label="Buscar paciente"></div></div></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Prioridad</th><th>Código / especie</th><th>Ingreso</th><th>Cuarentena</th><th>Último control</th><th>Alta médica</th><th>Estado</th><th></th></tr></thead><tbody id="hc-body"></tbody></table></div></div>';

    return {
      html: h,
      mount: function (root) {
        var body = root.querySelector('#hc-body');
        var search = root.querySelector('#hc-search');
        function draw() {
          var q = U.normalize(search.value);
          var filtered = U.sortBy(rows, function (i) { return (i.priority.order || 3) * 1e13 + new Date(i.occurredAt).getTime(); })
            .filter(function (i) { return !q || U.normalize(i.code + ' ' + i.speciesName).indexOf(q) >= 0; });
          body.innerHTML = filtered.length ? filtered.map(function (i) {
            var sum = Store.clinicalSummary(i.id);
            var days = Math.max(0, Math.round((Date.now() - new Date(i.occurredAt).getTime()) / 86400000));
            var last = sum.lastControl ? Math.round((Date.now() - new Date(sum.lastControl.ts).getTime()) / 86400000) : null;
            return '<tr class="is-click" data-go="#/app/clinica/' + i.id + '">' +
              '<td>' + UI.priorityBadge(i.priority.level) + '</td>' +
              '<td><div class="t-main">' + U.esc(i.speciesName) + '</div><div class="t-code">' + U.esc(i.code) + '</div></td>' +
              '<td class="t-sub t-nowrap">' + U.fmtDate(i.occurredAt) + '</td>' +
              '<td class="t-sub">' + (D.isInCare(i) ? days + ' días' : '—') + '</td>' +
              '<td class="t-sub">' + (last === null ? '<span class="text-red">Sin control</span>' : 'Hace ' + last + ' d') + '</td>' +
              '<td>' + (sum.hasDischarge ? UI.badge('Registrada', 'green') : UI.badge('Pendiente', 'gray')) + '</td>' +
              '<td>' + UI.statusBadge(i.status) + '</td>' +
              '<td class="t-right"><span class="btn btn-sm btn-soft">Abrir ' + U.icon('arrowRight') + '</span></td></tr>';
          }).join('') : '<tr><td colspan="8"><div class="table-empty">' + U.icon('stethoscope') + 'No se encontraron historias clínicas.</div></td></tr>';
        }
        search.addEventListener('input', U.debounce(draw, 160));
        U.on(root, '[data-go]', 'click', function () { location.hash = this.getAttribute('data-go'); });
        draw();
      }
    };
  }

  /* ==================================================================
     Detalle de historia clínica
     ================================================================== */
  function detail(params) {
    var intv = Store.intervention(params.id);
    if (!intv) return { html: Views.field.notFound('El animal solicitado no existe o no cuenta con intervención registrada.'), mount: function () {} };
    var u = user();
    var canEdit = Store.can(u.role, 'clinical.edit');
    var canDecide = Store.can(u.role, 'decisions.register');
    var sum = Store.clinicalSummary(intv.id);
    var dec = Store.decisionFor(intv.id);
    var tab = (params.query && params.query.tab) || 'resumen';
    var tabs = [
      { key: 'resumen', label: 'Resumen' },
      { key: 'registros', label: 'Registros clínicos', count: sum.records.filter(function (r) { return r.type === 'evaluacion' || r.type === 'control'; }).length },
      { key: 'vacunas', label: 'Vacunación', count: sum.records.filter(function (r) { return r.type === 'vacuna'; }).length },
      { key: 'dietas', label: 'Dietas', count: sum.records.filter(function (r) { return r.type === 'dieta'; }).length },
      { key: 'evolucion', label: 'Evolución' },
      { key: 'decision', label: 'Decisión técnica' }
    ];
    var h = '<div class="page-head"><div class="ph-text"><a href="#/app/clinica" class="btn btn-ghost btn-sm" style="margin-bottom:.4rem">' + U.icon('arrowLeft') + 'Volver a historias clínicas</a>' +
      '<h1>' + U.esc(intv.speciesName) + '</h1>' +
      '<div class="dh-sub"><span class="code-pill">' + U.esc(intv.code) + '</span>' + UI.statusBadge(intv.status) + UI.priorityBadge(intv.priority.level) +
      '<span class="hint">' + U.icon('user') + ' ' + U.esc(intv.agentName) + '</span></div></div>' +
      '<div class="ph-actions">' +
      (canEdit ? '<button class="btn btn-primary" data-new-record="evaluacion">' + U.icon('plus') + 'Nuevo registro</button>' : '') +
      (canEdit ? '<button class="btn btn-secondary" data-new-record="control">' + U.icon('activity') + 'Control de cuarentena</button>' : '') +
      (canDecide ? '<button class="btn btn-secondary" data-open-decision="' + intv.id + '">' + U.icon('scale') + 'Decisión técnica</button>' : '') +
      '<a class="btn btn-ghost" href="#/app/rescates/' + intv.id + '">' + U.icon('file') + 'Ficha</a></div></div>';

    if (!sum.count) {
      h += '<div class="alert-banner ab-amber">' + U.icon('alert') + '<span><strong>Historia clínica sin registros.</strong> El animal está registrado, pero aún no cuenta con evaluación veterinaria. Registra la primera evaluación para iniciar la cuarentena.</span></div>';
    }
    h += '<div class="grid grid-4 section">' +
      '<div class="card card-pad"><div class="hint">Estado de salud actual</div><div style="margin-top:.3rem">' + (sum.lastControl ? UI.healthBadge(sum.lastControl.health) : UI.badge('Sin evaluación', 'gray')) + '</div>' +
      '<div class="hint" style="margin-top:.4rem">' + (sum.lastControl ? U.fmtDateTime(sum.lastControl.ts) : '—') + '</div></div>' +
      '<div class="card card-pad"><div class="hint">Peso registrado</div><div style="font-size:1.4rem;font-weight:800">' + (sum.lastControl && sum.lastControl.vitals ? sum.lastControl.vitals.weight + ' kg' : '—') + '</div>' +
      '<div class="hint">Último control</div></div>' +
      '<div class="card card-pad"><div class="hint">Días en cuarentena</div><div style="font-size:1.4rem;font-weight:800">' + (D.isInCare(intv) ? Math.max(0, Math.round((Date.now() - new Date(intv.occurredAt).getTime()) / 86400000)) : '—') + '</div>' +
      '<div class="hint">' + U.esc(D.STATUS[intv.status].label) + '</div></div>' +
      '<div class="card card-pad"><div class="hint">Alta médica</div><div style="margin-top:.35rem">' + (sum.hasDischarge ? UI.badge('Registrada', 'green') : UI.badge('Pendiente', 'gray')) + '</div>' +
      '<div class="hint" style="margin-top:.4rem">' + (sum.hasApt ? 'Comportamiento apto registrado' : 'Comportamiento apto pendiente') + '</div></div>' +
      '</div>';

    h += '<div class="split"><div class="card"><div class="card-head" style="padding-bottom:0;border-bottom:0">' + UI.tabs(tabs, tab) + '</div><div class="card-body" id="hc-tab">' + tabContent(tab, intv, sum, dec) + '</div></div>' +
      '<aside style="display:flex;flex-direction:column;gap:1rem">' +
      '<div class="card"><div class="card-head"><h3>Ficha del paciente</h3></div><div class="card-body">' +
      '<div class="meta-grid" style="grid-template-columns:1fr 1fr">' +
      UI.infoRow('Especie', U.esc(intv.speciesName)) + UI.infoRow('Nombre científico', '<em>' + U.esc(intv.scientificName) + '</em>') +
      UI.infoRow('Identificación', U.esc(intv.preliminaryId)) + UI.infoRow('Ingreso', U.fmtDate(intv.occurredAt)) +
      UI.infoRow('Zona', U.esc((intv.location && intv.location.zone) || '—')) + UI.infoRow('Agente', U.esc(intv.agentName)) +
      '</div></div></div>' +
      '<div class="card"><div class="card-head"><h3>Acciones clínicas</h3></div><div class="card-body" style="display:flex;flex-direction:column;gap:.4rem">' +
      (canEdit ? '<button class="btn btn-soft" data-new-record="evaluacion">' + U.icon('stethoscope') + 'Evaluación clínica</button>' +
        '<button class="btn btn-soft" data-new-record="control">' + U.icon('activity') + 'Control de cuarentena</button>' +
        '<button class="btn btn-soft" data-new-record="vacuna">' + U.icon('syringe') + 'Registrar vacuna</button>' +
        '<button class="btn btn-soft" data-new-record="dieta">' + U.icon('utensils') + 'Registrar dieta</button>' +
        '<button class="btn btn-secondary" data-new-record="alta">' + U.icon('checkCircle') + 'Registrar alta médica</button>' : '<p class="hint" style="margin:0">Tu rol no permite editar la historia clínica.</p>') +
      (intv.status === 'registrado' && canEdit ? '<button class="btn btn-ghost" data-admit="' + intv.id + '">' + U.icon('heart') + 'Ingresar a cuarentena</button>' : '') +
      '</div></div>' +
      '<div class="card"><div class="card-head"><h3>Requisitos de liberación</h3></div><div class="card-body">' +
      requirement('Alta médica registrada', sum.hasDischarge) + requirement('Comportamiento apto', sum.hasApt) +
      requirement('Sin decisión previa', !dec) +
      '<p class="hint" style="margin:.6rem 0 0">La liberación solo se habilita cuando se cumplen los tres requisitos (RD005).</p></div></div>' +
      '</aside></div>';

    return {
      html: h,
      mount: function (root) {
        Store.log({ id: u.id, name: u.name, role: u.role }, 'Consulta de historia clínica', 'historia_clinica', intv.id, 'Acceso a la historia clínica de ' + intv.code + '.', true);
        U.on(root, '[data-tab]', 'click', function () {
          location.hash = '#/app/clinica/' + intv.id + '?tab=' + this.getAttribute('data-tab');
        });
        U.on(root, '[data-new-record]', 'click', function () {
          openRecordModal(intv.id, this.getAttribute('data-new-record'), function () { S.App.refresh(); });
        });
        U.on(root, '[data-open-decision]', 'click', function () {
          openDecisionModal(intv.id, function () { S.App.refresh(); });
        });
        U.on(root, '[data-admit]', 'click', function () {
          Store.setStatus(intv.id, 'en_cuarentena', u, 'Ingreso formal a cuarentena para observación clínica.');
          Store.log(u, 'Ingreso a cuarentena', 'intervencion', intv.id, intv.code, true);
          UI.toast('El animal fue registrado como ingresado a cuarentena.', 'success');
          S.App.refresh();
        });
        U.on(root, '[data-photo]', 'click', function () { UI.lightbox(this.getAttribute('data-photo'), this.getAttribute('data-caption')); });
        U.on(root, '[data-monitor]', 'click', function () { openMonitoringModal(intv.id, function () { S.App.refresh(); }); });
      }
    };
  }

  function requirement(label, ok) {
    return '<div style="display:flex;align-items:center;gap:.5rem;padding:.3rem 0;font-size:.78rem">' +
      '<span style="color:' + (ok ? 'var(--green-700)' : 'var(--muted)') + '">' + U.icon(ok ? 'checkCircle' : 'clock') + '</span>' +
      '<span style="flex:1">' + U.esc(label) + '</span>' + (ok ? UI.badge('Cumple', 'green') : UI.badge('Pendiente', 'gray')) + '</div>';
  }

  function tabContent(tab, intv, sum, dec) {
    if (tab === 'registros') {
      var recs = sum.records.filter(function (r) { return r.type === 'evaluacion' || r.type === 'control' || r.type === 'alta'; }).slice().reverse();
      if (!recs.length) return UI.empty('stethoscope', 'Sin registros clínicos', 'Registra la primera evaluación para iniciar la historia clínica digital.');
      return '<div class="timeline">' + recs.map(function (r) {
        return '<div class="tl-item ' + (r.discharge ? '' : r.health === 'critico' || r.health === 'grave' ? 'tl-red' : 'tl-amber') + '">' +
          '<div class="tl-head"><span class="tl-title">' + U.esc(D.RECORD_TYPES[r.type] ? D.RECORD_TYPES[r.type].label : 'Registro') + '</span>' +
          UI.healthBadge(r.health) + (r.discharge ? UI.badge('Alta médica', 'green') : '') +
          '<span class="tl-time">' + U.fmtDateTime(r.ts) + ' · ' + U.esc(r.vetName) + '</span></div>' +
          (r.vitals ? '<div class="kpi-row" style="margin:.45rem 0;grid-template-columns:repeat(auto-fit,minmax(90px,1fr))">' +
            '<div class="kpi-mini"><div class="km-val">' + r.vitals.fc + '</div><div class="km-lbl">FC (lpm)</div></div>' +
            '<div class="kpi-mini"><div class="km-val">' + r.vitals.fr + '</div><div class="km-lbl">FR (rpm)</div></div>' +
            '<div class="kpi-mini"><div class="km-val">' + r.vitals.temp + '°</div><div class="km-lbl">Temperatura</div></div>' +
            '<div class="kpi-mini"><div class="km-val">' + r.vitals.weight + '</div><div class="km-lbl">Peso (kg)</div></div></div>' : '') +
          (r.diagnosis ? '<div class="tl-body"><strong>Diagnóstico:</strong> ' + U.esc(r.diagnosis) + '</div>' : '') +
          (r.medications && r.medications.length ? '<div class="tl-body"><strong>Medicamentos:</strong> ' + r.medications.map(function (m) {
            return U.esc(m.name + ' · ' + m.dose + ' · ' + m.route + ' · ' + m.freq + ' · ' + m.days + ' días');
          }).join(' | ') + '</div>' : '') +
          (r.treatment ? '<div class="tl-body"><strong>Tratamiento:</strong> ' + U.esc(r.treatment) + '</div>' : '') +
          (r.observations ? '<div class="tl-changes">' + U.esc(r.observations) + '</div>' : '') +
          '</div>';
      }).join('') + '</div>';
    }
    if (tab === 'vacunas') {
      var vacs = sum.records.filter(function (r) { return r.type === 'vacuna'; }).slice().reverse();
      if (!vacs.length) return UI.empty('syringe', 'Sin vacunas registradas', 'Las vacunas administradas se registran con fecha, dosis y responsable.');
      return '<div class="table-wrap"><table class="tbl"><thead><tr><th>Vacuna</th><th>Dosis</th><th>Lote</th><th>Fecha</th><th>Responsable</th></tr></thead><tbody>' +
        vacs.map(function (r) {
          return '<tr><td class="t-main">' + U.esc(r.vaccineName) + '</td><td>' + U.esc(r.vaccineDose || '—') + '</td><td class="t-code">' + U.esc(r.vaccineLot || '—') + '</td>' +
            '<td class="t-sub">' + U.fmtDateTime(r.ts) + '</td><td class="t-sub">' + U.esc(r.vetName) + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }
    if (tab === 'dietas') {
      var diets = sum.records.filter(function (r) { return r.type === 'dieta'; }).slice().reverse();
      if (!diets.length) return UI.empty('utensils', 'Sin dietas registradas', 'Registra las dietas diarias para llevar el control alimentario del animal.');
      return '<div class="table-wrap"><table class="tbl"><thead><tr><th>Dieta</th><th>Cantidad</th><th>Fecha</th><th>Responsable</th><th>Observaciones</th></tr></thead><tbody>' +
        diets.map(function (r) {
          return '<tr><td class="t-main">' + U.esc(r.diet) + '</td><td>' + U.esc(r.dietQty || '—') + '</td><td class="t-sub">' + U.fmtDateTime(r.ts) + '</td>' +
            '<td class="t-sub">' + U.esc(r.vetName) + '</td><td class="t-sub">' + U.esc(r.observations || '—') + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }
    if (tab === 'evolucion') {
      var weights = sum.weights;
      var healthSeries = sum.healthSeries;
      return '<div class="section"><h3 style="font-size:.9rem;margin-bottom:.4rem">Evolución del peso</h3>' +
        Charts.line([{ points: weights, color: '#1b7a56', label: 'Peso registrado (kg)' }], { height: 190, aria: 'Evolución del peso' }) +
        '</div><div class="section"><h3 style="font-size:.9rem;margin-bottom:.4rem">Evolución del estado de salud</h3>' +
        Charts.line([{ points: healthSeries, color: '#b7791f', label: 'Escala: 1 crítico · 5 excelente' }], { height: 170, aria: 'Evolución del estado de salud' }) +
        '</div><div class="table-wrap"><table class="tbl"><thead><tr><th>Fecha</th><th>Peso</th><th>Estado</th><th>Control</th></tr></thead><tbody>' +
        (sum.records.filter(function (r) { return r.type === 'control' || r.type === 'evaluacion'; }).slice().reverse().map(function (r) {
          return '<tr><td class="t-sub">' + U.fmtDateTime(r.ts) + '</td><td>' + (r.vitals ? r.vitals.weight + ' kg' : '—') + '</td>' +
            '<td>' + UI.healthBadge(r.health) + '</td><td class="t-sub">' + U.esc(r.observations || r.diagnosis || '—') + '</td></tr>';
        }).join('') || '<tr><td colspan="4" class="table-empty">Sin controles registrados.</td></tr>') + '</tbody></table></div>';
    }
    if (tab === 'decision') {
      var avail = D.decisionAvailability(intv, sum.records);
      var labels = { liberacion: 'Liberación', custodia: 'Custodia permanente', eutanasia: 'Eutanasia' };
      var tones = { liberacion: 'green', custodia: 'purple', eutanasia: 'gray' };
      if (dec) {
        return '<div class="alert-banner ab-green" style="margin-top:0">' + U.icon('checkCircle') + '<span><strong>Decisión registrada.</strong> El historial conserva la evaluación, la justificación y el responsable.</span></div>' +
          '<div class="meta-grid">' + UI.infoRow('Decisión', UI.badge(labels[dec.type], tones[dec.type])) + UI.infoRow('Fecha', U.fmtDateTime(dec.ts)) +
          UI.infoRow('Responsable', U.esc(dec.vetName)) + (dec.destination ? UI.infoRow('Destino', U.esc(dec.destination)) : '') +
          (dec.releasePlace ? UI.infoRow('Lugar de liberación', U.esc(dec.releasePlace)) : '') + '</div>' +
          '<div class="divider"></div><div class="fs-75"><strong>Justificación</strong><p style="margin:.3rem 0 0;color:var(--ink-soft)">' + U.esc(dec.justification) + '</p></div>' +
          (dec.type === 'liberacion' ? '<div class="divider"></div><div class="section-head"><h3 style="font-size:.9rem">Monitoreo post-liberación</h3>' +
            '<div class="sh-actions"><button class="btn btn-sm btn-soft" data-monitor>' + U.icon('plus') + 'Añadir observación</button></div></div>' +
            (dec.monitoring.length ? '<div class="timeline">' + dec.monitoring.slice().reverse().map(function (m) {
              return '<div class="tl-item"><div class="tl-head"><span class="tl-title">Observación de adaptación</span><span class="tl-time">' + U.fmtDateTime(m.ts) + ' · ' + U.esc(m.vetName) + '</span></div>' +
                '<div class="tl-body">' + U.esc(m.observations) + '</div></div>';
            }).join('') + '</div>' : '<p class="hint">Aún no se registran observaciones de adaptación al hábitat.</p>') : '') +
          '<div class="divider"></div><div class="note">' + U.icon('lock') + '<span>La decisión forma parte del historial del animal y no puede eliminarse. Los usuarios sin permisos no pueden modificarla.</span></div>';
      }
      return '<div class="grid grid-3" style="margin-bottom:1rem">' +
        decisionOption('liberacion', 'Liberación', 'Requiere alta médica y comportamiento apto.', avail.liberacion.enabled, avail.liberacion.reason) +
        decisionOption('custodia', 'Custodia permanente', 'Requiere centro de destino y justificación.', avail.custodia.enabled, avail.custodia.reason) +
        decisionOption('eutanasia', 'Eutanasia', 'Requiere diagnóstico o condición terminal.', avail.eutanasia.enabled, avail.eutanasia.reason) +
        '</div>' +
        '<div class="alert-banner ' + (avail.liberacion.enabled ? 'ab-green' : 'ab-amber') + '">' + U.icon('info') +
        '<span>' + (avail.liberacion.enabled ? '<strong>El animal cumple los requisitos para liberación.</strong> Registra la decisión con fecha y lugar de liberación.' :
          '<strong>Liberación no habilitada.</strong> ' + U.esc(avail.liberacion.reason)) + '</span></div>' +
        (Store.can(user().role, 'decisions.register') ? '<button class="btn btn-primary" data-open-decision="' + intv.id + '">' + U.icon('scale') + 'Registrar decisión técnica</button>' :
          '<p class="hint">Solo el Médico Veterinario puede registrar la decisión técnica.</p>') +
        '<div class="divider"></div><div class="note">' + U.icon('shieldCheck') + '<span>El sistema valida el rol, la existencia del animal, el alta médica y la justificación antes de guardar la decisión (RD005).</span></div>';
    }
    /* Resumen */
    return '<div class="grid grid-2" style="gap:1rem">' +
      '<div><h3 style="font-size:.9rem;margin-bottom:.5rem">Último control</h3>' +
      (sum.lastControl ? '<div class="kpi-row" style="grid-template-columns:1fr 1fr">' +
        '<div class="kpi-mini"><div class="km-val">' + (sum.lastControl.vitals ? sum.lastControl.vitals.fc : '—') + '</div><div class="km-lbl">FC</div></div>' +
        '<div class="kpi-mini"><div class="km-val">' + (sum.lastControl.vitals ? sum.lastControl.vitals.fr : '—') + '</div><div class="km-lbl">FR</div></div>' +
        '<div class="kpi-mini"><div class="km-val">' + (sum.lastControl.vitals ? sum.lastControl.vitals.temp + '°' : '—') + '</div><div class="km-lbl">Temperatura</div></div>' +
        '<div class="kpi-mini"><div class="km-val">' + (sum.lastControl.vitals ? sum.lastControl.vitals.weight : '—') + '</div><div class="km-lbl">Peso</div></div></div>' +
        '<p class="hint" style="margin:.6rem 0 0">' + U.esc(sum.lastControl.diagnosis || sum.lastControl.observations) + '</p>' +
        '<p class="hint">' + U.fmtDateTime(sum.lastControl.ts) + ' · ' + U.esc(sum.lastControl.vetName) + '</p>' :
        '<p class="hint">Sin controles registrados.</p>') +
      '<div class="divider"></div><h3 style="font-size:.9rem;margin-bottom:.5rem">Último tratamiento</h3>' +
      (sum.lastControl && sum.lastControl.medications && sum.lastControl.medications.length ? sum.lastControl.medications.map(function (m) {
        return '<div class="list-item"><div class="li-icon">' + U.icon('syringe') + '</div><div class="li-main"><div class="li-title">' + U.esc(m.name) + '</div>' +
          '<div class="li-sub">' + U.esc(m.dose + ' · ' + m.route + ' · ' + m.freq + ' · ' + m.days + ' días') + '</div></div></div>';
      }).join('') : '<p class="hint">Sin medicamentos registrados.</p>') + '</div>' +
      '<div><h3 style="font-size:.9rem;margin-bottom:.5rem">Triaje de ingreso</h3>' + Views.field.scoreRing(intv.priority) +
      '<p style="font-size:.78rem;margin-top:.5rem;color:var(--ink-soft)">' + U.esc(intv.priority.name) + ' — ' + U.esc(intv.priority.reason) + '</p>' +
      '<div class="divider"></div><h3 style="font-size:.9rem;margin-bottom:.5rem">Historial</h3>' +
      '<div class="timeline">' + intv.history.slice(-5).reverse().map(function (ev) {
        return '<div class="tl-item"><div class="tl-head"><span class="tl-title">' + U.esc(ev.action) + '</span><span class="tl-time">' + U.fmtDate(ev.ts) + '</span></div>' +
          '<div class="tl-body">' + U.esc(ev.detail) + '</div></div>';
      }).join('') + '</div></div></div>';
  }

  function decisionOption(type, title, desc, enabled, reason) {
    return '<div class="card card-pad" style="opacity:' + (enabled ? '1' : '.65') + '">' +
      '<div class="pill-row">' + UI.badge(title, type === 'liberacion' ? 'green' : type === 'custodia' ? 'purple' : 'gray') + '</div>' +
      '<p style="font-size:.76rem;color:var(--ink-soft);margin:.5rem 0 .3rem">' + U.esc(desc) + '</p>' +
      '<p class="hint" style="margin:0">' + U.esc(reason) + '</p></div>';
  }

  /* ==================================================================
     Modal: registro clínico
     ================================================================== */
  function openRecordModal(interventionId, type, onDone) {
    var intv = Store.intervention(interventionId);
    if (!intv) return;
    var u = user();
    if (!Store.can(u.role, 'clinical.edit')) { UI.toast('Tu rol no permite editar la historia clínica.', 'error'); return; }
    var titles = {
      evaluacion: ['Nueva evaluación clínica', 'Signos clínicos, diagnóstico y tratamiento'],
      control: ['Control de cuarentena', 'Seguimiento periódico del estado de salud'],
      vacuna: ['Registrar vacuna', 'Vacuna administrada, dosis y lote'],
      dieta: ['Registrar dieta diaria', 'Alimentación suministrada durante la cuarentena'],
      alta: ['Registrar alta médica', 'Habilita la evaluación de liberación del animal']
    };
    var t = titles[type] || titles.evaluacion;
    var vitalsBlock = (type === 'evaluacion' || type === 'control') ?
      '<fieldset class="form-section"><div class="fs-title">' + U.icon('activity') + 'Signos clínicos</div><div class="form-grid">' +
      '<div class="field"><label for="rec-fc">Frecuencia cardíaca (lpm) <span class="req">*</span></label><input class="input" id="rec-fc" type="number" min="10" max="400" step="1" placeholder="Ej. 92"></div>' +
      '<div class="field"><label for="rec-fr">Frecuencia respiratoria (rpm) <span class="req">*</span></label><input class="input" id="rec-fr" type="number" min="2" max="200" step="1" placeholder="Ej. 24"></div>' +
      '<div class="field"><label for="rec-temp">Temperatura (°C) <span class="req">*</span></label><input class="input" id="rec-temp" type="number" min="20" max="45" step="0.1" placeholder="Ej. 37.8"></div>' +
      '<div class="field"><label for="rec-weight">Peso (kg)</label><input class="input" id="rec-weight" type="number" min="0.05" max="600" step="0.1" placeholder="Ej. 12.4"></div>' +
      '<div class="field"><label for="rec-body">Condición corporal (1–5)</label><select class="select" id="rec-body"><option value="1">1 · Muy deficiente</option><option value="2">2 · Deficiente</option><option value="3" selected>3 · Adecuada</option><option value="4">4 · Buena</option><option value="5">5 · Excelente</option></select></div>' +
      '<div class="field"><label for="rec-health">Estado de salud <span class="req">*</span></label><select class="select" id="rec-health">' +
      Object.keys(D.HEALTH).map(function (k) { return '<option value="' + k + '"' + (k === 'estable' ? ' selected' : '') + '>' + D.HEALTH[k].label + '</option>'; }).join('') + '</select></div>' +
      '</div></fieldset>' : '';

    var diagnosisBlock = (type === 'evaluacion' || type === 'alta' || type === 'control') ?
      '<fieldset class="form-section"><div class="fs-title">' + U.icon('stethoscope') + 'Diagnóstico y tratamiento</div><div class="form-grid">' +
      '<div class="field span-2"><label for="rec-diag">Diagnóstico ' + (type === 'evaluacion' || type === 'alta' ? '<span class="req">*</span>' : '') + '</label>' +
      '<textarea class="textarea" id="rec-diag" placeholder="Descripción del cuadro clínico y diagnóstico presuntivo…"></textarea></div>' +
      (type !== 'alta' ? '<div class="field span-2"><label>Medicamentos</label><div id="med-rows"></div>' +
        '<button class="btn btn-sm btn-ghost" type="button" id="add-med" style="align-self:flex-start;margin-top:.3rem">' + U.icon('plus') + 'Añadir medicamento</button></div>' +
        '<div class="field span-2"><label for="rec-treat">Tratamiento indicado</label><textarea class="textarea" id="rec-treat" placeholder="Indicaciones, frecuencia y duración del tratamiento…"></textarea></div>' : '') +
      '</div></fieldset>' : '';

    var vaccineBlock = type === 'vacuna' ?
      '<fieldset class="form-section"><div class="fs-title">' + U.icon('syringe') + 'Vacunación</div><div class="form-grid">' +
      '<div class="field span-2"><label for="rec-vaccine">Vacuna administrada <span class="req">*</span></label><input class="input" id="rec-vaccine" placeholder="Ej. Vacuna antirrábica veterinaria"></div>' +
      '<div class="field"><label for="rec-vdose">Dosis</label><input class="input" id="rec-vdose" placeholder="Ej. 1 ml"></div>' +
      '<div class="field"><label for="rec-vlot">Lote</label><input class="input" id="rec-vlot" placeholder="Ej. VR-2026-07"></div>' +
      '</div></fieldset>' : '';

    var dietBlock = type === 'dieta' ?
      '<fieldset class="form-section"><div class="fs-title">' + U.icon('utensils') + 'Dieta diaria</div><div class="form-grid">' +
      '<div class="field span-2"><label for="rec-diet">Dieta suministrada <span class="req">*</span></label><input class="input" id="rec-diet" placeholder="Ej. Frutas variadas y proteína animal"></div>' +
      '<div class="field"><label for="rec-dietqty">Cantidad</label><input class="input" id="rec-dietqty" placeholder="Ej. 450 g / 2 raciones"></div>' +
      '<div class="field"><label for="rec-dietfreq">Frecuencia</label><input class="input" id="rec-dietfreq" placeholder="Ej. 2 veces al día"></div>' +
      '</div></fieldset>' : '';

    var dischargeBlock = (type === 'evaluacion' || type === 'control' || type === 'alta') ?
      '<fieldset class="form-section" style="background:var(--green-50);border-color:#cbe8da"><div class="fs-title" style="color:var(--green-800)">' + U.icon('checkCircle') + 'Evaluación de aptitud</div>' +
      '<div style="display:flex;flex-direction:column;gap:.5rem">' +
      (type === 'alta' ? '<input type="hidden" id="rec-discharge" checked>' :
        '<label class="check"><input type="checkbox" id="rec-discharge"> <span><strong>Alta médica.</strong> El animal se encuentra clínicamente apto para egresar de cuarentena.</span></label>') +
      '<label class="check"><input type="checkbox" id="rec-apt"> <span><strong>Comportamiento apto para liberación.</strong> Manifiesta conductas compatibles con la vida silvestre.</span></label>' +
      '</div></fieldset>' : '';

    var body = '<div class="alert-banner ab-blue" style="margin-top:0">' + U.icon('paw') +
      '<span><strong>' + U.esc(intv.speciesName) + '</strong> · ' + U.esc(intv.code) + ' · ' + U.esc(intv.preliminaryId) + '</span></div>' +
      vitalsBlock + diagnosisBlock + vaccineBlock + dietBlock + dischargeBlock +
      '<fieldset class="form-section"><div class="fs-title">' + U.icon('clipboard') + 'Observaciones</div>' +
      '<div class="field"><label for="rec-obs">Observaciones del control</label><textarea class="textarea" id="rec-obs" placeholder="Evolución, comportamiento, tolerancia al tratamiento…"></textarea></div>' +
      '<p class="hint" style="margin:.4rem 0 0">El registro conservará la fecha, hora y el Médico Veterinario responsable.</p></fieldset>';

    var m = UI.modal({
      title: t[0], subtitle: t[1], size: 'lg', body: body,
      footer: '<button class="btn btn-secondary" type="button" data-close-modal>Cancelar</button>' +
        '<button class="btn btn-primary" type="button" id="rec-save">' + U.icon('save') + 'Guardar registro</button>'
    });
    m.el.querySelector('[data-close-modal]').addEventListener('click', UI.closeModal);

    var medCount = 0;
    function addMedRow() {
      if (type === 'alta') return;
      medCount++;
      var row = document.createElement('div');
      row.className = 'med-row';
      row.style.cssText = 'display:grid;grid-template-columns:1.4fr .8fr .7fr 1fr .5fr auto;gap:.35rem;margin-bottom:.35rem;align-items:center';
      row.innerHTML = '<input class="input" placeholder="Medicamento" data-med="name">' +
        '<input class="input" placeholder="Dosis" data-med="dose">' +
        '<input class="input" placeholder="Vía" data-med="route">' +
        '<input class="input" placeholder="Frecuencia" data-med="freq">' +
        '<input class="input" type="number" min="1" max="90" placeholder="Días" data-med="days" value="5">' +
        '<button class="btn btn-ghost btn-sm" type="button" aria-label="Quitar">' + U.icon('x') + '</button>';
      row.querySelector('button').addEventListener('click', function () { row.remove(); });
      m.el.querySelector('#med-rows').appendChild(row);
    }
    var medRows = m.el.querySelector('#med-rows');
    var addMedBtn = m.el.querySelector('#add-med');
    if (type !== 'alta' && medRows && addMedBtn) { addMedRow(); addMedBtn.addEventListener('click', addMedRow); }

    m.el.querySelector('#rec-save').addEventListener('click', function () {
      var data = { type: type, health: (m.el.querySelector('#rec-health') || {}).value || (type === 'alta' ? 'bueno' : 'estable'), ts: U.nowISO() };
      if (type === 'evaluacion' || type === 'control') {
        var fc = U.num((m.el.querySelector('#rec-fc') || {}).value);
        var fr = U.num((m.el.querySelector('#rec-fr') || {}).value);
        var temp = U.num((m.el.querySelector('#rec-temp') || {}).value);
        if (!fc || !fr || !temp) { UI.toast('Complete los signos vitales: frecuencia cardíaca, respiratoria y temperatura.', 'error'); return; }
        data.vitals = { fc: fc, fr: fr, temp: temp, weight: U.num((m.el.querySelector('#rec-weight') || {}).value) || null, bodyCondition: U.num((m.el.querySelector('#rec-body') || {}).value) || 3 };
        data.diagnosis = (m.el.querySelector('#rec-diag') || {}).value || '';
        data.treatment = (m.el.querySelector('#rec-treat') || {}).value || '';
        if (type === 'evaluacion' && data.diagnosis.trim().length < 5) { UI.toast('Registre el diagnóstico de la evaluación.', 'error'); return; }
      }
      if (type === 'vacuna') {
        data.vaccineName = (m.el.querySelector('#rec-vaccine') || {}).value || '';
        data.vaccineDose = (m.el.querySelector('#rec-vdose') || {}).value || '';
        data.vaccineLot = (m.el.querySelector('#rec-vlot') || {}).value || '';
        if (!data.vaccineName.trim()) { UI.toast('Indique el nombre de la vacuna.', 'error'); return; }
      }
      if (type === 'dieta') {
        data.diet = (m.el.querySelector('#rec-diet') || {}).value || '';
        data.dietQty = [(m.el.querySelector('#rec-dietqty') || {}).value, (m.el.querySelector('#rec-dietfreq') || {}).value].filter(Boolean).join(' · ');
        if (!data.diet.trim()) { UI.toast('Describa la dieta suministrada.', 'error'); return; }
      }
      if (type === 'alta') {
        data.diagnosis = (m.el.querySelector('#rec-diag') || {}).value || '';
        if (data.diagnosis.trim().length < 5) { UI.toast('Registre el sustento clínico del alta médica.', 'error'); return; }
        data.discharge = true;
      }
      var discharge = m.el.querySelector('#rec-discharge');
      if (discharge) data.discharge = !!discharge.checked;
      var apt = m.el.querySelector('#rec-apt');
      if (apt) data.behaviorApt = !!apt.checked;
      data.observations = (m.el.querySelector('#rec-obs') || {}).value || '';
      if (type !== 'alta') {
        data.medications = U.$$('.med-row', m.el).map(function (row) {
          return {
            name: row.querySelector('[data-med="name"]').value.trim(),
            dose: row.querySelector('[data-med="dose"]').value.trim(),
            route: row.querySelector('[data-med="route"]').value.trim(),
            freq: row.querySelector('[data-med="freq"]').value.trim(),
            days: U.num(row.querySelector('[data-med="days"]').value)
          };
        }).filter(function (x) { return x.name; });
      }
      try {
        Store.addRecord(interventionId, data, u);
        UI.closeModal();
        UI.toast(data.discharge ? 'Alta médica registrada. Se habilita la evaluación de liberación.' : 'Registro clínico guardado en la historia del animal.', 'success');
        if (onDone) onDone();
      } catch (err) { UI.toast(err.message, 'error'); }
    });
  }

  /* ==================================================================
     Modal: decisión técnica (RF008 / RD005)
     ================================================================== */
  function openDecisionModal(interventionId, onDone) {
    var intv = Store.intervention(interventionId);
    if (!intv) return;
    var u = user();
    if (!Store.can(u.role, 'decisions.register')) { UI.toast('Solo el Médico Veterinario puede registrar la decisión técnica.', 'error'); return; }
    var sum = Store.clinicalSummary(interventionId);
    var avail = D.decisionAvailability(intv, sum.records);
    var body = '<div class="alert-banner ab-blue" style="margin-top:0">' + U.icon('paw') +
      '<span><strong>' + U.esc(intv.speciesName) + '</strong> · ' + U.esc(intv.code) + ' · ' + U.esc(intv.preliminaryId) + '</span></div>' +
      '<div class="card card-pad" style="margin-bottom:1rem;background:var(--sand-50)">' +
      '<div class="fs-title" style="font-size:.72rem;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:var(--green-800);margin-bottom:.5rem">Requisitos verificados</div>' +
      requirement('Historia clínica con alta médica', sum.hasDischarge) +
      requirement('Comportamiento apto para liberación', sum.hasApt) +
      requirement('Sin decisión técnica previa', !avail.blocked) +
      '</div>' +
      '<div class="radio-cards" id="dec-options">' +
      decisionRadio('liberacion', 'Liberación', 'Devuelto a su hábitat natural. Requiere alta médica y comportamiento apto.', avail.liberacion.enabled, avail.liberacion.reason) +
      decisionRadio('custodia', 'Custodia permanente', 'Traslado a un centro de custodia autorizado. Requiere destino y justificación.', avail.custodia.enabled, avail.custodia.reason) +
      decisionRadio('eutanasia', 'Eutanasia humanitaria', 'Aplicable ante condición terminal o sufrimiento irreversible. Requiere justificación médica.', avail.eutanasia.enabled, avail.eutanasia.reason) +
      '</div>' +
      '<div id="dec-fields" style="margin-top:1rem"></div>';

    var m = UI.modal({
      title: 'Decisión técnica final', subtitle: intv.code + ' · ' + intv.speciesName, size: 'lg', body: body,
      footer: '<button class="btn btn-secondary" type="button" data-close-modal>Cancelar</button>' +
        '<button class="btn btn-primary" type="button" id="dec-save">' + U.icon('save') + 'Registrar decisión</button>'
    });
    m.el.querySelector('[data-close-modal]').addEventListener('click', UI.closeModal);

    function fieldsFor(type) {
      if (type === 'liberacion') {
        return '<div class="form-grid"><div class="field"><label for="dec-date">Fecha de liberación <span class="req">*</span></label>' +
          '<input class="input" id="dec-date" type="date" value="' + U.attr(U.toLocalInput().slice(0, 10)) + '"></div>' +
          '<div class="field"><label for="dec-place">Lugar de liberación <span class="req">*</span></label><input class="input" id="dec-place" placeholder="Ej. Reserva paisajística Nor Yauyos Cochas"></div>' +
          '<div class="field span-2"><label for="dec-just">Justificación técnica <span class="req">*</span></label><textarea class="textarea" id="dec-just" placeholder="Sustento de la aptitud clínica y conductual para la liberación…"></textarea></div></div>';
      }
      if (type === 'custodia') {
        return '<div class="form-grid"><div class="field span-2"><label for="dec-dest">Centro o zoológico de destino <span class="req">*</span></label>' +
          '<input class="input" id="dec-dest" list="dest-list" placeholder="Ej. Zoológico Municipal del Cerrito de la Libertad">' +
          '<datalist id="dest-list"><option value="Zoológico Municipal del Cerrito de la Libertad"><option value="Centro de Custodia Temporal de Fauna Silvestre – Satipo"><option value="CCTFS Lima"><option value="Centro de Conservación de Fauna Silvestre – Huancayo"></datalist></div>' +
          '<div class="field span-2"><label for="dec-just">Justificación del traslado <span class="req">*</span></label><textarea class="textarea" id="dec-just" placeholder="Motivos por los que el animal no es apto para liberación…"></textarea></div></div>';
      }
      return '<div class="form-grid"><div class="field span-2"><label for="dec-just">Diagnóstico o condición terminal <span class="req">*</span></label>' +
        '<textarea class="textarea" id="dec-just" placeholder="Diagnóstico, pronóstico y sustento del protocolo de bienestar animal…"></textarea></div>' +
        '<div class="alert-banner ab-red span-2" style="margin:0">' + U.icon('alert') + '<span>La eutanasia es una decisión excepcional y debe sustentarse en el bienestar animal y la normativa vigente.</span></div></div>';
    }

    var selected = null;
    function selectType(type) {
      var radio = m.el.querySelector('input[name="dec-type"][value="' + type + '"]');
      if (radio) radio.checked = true;
      selected = type;
      m.el.querySelector('#dec-fields').innerHTML = fieldsFor(type);
    }
    U.on(m.el, 'input[name="dec-type"]', 'change', function () { selectType(this.value); });
    var first = ['liberacion', 'custodia', 'eutanasia'].filter(function (t) { return avail[t].enabled; })[0];
    if (first) selectType(first);

    m.el.querySelector('#dec-save').addEventListener('click', function () {
      if (!selected) { UI.toast('Seleccione una decisión técnica.', 'error'); return; }
      var data = { type: selected, justification: (m.el.querySelector('#dec-just') || {}).value || '' };
      if (selected === 'liberacion') {
        data.releaseDate = (m.el.querySelector('#dec-date') || {}).value || '';
        data.releasePlace = (m.el.querySelector('#dec-place') || {}).value || '';
      }
      if (selected === 'custodia') data.destination = (m.el.querySelector('#dec-dest') || {}).value || '';
      var check = D.validateDecision(selected, data);
      if (!check.ok) { UI.toast(check.error, 'error'); return; }
      if (selected === 'liberacion' && !avail.liberacion.enabled) { UI.toast(avail.liberacion.reason, 'error'); return; }
      function commit() {
        try {
          Store.saveDecision(interventionId, data, u);
          UI.closeModal();
          UI.toast('Decisión técnica registrada y conservada en el historial del animal.', 'success');
          if (onDone) onDone();
        } catch (err) { UI.toast(err.message, 'error'); }
      }
      if (selected === 'eutanasia') {
        UI.confirm({ title: 'Confirmar eutanasia', message: 'Esta decisión quedará registrada de forma permanente en el historial del animal. ¿Desea continuar?', confirmLabel: 'Confirmar eutanasia', danger: true }).then(function (ok) { if (ok) commit(); });
      } else commit();
    });
  }
  function decisionRadio(type, title, desc, enabled, reason) {
    return '<label class="radio-card" style="' + (enabled ? '' : 'opacity:.6') + '">' +
      '<input type="radio" name="dec-type" value="' + type + '"' + (enabled ? '' : ' disabled') + '>' +
      '<span style="flex:1"><span class="rc-title">' + U.esc(title) + '</span><span class="rc-desc">' + U.esc(desc) + '</span>' +
      (!enabled ? '<span class="rc-desc" style="color:var(--amber-600);font-weight:600">' + U.esc(reason) + '</span>' : '') + '</span></label>';
  }

  /* ==================================================================
     Modal: monitoreo post-liberación (PG-31)
     ================================================================== */
  function openMonitoringModal(interventionId, onDone) {
    var intv = Store.intervention(interventionId);
    var dec = Store.decisionFor(interventionId);
    if (!intv || !dec) return;
    var m = UI.modal({
      title: 'Monitoreo post-liberación', subtitle: intv.code + ' · ' + intv.speciesName,
      body: '<div class="alert-banner ab-green" style="margin-top:0">' + U.icon('leaf') +
        '<span>Registra observaciones de adaptación al hábitat. El historial de monitoreo queda asociado al animal.</span></div>' +
        '<div class="field"><label for="mon-obs">Observaciones de adaptación <span class="req">*</span></label>' +
        '<textarea class="textarea" id="mon-obs" placeholder="Desplazamiento, alimentación, interacción con la fauna local, estado físico…"></textarea></div>' +
        (dec.monitoring.length ? '<div class="divider"></div><div class="hint"><strong>Monitoreos previos:</strong> ' + dec.monitoring.length + '</div>' : ''),
      footer: '<button class="btn btn-secondary" type="button" data-close-modal>Cancelar</button>' +
        '<button class="btn btn-primary" type="button" id="mon-save">' + U.icon('save') + 'Guardar observación</button>'
    });
    m.el.querySelector('[data-close-modal]').addEventListener('click', UI.closeModal);
    m.el.querySelector('#mon-save').addEventListener('click', function () {
      try {
        Store.addMonitoring(interventionId, { observations: m.el.querySelector('#mon-obs').value }, user());
        UI.closeModal();
        UI.toast('Observación de monitoreo registrada.', 'success');
        if (onDone) onDone();
      } catch (err) { UI.toast(err.message, 'error'); }
    });
  }

  Views.clinical = {
    list: list, detail: detail,
    openRecordModal: openRecordModal, openDecisionModal: openDecisionModal,
    openMonitoringModal: openMonitoringModal
  };
})(typeof window !== 'undefined' ? window : this);

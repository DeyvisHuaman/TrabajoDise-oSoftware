/* Utilidades generales: formato, DOM, iconografía y descargas. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};

  function esc(value) {
    if (value === null || value === undefined) return '';
    return String(value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function attr(value) { return esc(value); }
  function uid(prefix) {
    var rnd = Math.random().toString(36).slice(2, 8);
    return (prefix || 'id') + '_' + Date.now().toString(36) + rnd;
  }
  function num(value, fallback) {
    var n = Number(value);
    return isFinite(n) ? n : (fallback === undefined ? 0 : fallback);
  }
  function clamp(n, min, max) { return Math.min(max, Math.max(min, n)); }
  function round(n, dec) { var p = Math.pow(10, dec || 0); return Math.round(n * p) / p; }

  /* ---------- Fechas ---------- */
  function toDate(value) { return value instanceof Date ? value : new Date(value); }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  var MONTHS = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  var MONTHS_LONG = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  function fmtDate(value) {
    if (!value) return '—';
    var d = toDate(value); if (isNaN(d)) return '—';
    return d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
  }
  function fmtDateLong(value) {
    if (!value) return '—';
    var d = toDate(value); if (isNaN(d)) return '—';
    return d.getDate() + ' de ' + MONTHS_LONG[d.getMonth()] + ' de ' + d.getFullYear();
  }
  function fmtTime(value) {
    if (!value) return '—';
    var d = toDate(value); if (isNaN(d)) return '—';
    return pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  function fmtDateTime(value) {
    if (!value) return '—';
    var d = toDate(value); if (isNaN(d)) return '—';
    return fmtDate(d) + ', ' + fmtTime(d);
  }
  function fmtShort(value) {
    if (!value) return '—';
    var d = toDate(value); if (isNaN(d)) return '—';
    return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear();
  }
  function fmtMonth(value) {
    var d = toDate(value); if (isNaN(d)) return '—';
    return MONTHS[d.getMonth()] + ' ' + String(d.getFullYear()).slice(2);
  }
  function nowISO() { return new Date().toISOString(); }
  function toLocalInput(value) {
    var d = value ? toDate(value) : new Date();
    if (isNaN(d)) d = new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  function dayKey(value) {
    var d = toDate(value);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function daysUntil(value) {
    if (!value) return null;
    var target = new Date(value);
    if (isNaN(target)) return null;
    var today = new Date();
    var a = Date.UTC(today.getFullYear(), today.getMonth(), today.getDate());
    var b = Date.UTC(target.getFullYear(), target.getMonth(), target.getDate());
    return Math.round((b - a) / 86400000);
  }
  function timeAgo(value) {
    var d = toDate(value); if (isNaN(d)) return '—';
    var diff = Math.round((Date.now() - d.getTime()) / 1000);
    if (diff < 60) return 'hace unos segundos';
    if (diff < 3600) return 'hace ' + Math.floor(diff / 60) + ' min';
    if (diff < 86400) return 'hace ' + Math.floor(diff / 3600) + ' h';
    if (diff < 86400 * 7) return 'hace ' + Math.floor(diff / 86400) + ' d';
    return fmtDate(d);
  }
  function addDays(value, days) {
    var base = value ? toDate(value) : new Date();
    var d = new Date(base.getTime());
    d.setDate(d.getDate() + days);
    return d;
  }

  /* ---------- Texto ---------- */
  function initials(name) {
    if (!name) return '??';
    var parts = String(name).trim().split(/\s+/).slice(0, 2);
    return parts.map(function (p) { return p.charAt(0).toUpperCase(); }).join('') || '??';
  }
  function titleCase(text) {
    return String(text || '').toLowerCase().replace(/(^|\s|\/)([a-záéíóúñ])/g, function (m, sp, ch) { return sp + ch.toUpperCase(); });
  }
  function normalize(text) {
    return String(text || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }
  function plural(n, one, many) { return n === 1 ? one : many; }
  function truncate(text, max) {
    text = String(text || '');
    return text.length > max ? text.slice(0, max - 1).trim() + '…' : text;
  }
  function formatBytes(bytes) {
    if (!bytes) return '0 KB';
    if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  }
  function groupBy(list, keyFn) {
    var out = {};
    (list || []).forEach(function (item) {
      var key = keyFn(item);
      (out[key] = out[key] || []).push(item);
    });
    return out;
  }
  function sortBy(list, keyFn, desc) {
    return (list || []).slice().sort(function (a, b) {
      var va = keyFn(a), vb = keyFn(b);
      if (va === vb) return 0;
      var res = va > vb ? 1 : -1;
      return desc ? -res : res;
    });
  }
  function sum(list, keyFn) { return (list || []).reduce(function (acc, item) { return acc + num(typeof keyFn === 'function' ? keyFn(item) : item[keyFn]); }, 0); }
  function unique(list) { return Array.from(new Set(list || [])); }

  /* ---------- DOM ---------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function on(root, selector, type, handler) {
    if (!root) return;
    root.addEventListener(type, function (event) {
      var target = event.target.closest(selector);
      if (target && root.contains(target)) handler.call(target, event, target);
    });
  }
  function debounce(fn, wait) {
    var timer;
    return function () {
      var ctx = this, args = arguments;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(ctx, args); }, wait || 250);
    };
  }

  /* ---------- Descargas ---------- */
  function download(filename, content, mime) {
    var blob = content instanceof Blob ? content : new Blob([content], { type: mime || 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 800);
  }
  function toCSV(rows, columns) {
    function cell(value) {
      var s = value === null || value === undefined ? '' : String(value);
      return '"' + s.replace(/"/g, '""') + '"';
    }
    var head = columns.map(function (c) { return cell(c.label); }).join(';');
    var body = (rows || []).map(function (row) {
      return columns.map(function (c) {
        var v = typeof c.value === 'function' ? c.value(row) : row[c.key];
        return cell(v);
      }).join(';');
    }).join('\r\n');
    return '\uFEFF' + head + '\r\n' + body;
  }
  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).catch(function () { return legacyCopy(text); });
    }
    return Promise.resolve(legacyCopy(text));
  }
  function legacyCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch (e) { /* noop */ }
    ta.remove();
  }
  function storageBytes() {
    var total = 0;
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);
        if (key && key.indexOf('sifas.') === 0) {
          total += (localStorage.getItem(key) || '').length + key.length;
        }
      }
    } catch (e) { return 0; }
    return total * 2;
  }

  /* ---------- Iconos ---------- */
  var ICONS = {
    dashboard: '<rect x="3" y="3" width="7" height="7" rx="1.6"/><rect x="14" y="3" width="7" height="7" rx="1.6"/><rect x="3" y="14" width="7" height="7" rx="1.6"/><rect x="14" y="14" width="7" height="7" rx="1.6"/>',
    paw: '<ellipse cx="12" cy="15.5" rx="4.6" ry="3.8"/><ellipse cx="5.4" cy="10.4" rx="1.9" ry="2.4"/><ellipse cx="9.4" cy="6.6" rx="1.9" ry="2.5"/><ellipse cx="14.6" cy="6.6" rx="1.9" ry="2.5"/><ellipse cx="18.6" cy="10.4" rx="1.9" ry="2.4"/>',
    stethoscope: '<path d="M5 3v5a4 4 0 0 0 8 0V3"/><path d="M3 3h4M11 3h4"/><path d="M9 16v1a5 5 0 0 0 10 0v-2"/><circle cx="19" cy="12" r="2.4"/>',
    box: '<path d="M21 8.2 12 3 3 8.2v7.6L12 21l9-5.2Z"/><path d="m3 8.2 9 5.2 9-5.2M12 13.4V21"/>',
    map: '<path d="m9 3-6 2.4v15L9 18l6 3 6-2.4v-15L15 6 9 3Z"/><path d="M9 3v15M15 6v15"/>',
    chart: '<path d="M3 3v18h18"/><path d="M7 15v3M12 9v9M17 5v13"/>',
    users: '<path d="M16 21v-1.8a4.2 4.2 0 0 0-4.2-4.2H6.2A4.2 4.2 0 0 0 2 19.2V21"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
    shield: '<path d="M12 22s8-3.2 8-10V5l-8-3-8 3v7c0 6.8 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
    bell: '<path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2Z"/><circle cx="12" cy="13" r="4"/>',
    pin: '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
    check: '<path d="m20 6-11 11-5-5"/>',
    checkCircle: '<circle cx="12" cy="12" r="10"/><path d="m8 12 3 3 5-5"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/><path d="M10 11v5M14 11v5"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4Z"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5M12 15V3"/>',
    print: '<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    leaf: '<path d="M11 20A7 7 0 0 1 4 13c0-5.5 6-9 16-10-1 10-4.5 16-9 17Z"/><path d="M4 21c2-5 5-8 10-11"/>',
    arrowLeft: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
    arrowRight: '<path d="M5 12h14M12 5l7 7-7 7"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    chevronRight: '<path d="m9 18 6-6-6-6"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    clipboard: '<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M8 11h8M8 15h6"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
    activity: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
    syringe: '<path d="m18 2 4 4M17 7l3-3M19 9 8 20l-4 1 1-4L16 6Z"/><path d="m12 8 4 4"/>',
    utensils: '<path d="M3 2v7a3 3 0 0 0 6 0V2M6 2v20M18 2c-2 2-3 4.5-3 8v4h3v8"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/><path d="M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    refresh: '<path d="M3 12a9 9 0 0 1 15.5-6.3L21 8"/><path d="M21 3v5h-5M21 12a9 9 0 0 1-15.5 6.3L3 16"/><path d="M3 21v-5h5"/>',
    external: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6M10 14 21 3"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
    filter: '<path d="M22 3H2l8 9.5V19l4 2v-8.5Z"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20Z"/>',
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/>',
    scale: '<path d="M12 3v18M7 21h10M3 7l4-4 4 4M3 7l-2 6h8L7 7M21 7l-4-4-4 4M21 7l2 6h-8l2-6"/>',
    send: '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
    leaf2: '<path d="M2 22c1-4 3-7 6-9"/><path d="M20 4c-8 0-14 4-14 11 0 2 .5 3 .5 3S9 19 12 17c4-2.5 6-7 8-13Z"/>',
    spark: '<path d="M12 2v4M12 18v4M4.9 4.9l2.8 2.8M16.3 16.3l2.8 2.8M2 12h4M18 12h4M4.9 19.1l2.8-2.8M16.3 7.7l2.8-2.8"/>',
    thermometer: '<path d="M14 14.8V4a2 2 0 0 0-4 0v10.8a4 4 0 1 0 4 0Z"/>',
    shieldCheck: '<path d="M12 22s8-3.2 8-10V5l-8-3-8 3v7c0 6.8 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>'
  };
  function icon(name, cls) {
    var body = ICONS[name] || ICONS.info;
    return '<svg class="' + (cls || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + body + '</svg>';
  }

  S.Util = {
    esc: esc, attr: attr, uid: uid, num: num, clamp: clamp, round: round,
    toDate: toDate, pad: pad, MONTHS: MONTHS, MONTHS_LONG: MONTHS_LONG,
    fmtDate: fmtDate, fmtDateLong: fmtDateLong, fmtTime: fmtTime, fmtDateTime: fmtDateTime,
    fmtShort: fmtShort, fmtMonth: fmtMonth, nowISO: nowISO, toLocalInput: toLocalInput,
    dayKey: dayKey, daysUntil: daysUntil, timeAgo: timeAgo, addDays: addDays,
    initials: initials, titleCase: titleCase, normalize: normalize, plural: plural,
    truncate: truncate, formatBytes: formatBytes, groupBy: groupBy, sortBy: sortBy,
    sum: sum, unique: unique,
    $: $, $$: $$, on: on, debounce: debounce,
    download: download, toCSV: toCSV, copyText: copyText, storageBytes: storageBytes,
    icon: icon, ICONS: ICONS
  };
})(typeof window !== 'undefined' ? window : this);

/* Arranque de la aplicación: enrutador por hash, shell institucional,
   guardas de acceso por rol, notificaciones y sesión (RF001, RNF001, RNF007). */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util, D = S.Domain, Store = S.Store, Auth = S.Auth, UI = S.UI, Views = S.Views;

  var appRoot = null;
  var routes = [];
  var currentRoute = null;

  /* ==================================================================
     Rutas
     ================================================================== */
  function defineRoutes() {
    routes = [
      { path: '/', view: Views.public.home, title: 'Inicio', public: true },
      { path: '/especies', view: Views.public.speciesList, title: 'Especies protegidas', public: true },
      { path: '/especies/:id', view: Views.public.speciesDetail, title: 'Ficha de especie', public: true },
      { path: '/denunciar', view: Views.public.denuncia, title: 'Reportar infracción', public: true },
      { path: '/seguimiento', view: Views.public.seguimiento, title: 'Seguimiento de denuncia', public: true },
      { path: '/login', view: Views.public.login, title: 'Acceso institucional', public: true },

      { path: '/app/panel', view: Views.field.dashboard, perm: 'dashboard.view', title: 'Panel de control', group: 'Principal' },
      { path: '/app/rescates', view: Views.field.rescates, perm: 'rescates.view', title: 'Rescates y decomisos', group: 'Operación' },
      { path: '/app/rescates/nuevo', view: Views.field.nuevo, perm: 'rescates.create', title: 'Nuevo rescate', group: 'Operación' },
      { path: '/app/rescates/:id/editar', view: Views.field.editar, perm: 'rescates.edit', title: 'Editar intervención', group: 'Operación' },
      { path: '/app/rescates/:id/preacta', view: Views.field.preacta, perm: 'rescates.view', title: 'Pre-acta digital', group: 'Operación' },
      { path: '/app/rescates/:id', view: Views.field.detalle, perm: 'rescates.view', title: 'Ficha de intervención', group: 'Operación' },
      { path: '/app/clinica', view: Views.clinical.list, perm: 'clinical.view', title: 'Historias clínicas', group: 'Clínica' },
      { path: '/app/clinica/:id', view: Views.clinical.detail, perm: 'clinical.view', title: 'Historia clínica', group: 'Clínica' },
      { path: '/app/inventario', view: Views.inventory.index, perm: 'inventory.view', title: 'Inventario', group: 'Logística' },
      { path: '/app/mapa', view: Views.admin.mapa, perm: 'map.view', title: 'Mapa de intervenciones', group: 'Análisis' },
      { path: '/app/reportes', view: Views.admin.reportes, perm: 'reports.view', title: 'Reportes e indicadores', group: 'Análisis' },
      { path: '/app/denuncias', view: Views.admin.denuncias, perm: 'denuncias.view', title: 'Denuncias ciudadanas', group: 'Portal' },
      { path: '/app/catalogo', view: Views.admin.catalogo, perm: 'species.manage', title: 'Catálogo de especies', group: 'Portal' },
      { path: '/app/usuarios', view: Views.admin.usuarios, perm: 'users.manage', title: 'Usuarios', group: 'Administración' },
      { path: '/app/roles', view: Views.admin.roles, perm: 'roles.manage', title: 'Roles y permisos', group: 'Administración' },
      { path: '/app/auditoria', view: Views.admin.auditoria, perm: 'audit.view', title: 'Auditoría', group: 'Administración' },
      { path: '/app/respaldo', view: Views.admin.respaldo, perm: 'settings.manage', title: 'Respaldo y configuración', group: 'Administración' },
      { path: '/app/requisitos', view: Views.admin.requisitos, perm: null, title: 'Trazabilidad de requisitos', group: 'Sistema' },
      { path: '/app/pruebas', view: S.Tests.page, perm: null, title: 'Pruebas del sistema', group: 'Sistema' }
    ];
  }

  /* ==================================================================
     Utilidades de navegación
     ================================================================== */
  function parseHash() {
    var raw = (location.hash || '#/').replace(/^#/, '');
    if (!raw) raw = '/';
    var qi = raw.indexOf('?');
    var path = qi >= 0 ? raw.slice(0, qi) : raw;
    var qs = qi >= 0 ? raw.slice(qi + 1) : '';
    if (path.charAt(0) !== '/') path = '/' + path;
    var query = {};
    if (qs) {
      if (global.URLSearchParams) {
        try {
          var sp = new URLSearchParams(qs);
          sp.forEach(function (v, k) { query[k] = v; });
        } catch (e) { /* noop */ }
      } else {
        qs.split('&').forEach(function (pair) {
          if (!pair) return;
          var parts = pair.split('=');
          query[decodeURIComponent(parts[0])] = decodeURIComponent((parts[1] || '').replace(/\+/g, ' '));
        });
      }
    }
    return { path: path.replace(/\/+$/, '') || '/', query: query };
  }

  function matchRoute(route, path) {
    var rp = route.path.split('/').filter(Boolean);
    var pp = path.split('/').filter(Boolean);
    if (rp.length !== pp.length) return null;
    var params = {};
    for (var i = 0; i < rp.length; i++) {
      if (rp[i].charAt(0) === ':') {
        params[rp[i].slice(1)] = decodeURIComponent(pp[i]);
      } else if (rp[i] !== pp[i]) {
        return null;
      }
    }
    return params;
  }

  function findRoute(path) {
    for (var i = 0; i < routes.length; i++) {
      var params = matchRoute(routes[i], path);
      if (params) return { route: routes[i], params: params };
    }
    return null;
  }

  /* ==================================================================
     Shell institucional
     ================================================================== */
  function navGroups(u) {
    var groups = [
      {
        label: 'Principal', items: [
          { href: '#/app/panel', icon: 'dashboard', label: 'Panel', perm: 'dashboard.view', exact: true }
        ]
      },
      {
        label: 'Operación', items: [
          { href: '#/app/rescates', icon: 'paw', label: 'Rescates y decomisos', perm: 'rescates.view' },
          { href: '#/app/rescates/nuevo', icon: 'plus', label: 'Nuevo rescate', perm: 'rescates.create', exact: true }
        ]
      },
      {
        label: 'Clínica', items: [
          { href: '#/app/clinica', icon: 'stethoscope', label: 'Historias clínicas', perm: 'clinical.view', count: 'clinica' }
        ]
      },
      {
        label: 'Logística', items: [
          { href: '#/app/inventario', icon: 'box', label: 'Inventario e insumos', perm: 'inventory.view', count: 'inventario' }
        ]
      },
      {
        label: 'Análisis', items: [
          { href: '#/app/mapa', icon: 'map', label: 'Mapa de intervenciones', perm: 'map.view' },
          { href: '#/app/reportes', icon: 'chart', label: 'Reportes e indicadores', perm: 'reports.view' }
        ]
      },
      {
        label: 'Portal ciudadano', items: [
          { href: '#/app/denuncias', icon: 'alert', label: 'Denuncias recibidas', perm: 'denuncias.view', count: 'denuncias' },
          { href: '#/app/catalogo', icon: 'book', label: 'Catálogo de especies', perm: 'species.manage' }
        ]
      },
      {
        label: 'Administración', items: [
          { href: '#/app/usuarios', icon: 'users', label: 'Usuarios', perm: 'users.manage' },
          { href: '#/app/roles', icon: 'lock', label: 'Roles y permisos', perm: 'roles.manage' },
          { href: '#/app/auditoria', icon: 'file', label: 'Auditoría', perm: 'audit.view' },
          { href: '#/app/respaldo', icon: 'database', label: 'Respaldo y configuración', perm: 'settings.manage' }
        ]
      },
      {
        label: 'Sistema', items: [
          { href: '#/app/requisitos', icon: 'checkCircle', label: 'Trazabilidad de requisitos', perm: null },
          { href: '#/app/pruebas', icon: 'activity', label: 'Pruebas del sistema', perm: null }
        ]
      }
    ];
    return groups.map(function (g) {
      return {
        label: g.label,
        items: g.items.filter(function (it) { return !it.perm || Store.can(u.role, it.perm); })
      };
    }).filter(function (g) { return g.items.length; });
  }

  function countsForNav(u) {
    var stats = Store.stats();
    var clinicalCritical = Store.interventions().filter(function (i) { return D.isInCare(i) && i.priority.level === 'I'; }).length;
    return { denuncias: stats.newDenuncias, inventario: stats.inventoryAlerts, clinica: clinicalCritical };
  }

  function navItem(item, path, counts) {
    var active;
    var target = item.href.slice(1);
    if (item.exact) active = path === target;
    else active = path === target || path.indexOf(target + '/') === 0;
    var count = item.count ? counts[item.count] : 0;
    return '<a class="nav-item ' + (active ? 'active' : '') + '" href="' + item.href + '">' +
      U.icon(item.icon) + '<span>' + U.esc(item.label) + '</span>' +
      (item.count ? '<span class="nav-count" data-nav-count="' + item.count + '" style="' + (count ? '' : 'display:none') + '">' + (count || '') + '</span>' : '') +
      '</a>';
  }

  function shellHtml(route, u, path) {
    var groups = navGroups(u);
    var counts = countsForNav(u);
    var unread = Store.unreadCount(u.role);
    var nav = groups.map(function (g) {
      return '<div class="nav-group"><div class="nav-label">' + U.esc(g.label) + '</div>' +
        g.items.map(function (it) { return navItem(it, path, counts); }).join('') + '</div>';
    }).join('');

    var sidebar = '<aside class="sidebar" id="sidebar" aria-label="Navegación principal">' +
      '<div class="sidebar-head"><a href="#/app/panel" class="brand-mark" aria-label="Ir al panel">' + U.icon('paw') + '</a>' +
      '<div class="brand-text"><strong>SIFAS</strong><span>SERFOR · Junín</span></div></div>' +
      '<div class="sidebar-scroll">' + nav + '</div>' +
      '<div class="sidebar-foot"><div class="sf-note">' + U.icon('shieldCheck') +
      '<span>Sistema de trazabilidad de fauna silvestre · ATFFS Sierra Central. Datos protegidos y auditados.</span></div></div>' +
      '</aside>';

    var crumb = '<div class="topbar-crumb"><a href="#/app/panel" style="display:inline-flex;color:inherit" aria-label="Panel">' + U.icon('dashboard') + '</a>' +
      U.icon('arrowRight') + '<span class="crumb-parent">' + U.esc(route.group || 'Sistema') + '</span>' +
      U.icon('arrowRight') + '<strong>' + U.esc(route.title) + '</strong></div>';

    var quickAdd = Store.can(u.role, 'rescates.create') ?
      '<a class="icon-btn" href="#/app/rescates/nuevo" aria-label="Registrar nuevo rescate" title="Nuevo rescate">' + U.icon('plus') + '</a>' : '';

    var userMenu = '<div class="user-menu-wrap">' +
      '<button class="user-chip" id="user-chip" type="button" aria-haspopup="menu" aria-expanded="false" aria-label="Menú de usuario">' +
      '<span class="avatar">' + U.esc(U.initials(u.name)) + '</span>' +
      '<span class="uc-meta"><span class="uc-name">' + U.esc(u.name) + '</span><span class="uc-role">' + U.esc(D.roleLabel(u.role)) + '</span></span>' +
      U.icon('chevronDown') + '</button>' +
      '<div class="user-menu" id="user-menu" role="menu" hidden>' +
      '<div class="um-head"><strong>' + U.esc(u.name) + '</strong><span>' + U.esc(u.email) + '</span>' +
      '<span style="margin-top:.25rem">' + U.esc(D.roleLabel(u.role)) + '</span></div>' +
      '<button type="button" data-open-account>' + U.icon('user') + 'Mi cuenta</button>' +
      (Store.can(u.role, 'settings.manage') ? '<a href="#/app/respaldo" role="menuitem">' + U.icon('database') + 'Respaldo y configuración</a>' : '') +
      '<a href="#/" role="menuitem">' + U.icon('globe') + 'Portal público</a>' +
      '<div class="um-sep"></div>' +
      '<button type="button" class="um-danger" data-logout>' + U.icon('logout') + 'Cerrar sesión</button>' +
      '</div></div>';

    var topbar = '<header class="topbar">' +
      '<button class="icon-btn mobile-menu-btn" id="menu-btn" type="button" aria-label="Abrir menú" aria-controls="sidebar" aria-expanded="false">' + U.icon('menu') + '</button>' +
      crumb +
      '<div class="topbar-right">' + quickAdd +
      '<button class="icon-btn" id="notif-btn" type="button" aria-label="Notificaciones" title="Notificaciones">' + U.icon('bell') +
      '<span class="dot" id="notif-dot" style="' + (unread ? '' : 'display:none') + '"></span></button>' +
      userMenu + '</div></header>';

    return '<div class="shell">' + sidebar +
      '<div class="sidebar-scrim" id="sidebar-scrim"></div>' +
      '<div class="main">' + topbar +
      '<main class="page" id="page-content" tabindex="-1"></main></div></div>';
  }

  function bindShell(root) {
    var u = Auth.current();
    var sidebar = root.querySelector('#sidebar');
    var scrim = root.querySelector('#sidebar-scrim');
    var menuBtn = root.querySelector('#menu-btn');
    function closeSidebar() {
      if (sidebar) sidebar.classList.remove('open');
      if (scrim) scrim.classList.remove('open');
      if (menuBtn) { menuBtn.setAttribute('aria-expanded', 'false'); }
    }
    if (menuBtn) {
      menuBtn.addEventListener('click', function () {
        var open = sidebar.classList.toggle('open');
        scrim.classList.toggle('open', open);
        menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
    }
    if (scrim) scrim.addEventListener('click', closeSidebar);
    U.on(sidebar, 'a', 'click', closeSidebar);

    var chip = root.querySelector('#user-chip');
    var menu = root.querySelector('#user-menu');
    if (chip && menu) {
      chip.addEventListener('click', function (ev) {
        ev.stopPropagation();
        var open = menu.hidden;
        menu.hidden = !open;
        chip.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
    }
    U.on(root, '[data-logout]', 'click', function (ev) { ev.preventDefault(); logout(); });
    U.on(root, '[data-open-account]', 'click', function (ev) { ev.preventDefault(); openAccount(); });

    var notifBtn = root.querySelector('#notif-btn');
    if (notifBtn) notifBtn.addEventListener('click', openNotifications);

    if (u && u.role === 'field') {
      var firstNav = root.querySelector('.nav-item');
      if (firstNav) firstNav.focus({ preventScroll: true });
    }
  }

  function updateChrome() {
    var u = Auth.current();
    if (!u) return;
    var counts = countsForNav(u);
    U.$$('[data-nav-count]').forEach(function (el) {
      var key = el.getAttribute('data-nav-count');
      var value = counts[key] || 0;
      el.textContent = value || '';
      el.style.display = value ? '' : 'none';
    });
    var dot = document.getElementById('notif-dot');
    if (dot) dot.style.display = Store.unreadCount(u.role) ? '' : 'none';
  }

  /* ==================================================================
     Notificaciones y cuenta
     ================================================================== */
  function openNotifications() {
    var u = Auth.current();
    if (!u) return;
    var list = U.sortBy(Store.notificationsFor(u.role), function (n) { return new Date(n.ts); }, true);
    var body = list.length ? '<div>' + list.map(function (n) {
      return '<button type="button" class="list-item" data-notif="' + U.attr(n.id) + '" data-link="' + U.attr(n.link || '') + '" style="width:100%;background:none;border:0;border-bottom:1px solid #eef1ed;text-align:left;font-family:inherit;cursor:pointer;padding:.75rem 0">' +
        '<span class="li-icon" style="background:' + (n.read ? 'var(--sand-100)' : 'var(--green-50)') + ';color:' + (n.read ? 'var(--muted)' : 'var(--green-700)') + '">' +
        U.icon(n.type === 'inventory' ? 'box' : n.type === 'denuncia' ? 'alert' : 'activity') + '</span>' +
        '<span class="li-main"><span class="li-title" style="display:block">' + U.esc(n.title) + '</span>' +
        '<span class="li-sub" style="display:block">' + U.esc(n.message) + '</span></span>' +
        '<span class="li-right">' + (n.read ? '' : '<span class="dotp" style="background:var(--green-600);margin-right:.35rem"></span>') + U.timeAgo(n.ts) + '</span></button>';
    }).join('') + '</div>' : UI.empty('bell', 'Sin notificaciones', 'No hay alertas pendientes para su rol en este momento.');
    var m = UI.modal({
      title: 'Notificaciones', subtitle: 'Alertas de triaje, inventario y denuncias ciudadanas', size: 'lg', body: body,
      footer: '<button class="btn btn-secondary" type="button" data-mark-all>Marcar todas como leídas</button>' +
        '<button class="btn btn-primary" type="button" data-close-notif>Cerrar</button>'
    });
    m.el.querySelector('[data-close-notif]').addEventListener('click', UI.closeModal);
    m.el.querySelector('[data-mark-all]').addEventListener('click', function () {
      Store.markRead();
      UI.closeModal();
      updateChrome();
      UI.toast('Todas las notificaciones fueron marcadas como leídas.', 'success');
    });
    U.on(m.el, '[data-notif]', 'click', function () {
      var id = this.getAttribute('data-notif');
      var link = this.getAttribute('data-link');
      Store.markRead(id);
      UI.closeModal();
      updateChrome();
      if (link) location.hash = link;
    });
  }

  function openAccount() {
    var u = Auth.current();
    if (!u) return;
    var body = '<div style="display:flex;align-items:center;gap:.9rem;margin-bottom:1rem">' +
      '<span class="avatar lg">' + U.esc(U.initials(u.name)) + '</span>' +
      '<div><div style="font-size:1.05rem;font-weight:800">' + U.esc(u.name) + '</div>' +
      '<div class="hint">' + U.esc(u.email) + '</div>' +
      '<div class="pill-row" style="margin-top:.35rem">' + UI.badge(D.roleLabel(u.role), UI.roleTone(u.role)) +
      (u.active ? UI.badge('Cuenta activa', 'green') : UI.badge('Cuenta inactiva', 'gray')) + '</div></div></div>' +
      '<div class="meta-grid">' + UI.infoRow('Teléfono', U.esc(u.phone || '—')) +
      UI.infoRow('Último acceso', u.lastLogin ? U.fmtDateTime(u.lastLogin) : '—') +
      UI.infoRow('Cuenta creada', U.fmtDate(u.createdAt)) +
      UI.infoRow('Creada por', U.esc(u.createdBy || 'sistema')) + '</div>' +
      '<div class="divider"></div>' +
      '<div class="fs-75"><strong>Permisos asignados</strong><div class="pill-row" style="margin-top:.45rem">' +
      Store.permissionsFor(u.role).slice(0, 18).map(function (p) { return '<span class="chip" style="font-size:.68rem">' + U.esc(D.permissionLabel(p)) + '</span>'; }).join('') +
      '</div></div>';
    var m = UI.modal({
      title: 'Mi cuenta', subtitle: 'Información de la sesión actual', size: 'lg', body: body,
      footer: '<button class="btn btn-secondary" type="button" data-close-account>Cerrar</button>' +
        '<button class="btn btn-danger-soft" type="button" data-logout>' + U.icon('logout') + 'Cerrar sesión</button>'
    });
    m.el.querySelector('[data-close-account]').addEventListener('click', UI.closeModal);
    m.el.querySelector('[data-logout]').addEventListener('click', logout);
  }

  function logout() {
    UI.closeModal();
    Auth.logout();
    if (location.hash !== '#/login') location.hash = '#/login';
  }

  /* ==================================================================
     Render
     ================================================================== */
  function standaloneError(title, message, href) {
    return '<div style="min-height:100vh;display:grid;place-items:center;padding:2rem;background:var(--sand-50)">' +
      '<div class="card card-pad" style="max-width:560px;width:100%">' + UI.empty('alert', title, message,
        '<a class="btn btn-primary" href="' + (href || '#/') + '">Ir al inicio</a>') + '</div></div>';
  }

  function renderForbidden(route) {
    var u = Auth.current();
    var result = {
      html: '<div class="card card-pad" style="max-width:640px;margin:2rem auto">' +
        UI.empty('lock', 'Acceso restringido', 'Su rol (' + D.roleLabel(u.role) + ') no cuenta con el permiso necesario para acceder a este módulo. Si requiere acceso, contacte al Administrador del sistema.',
          '<a class="btn btn-primary" href="#/app/panel">Volver al panel</a>') + '</div>',
      mount: function () {}
    };
    renderShell(route, result);
  }

  function renderShell(route, result) {
    var u = Auth.current();
    var parsed = parseHash();
    appRoot.innerHTML = shellHtml(route, u, parsed.path);
    var page = appRoot.querySelector('#page-content');
    page.innerHTML = result.html || '';
    bindShell(appRoot);
    try {
      if (result.mount) result.mount(page);
    } catch (e) {
      if (global.console && console.error) console.error(e);
      UI.toast('Ocurrió un error al inicializar la vista: ' + (e.message || e), 'error');
    }
    document.title = route.title + ' · SIFAS';
    page.focus({ preventScroll: true });
  }

  function renderPublic(route, result, params) {
    appRoot.innerHTML = result.html || '';
    try {
      if (result.mount) result.mount(appRoot);
    } catch (e) {
      if (global.console && console.error) console.error(e);
      UI.toast('Ocurrió un error al cargar la página: ' + (e.message || e), 'error');
    }
    var title = route.title;
    if (route.path === '/especies/:id' && params && params.id) {
      var sp = Store.findSpecies(params.id);
      if (sp) title = sp.common;
    }
    document.title = (route.path === '/' ? 'SIFAS · Fauna silvestre — SERFOR Huancayo' : title + ' · SIFAS');
  }

  function render(preserveScroll) {
    if (!appRoot) appRoot = document.getElementById('app');
    if (!appRoot) return;
    var parsed = parseHash();
    var path = parsed.path;
    var scrollY = preserveScroll ? (global.scrollY || 0) : 0;
    UI.closeModal();
    closeUserMenu();

    /* Redirecciones de sesión */
    if (path.indexOf('/app') === 0 && !Auth.current()) {
      try { sessionStorage.setItem('sifas.redirect', location.hash || '#/app/panel'); } catch (e) { /* noop */ }
      if (location.hash !== '#/login') { location.hash = '#/login'; return; }
    }
    if (path === '/login' && Auth.current()) { location.hash = '#/app/panel'; return; }
    if (path === '/app' || path === '/app/') { location.hash = '#/app/panel'; return; }

    var found = findRoute(path);
    if (!found) {
      currentRoute = null;
      appRoot.innerHTML = standaloneError('Página no encontrada', 'La dirección solicitada no existe o fue movida. Verifique el enlace e intente nuevamente.', '#/');
      document.title = 'Página no encontrada · SIFAS';
      window.scrollTo(0, 0);
      return;
    }

    var route = found.route;
    currentRoute = route;
    var params = Object.assign({}, found.params, { query: parsed.query, path: path });

    if (!route.public && route.perm && !Auth.can(route.perm)) {
      renderForbidden(route);
      window.scrollTo(0, 0);
      return;
    }

    var result;
    try {
      result = route.view(params) || { html: '', mount: null };
    } catch (e) {
      if (global.console && console.error) console.error(e);
      if (route.public) {
        appRoot.innerHTML = standaloneError('No se pudo cargar la página', e.message || String(e), '#/');
      } else {
        renderShell(route, {
          html: '<div class="card card-pad">' + UI.empty('alert', 'No se pudo cargar el módulo', e.message || String(e),
            '<a class="btn btn-primary" href="#/app/panel">Volver al panel</a>') + '</div>',
          mount: function () {}
        });
      }
      window.scrollTo(0, 0);
      return;
    }

    if (route.public) renderPublic(route, result, found.params);
    else renderShell(route, result);

    if (preserveScroll) window.scrollTo(0, scrollY);
    else window.scrollTo(0, 0);
  }

  function closeUserMenu() {
    var menu = document.getElementById('user-menu');
    var chip = document.getElementById('user-chip');
    if (menu) menu.hidden = true;
    if (chip) chip.setAttribute('aria-expanded', 'false');
  }

  /* ==================================================================
     API pública
     ================================================================== */
  function refresh() { render(true); }
  function navigate(hash) {
    if (!hash) return;
    if (location.hash === hash) refresh();
    else location.hash = hash;
  }

  S.App = {
    refresh: refresh, navigate: navigate, render: render,
    routes: routes, current: function () { return currentRoute; }
  };

  /* ==================================================================
     Inicialización
     ================================================================== */
  function init() {
    appRoot = document.getElementById('app');
    Store.init();
    defineRoutes();

    window.addEventListener('hashchange', function () { render(false); });

    document.addEventListener('sifas:change', function () { updateChrome(); });
    document.addEventListener('sifas:quota', function () {
      UI.toast('El almacenamiento local está lleno. Elimine evidencias antiguas o descargue un respaldo desde el módulo de configuración.', 'error', 'No se pudo guardar');
    });
    document.addEventListener('sifas:logout', function () {
      UI.closeModal();
      if (location.hash.indexOf('#/app') === 0) location.hash = '#/login';
      else render(true);
    });
    document.addEventListener('click', function (ev) {
      if (!ev.target.closest('.user-menu-wrap')) closeUserMenu();
    });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') closeUserMenu();
    });

    if (!location.hash) location.hash = '#/';
    render(false);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})(typeof window !== 'undefined' ? window : this);

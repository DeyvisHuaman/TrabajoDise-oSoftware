/* Reglas de dominio del sistema (RD001–RD011) y catálogos maestros. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util;

  /* ------------------------------------------------------------------
     RD011 — Triaje clínico de cuatro criterios (0–2 cada uno, total 0–8)
     ------------------------------------------------------------------ */
  var CRITERIA = [
    {
      key: 'signs', label: 'Signos vitales', short: 'Signos vitales', icon: 'activity',
      options: [
        { score: 0, label: 'Normales', desc: 'Frecuencia cardíaca, respiratoria y temperatura dentro de rango.' },
        { score: 1, label: 'Alterados leves', desc: 'Desviación moderada de uno o más parámetros.' },
        { score: 2, label: 'Alterados graves o ausentes', desc: 'Desviación severa, compromiso vital evidente.' }
      ]
    },
    {
      key: 'lesions', label: 'Lesiones o fracturas', short: 'Lesiones', icon: 'heart',
      options: [
        { score: 0, label: 'Sin lesiones aparentes', desc: 'No se observan heridas ni fracturas.' },
        { score: 1, label: 'Lesión leve', desc: 'Heridas superficiales, contusiones.' },
        { score: 2, label: 'Lesión grave', desc: 'Fractura abierta, hemorragia activa, herida profunda.' }
      ]
    },
    {
      key: 'response', label: 'Respuesta a estímulos', short: 'Respuesta', icon: 'spark',
      options: [
        { score: 0, label: 'Reactivo y alerta', desc: 'Responde de forma adecuada a los estímulos.' },
        { score: 1, label: 'Hipoactivo', desc: 'Respuesta disminuida o letargo moderado.' },
        { score: 2, label: 'No reactivo o inconsciente', desc: 'Sin respuesta a estímulos externos.' }
      ]
    },
    {
      key: 'mobility', label: 'Movilidad', short: 'Movilidad', icon: 'paw',
      options: [
        { score: 0, label: 'Normal', desc: 'Se desplaza y sostiene sin dificultad.' },
        { score: 1, label: 'Limitada', desc: 'Dificultad para desplazarse.' },
        { score: 2, label: 'Ausente', desc: 'No se sostiene ni se desplaza.' }
      ]
    }
  ];

  var PRIORITY = {
    I: { level: 'I', name: 'Prioridad I', tag: 'Crítico', color: '#c0392b', tone: 'red', order: 1, rule: 'Rojo' },
    II: { level: 'II', name: 'Prioridad II', tag: 'Urgente', color: '#d99a18', tone: 'amber', order: 2, rule: 'Amarillo' },
    III: { level: 'III', name: 'Prioridad III', tag: 'No urgente', color: '#2a9169', tone: 'green', order: 3, rule: 'Verde' }
  };

  function triage(criteria) {
    criteria = criteria || {};
    var total = 0, valid = true;
    CRITERIA.forEach(function (c) {
      var v = Number(criteria[c.key]);
      if (!isFinite(v) || v < 0 || v > 2 || Math.floor(v) !== v) valid = false;
      total += isFinite(v) ? v : 0;
    });
    if (!valid) {
      return { valid: false, error: 'Cada criterio debe calificarse con 0, 1 o 2 puntos.', score: total, level: null };
    }
    var signs = Number(criteria.signs);
    var level, reason;
    if (signs === 2) {
      level = 'I';
      reason = 'Regla de excepción: signos vitales calificados con 2 puntos (compromiso vital).';
    } else if (total >= 5) {
      level = 'I';
      reason = 'Puntaje total de ' + total + ' puntos (rango 5–8).';
    } else if (total >= 2) {
      level = 'II';
      reason = 'Puntaje total de ' + total + ' puntos (rango 2–4) y sin compromiso vital.';
    } else {
      level = 'III';
      reason = 'Puntaje total de ' + total + ' punto' + (total === 1 ? '' : 's') + ' (rango 0–1).';
    }
    var meta = PRIORITY[level];
    return {
      valid: true, score: total, level: level, name: meta.name, tag: meta.tag,
      color: meta.color, tone: meta.tone, order: meta.order, reason: reason,
      alert: level === 'I',
      criteria: {
        signs: Number(criteria.signs), lesions: Number(criteria.lesions),
        response: Number(criteria.response), mobility: Number(criteria.mobility)
      },
      evaluatedAt: U.nowISO()
    };
  }

  function normalizePriority(p) {
    if (!p) return PRIORITY.III;
    if (typeof p === 'string') return PRIORITY[p] || PRIORITY.III;
    return PRIORITY[p.level] || PRIORITY.III;
  }

  /* ------------------------------------------------------------------
     Estados de la intervención / animal
     ------------------------------------------------------------------ */
  var STATUS = {
    registrado: { key: 'registrado', label: 'Registrado', tone: 'blue', desc: 'Ingresado y pendiente de evaluación clínica.' },
    en_cuarentena: { key: 'en_cuarentena', label: 'En cuarentena', tone: 'amber', desc: 'En observación y rehabilitación.' },
    liberado: { key: 'liberado', label: 'Liberado', tone: 'green', desc: 'Devuelto a su hábitat natural.' },
    custodia: { key: 'custodia', label: 'Custodia permanente', tone: 'purple', desc: 'Trasladado a un centro de custodia.' },
    eutanasia: { key: 'eutanasia', label: 'Eutanasia', tone: 'gray', desc: 'Decisión humanitaria registrada.' }
  };
  function isInCare(intervention) {
    return intervention && (intervention.status === 'registrado' || intervention.status === 'en_cuarentena');
  }

  var CONDITIONS = [
    'Herida abierta', 'Fractura', 'Desnutrición', 'Deshidratación', 'Cautiverio',
    'Venta ilegal', 'Atropellamiento', 'Quemadura', 'Ataque de otro animal',
    'Cría huérfana', 'Estrés severo', 'Plumaje o pelaje deteriorado', 'Sin lesiones aparentes'
  ];

  var INTERVENTION_TYPES = [
    { key: 'rescate', label: 'Rescate' },
    { key: 'decomiso', label: 'Decomiso' },
    { key: 'hallazgo', label: 'Hallazgo' },
    { key: 'entrega_voluntaria', label: 'Entrega voluntaria' }
  ];

  var INVENTORY_CATEGORIES = [
    { key: 'alimento', label: 'Alimentos', icon: 'utensils' },
    { key: 'medicamento', label: 'Medicamentos veterinarios', icon: 'syringe' },
    { key: 'herramienta', label: 'Herramientas de contención', icon: 'box' }
  ];

  var DENUNCIA_TYPES = [
    { key: 'venta', label: 'Venta ilegal' },
    { key: 'tenencia', label: 'Tenencia ilegal en cautiverio' },
    { key: 'transporte', label: 'Transporte o traslado ilegal' },
    { key: 'maltrato', label: 'Maltrato animal' },
    { key: 'otro', label: 'Otro hecho' }
  ];

  var DENUNCIA_STATUS = {
    nueva: { label: 'Nueva', tone: 'blue' },
    en_revision: { label: 'En revisión', tone: 'amber' },
    derivada: { label: 'Derivada a fiscalización', tone: 'purple' },
    cerrada: { label: 'Cerrada', tone: 'gray' }
  };

  var PROTECTION = {
    CR: { code: 'CR', label: 'En peligro crítico', tone: 'red', rank: 1 },
    EN: { code: 'EN', label: 'En peligro', tone: 'red', rank: 2 },
    VU: { code: 'VU', label: 'Vulnerable', tone: 'amber', rank: 3 },
    NT: { code: 'NT', label: 'Casi amenazada', tone: 'amber', rank: 4 },
    LC: { code: 'LC', label: 'Preocupación menor', tone: 'green', rank: 5 },
    DD: { code: 'DD', label: 'Datos insuficientes', tone: 'gray', rank: 6 }
  };

  var ZONES = [
    { key: 'huancayo', name: 'Huancayo Centro', lat: -12.0651, lng: -75.2049, kind: 'urbana' },
    { key: 'el-tambo', name: 'El Tambo', lat: -12.0444, lng: -75.2139, kind: 'urbana' },
    { key: 'chilca', name: 'Chilca', lat: -12.0819, lng: -75.2044, kind: 'urbana' },
    { key: 'pilcomayo', name: 'Pilcomayo', lat: -12.0497, lng: -75.2483, kind: 'urbana' },
    { key: 'cajas', name: 'San Agustín de Cajas', lat: -12.0186, lng: -75.2194, kind: 'periurbana' },
    { key: 'tunan', name: 'San Jerónimo de Tunán', lat: -11.9989, lng: -75.2397, kind: 'periurbana' },
    { key: 'huayucachi', name: 'Huayucachi', lat: -12.1319, lng: -75.2219, kind: 'rural' },
    { key: 'sapallanga', name: 'Sapallanga', lat: -12.1375, lng: -75.1769, kind: 'rural' },
    { key: 'viques', name: 'Viques', lat: -12.1539, lng: -75.1869, kind: 'rural' },
    { key: 'pucara', name: 'Pucará', lat: -12.1633, lng: -75.1528, kind: 'rural' }
  ];

  function distanceKm(aLat, aLng, bLat, bLng) {
    var R = 6371, toRad = Math.PI / 180;
    var dLat = (bLat - aLat) * toRad, dLng = (bLng - aLng) * toRad;
    var h = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(aLat * toRad) * Math.cos(bLat * toRad) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
  }
  function nearestZone(lat, lng) {
    if (!isFinite(lat) || !isFinite(lng)) return null;
    var best = null, bestD = Infinity;
    ZONES.forEach(function (z) {
      var d = distanceKm(lat, lng, z.lat, z.lng);
      if (d < bestD) { bestD = d; best = z; }
    });
    return best ? { zone: best, distanceKm: U.round(bestD, 1) } : null;
  }

  /* ------------------------------------------------------------------
     RD005 / RF008 — Decisión técnica
     ------------------------------------------------------------------ */
  function decisionAvailability(intervention, records) {
    records = records || [];
    var hasDischarge = records.some(function (r) { return r.discharge === true; });
    var hasAptBehavior = records.some(function (r) { return r.behaviorApt === true; });
    var existing = intervention && intervention.decisionId;
    var finalized = intervention && ['liberado', 'custodia', 'eutanasia'].indexOf(intervention.status) >= 0;
    var reasonsRelease = [];
    if (!hasDischarge) reasonsRelease.push('Falta el alta médica en la historia clínica.');
    if (!hasAptBehavior) reasonsRelease.push('Falta registrar comportamiento apto para liberación.');
    var blocked = existing || finalized;
    return {
      liberacion: {
        enabled: !blocked && hasDischarge && hasAptBehavior,
        reason: blocked ? 'Ya existe una decisión técnica registrada para este animal.' :
          (reasonsRelease.length ? reasonsRelease.join(' ') : 'Cumple los requisitos de liberación.')
      },
      custodia: {
        enabled: !blocked,
        reason: blocked ? 'Ya existe una decisión técnica registrada para este animal.' :
          'Requiere indicar el centro o zoológico de destino y la justificación.'
      },
      eutanasia: {
        enabled: !blocked,
        reason: blocked ? 'Ya existe una decisión técnica registrada para este animal.' :
          'Requiere registrar el diagnóstico o condición terminal que la justifica.'
      },
      hasDischarge: hasDischarge,
      hasAptBehavior: hasAptBehavior,
      blocked: !!blocked,
      dischargeRecord: records.filter(function (r) { return r.discharge; }).slice(-1)[0] || null
    };
  }

  function validateDecision(type, payload) {
    payload = payload || {};
    if (['liberacion', 'custodia', 'eutanasia'].indexOf(type) < 0) {
      return { ok: false, error: 'Decisión no permitida por el sistema.' };
    }
    if (type === 'liberacion') {
      if (!payload.releaseDate) return { ok: false, error: 'Registre la fecha de liberación.' };
      if (!String(payload.releasePlace || '').trim()) return { ok: false, error: 'Indique el lugar de liberación.' };
      if (String(payload.justification || '').trim().length < 10) {
        return { ok: false, error: 'Registre la justificación técnica (mínimo 10 caracteres).' };
      }
    }
    if (type === 'custodia') {
      if (String(payload.destination || '').trim().length < 3) {
        return { ok: false, error: 'Indique el centro o zoológico de destino.' };
      }
      if (String(payload.justification || '').trim().length < 10) {
        return { ok: false, error: 'Registre la justificación del traslado (mínimo 10 caracteres).' };
      }
    }
    if (type === 'eutanasia') {
      if (String(payload.justification || '').trim().length < 10) {
        return { ok: false, error: 'Registre el diagnóstico o condición terminal que justifica la eutanasia.' };
      }
    }
    return { ok: true };
  }

  /* ------------------------------------------------------------------
     RD006 / RD007 — Inventario
     ------------------------------------------------------------------ */
  function validateExit(stock, qty) {
    var s = U.num(stock), q = U.num(qty);
    if (!(q > 0)) return { ok: false, error: 'La cantidad debe ser mayor a cero.' };
    if (q > s) {
      return { ok: false, error: 'La cantidad solicitada (' + q + ') supera el stock disponible (' + s + ').' };
    }
    return { ok: true };
  }
  function expiryStatus(dateISO) {
    if (!dateISO) return { state: 'sin', label: 'Sin vencimiento', tone: 'gray', days: null };
    var days = U.daysUntil(dateISO);
    if (days === null) return { state: 'sin', label: 'Sin vencimiento', tone: 'gray', days: null };
    if (days < 0) return { state: 'vencido', label: 'Vencido hace ' + Math.abs(days) + ' d', tone: 'red', days: days };
    if (days <= 30) return { state: 'por_vencer', label: 'Vence en ' + days + ' d', tone: 'amber', days: days };
    return { state: 'ok', label: 'Vence ' + U.fmtShort(dateISO), tone: 'gray', days: days };
  }
  function inventoryAlerts(items) {
    var out = [];
    (items || []).forEach(function (item) {
      if (!item.active) return;
      if (item.expiresAt) {
        var st = expiryStatus(item.expiresAt);
        if (st.state === 'vencido') {
          out.push({ item: item, type: 'vencido', severity: 1, title: 'Producto vencido', reason: item.name + ' venció el ' + U.fmtShort(item.expiresAt) + '.' });
        } else if (st.state === 'por_vencer') {
          out.push({ item: item, type: 'por_vencer', severity: 2, title: 'Próximo a vencer', reason: item.name + ' vence en ' + st.days + ' día' + (st.days === 1 ? '' : 's') + ' (' + U.fmtShort(item.expiresAt) + ').' });
        }
      }
      if (U.num(item.stock) <= U.num(item.minStock)) {
        out.push({ item: item, type: 'stock', severity: U.num(item.stock) === 0 ? 1 : 2, title: 'Stock mínimo alcanzado', reason: item.name + ': ' + U.num(item.stock) + ' ' + item.unit + ' disponibles (mínimo ' + U.num(item.minStock) + ').' });
      }
    });
    return out.sort(function (a, b) { return a.severity - b.severity || a.item.name.localeCompare(b.item.name); });
  }

  /* ------------------------------------------------------------------
     Seguridad — política de contraseñas
     ------------------------------------------------------------------ */
  function validatePassword(pw) {
    pw = String(pw || '');
    var errors = [];
    if (pw.length < 8) errors.push('Al menos 8 caracteres.');
    if (!/[A-ZÁÉÍÓÚÑ]/.test(pw)) errors.push('Al menos una letra mayúscula.');
    if (!/[a-záéíóúñ]/.test(pw)) errors.push('Al menos una letra minúscula.');
    if (!/[0-9]/.test(pw)) errors.push('Al menos un número.');
    if (!/[^A-Za-z0-9ÁÉÍÓÚÑáéíóúñ\s]/.test(pw)) errors.push('Al menos un símbolo (!@#$%…).');
    var score = 0;
    if (pw.length >= 8) score++;
    if (pw.length >= 12) score++;
    if (/[A-ZÁÉÍÓÚÑ]/.test(pw) && /[a-záéíóúñ]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9ÁÉÍÓÚÑáéíóúñ\s]/.test(pw)) score++;
    return { ok: errors.length === 0, errors: errors, score: Math.min(4, score) };
  }

  /* ------------------------------------------------------------------
     Permisos por rol (RNF001 / RD010)
     ------------------------------------------------------------------ */
  var PERMISSIONS = [
    { key: 'dashboard.view', label: 'Ver panel de control', group: 'General' },
    { key: 'rescates.view', label: 'Consultar intervenciones y rescates', group: 'Rescates' },
    { key: 'rescates.create', label: 'Registrar rescate / decomiso', group: 'Rescates' },
    { key: 'rescates.edit', label: 'Editar datos del animal', group: 'Rescates' },
    { key: 'clinical.view', label: 'Consultar historias clínicas', group: 'Clínica' },
    { key: 'clinical.edit', label: 'Crear y actualizar historia clínica', group: 'Clínica' },
    { key: 'decisions.register', label: 'Registrar decisión técnica', group: 'Clínica' },
    { key: 'inventory.view', label: 'Consultar inventario', group: 'Logística' },
    { key: 'inventory.manage', label: 'Gestionar inventario y movimientos', group: 'Logística' },
    { key: 'reports.view', label: 'Ver reportes y exportar indicadores', group: 'Reportes' },
    { key: 'map.view', label: 'Visualizar mapa de intervenciones', group: 'Reportes' },
    { key: 'denuncias.view', label: 'Revisar denuncias ciudadanas', group: 'Portal' },
    { key: 'species.manage', label: 'Administrar catálogo de especies', group: 'Portal' },
    { key: 'users.manage', label: 'Gestionar usuarios', group: 'Administración' },
    { key: 'roles.manage', label: 'Gestionar roles y permisos', group: 'Administración' },
    { key: 'audit.view', label: 'Consultar auditoría del sistema', group: 'Administración' },
    { key: 'settings.manage', label: 'Respaldo y configuración', group: 'Administración' }
  ];
  var ROLE_DEFS = {
    admin: { key: 'admin', label: 'Administrador', desc: 'Gestión de usuarios, roles, reportes, mapa y auditoría.' },
    vet: { key: 'vet', label: 'Médico Veterinario', desc: 'Historia clínica, seguimiento y decisión técnica.' },
    field: { key: 'field', label: 'Agente de Campo', desc: 'Registro de rescates, evidencias y triaje.' },
    logistics: { key: 'logistics', label: 'Encargado de Logística', desc: 'Inventario, stock y alertas de insumos.' }
  };
  var DEFAULT_PERMS = {
    admin: PERMISSIONS.map(function (p) { return p.key; }),
    vet: ['dashboard.view', 'rescates.view', 'clinical.view', 'clinical.edit', 'decisions.register', 'inventory.view'],
    field: ['dashboard.view', 'rescates.view', 'rescates.create', 'rescates.edit'],
    logistics: ['dashboard.view', 'rescates.view', 'inventory.view', 'inventory.manage']
  };

  /* ------------------------------------------------------------------
     Estados de salud y utilidades clínicas
     ------------------------------------------------------------------ */
  var HEALTH = {
    critico: { key: 'critico', label: 'Crítico', tone: 'red', score: 1 },
    grave: { key: 'grave', label: 'Grave', tone: 'red', score: 2 },
    estable: { key: 'estable', label: 'Estable', tone: 'amber', score: 3 },
    bueno: { key: 'bueno', label: 'Bueno', tone: 'green', score: 4 },
    excelente: { key: 'excelente', label: 'Excelente', tone: 'green', score: 5 }
  };
  var RECORD_TYPES = {
    evaluacion: { key: 'evaluacion', label: 'Evaluación clínica', icon: 'stethoscope' },
    control: { key: 'control', label: 'Control de cuarentena', icon: 'activity' },
    vacuna: { key: 'vacuna', label: 'Vacunación', icon: 'syringe' },
    dieta: { key: 'dieta', label: 'Dieta diaria', icon: 'utensils' },
    alta: { key: 'alta', label: 'Alta médica', icon: 'checkCircle' }
  };

  function nextSequential(list, start) {
    var max = start || 0;
    (list || []).forEach(function (item) {
      var m = String(item || '').match(/(\d+)$/);
      if (m) max = Math.max(max, parseInt(m[1], 10));
    });
    return max + 1;
  }
  function pad4(n) { return ('0000' + n).slice(-4); }

  S.Domain = {
    CRITERIA: CRITERIA, PRIORITY: PRIORITY, triage: triage, normalizePriority: normalizePriority,
    STATUS: STATUS, isInCare: isInCare, CONDITIONS: CONDITIONS, INTERVENTION_TYPES: INTERVENTION_TYPES,
    INVENTORY_CATEGORIES: INVENTORY_CATEGORIES, DENUNCIA_TYPES: DENUNCIA_TYPES, DENUNCIA_STATUS: DENUNCIA_STATUS,
    PROTECTION: PROTECTION, ZONES: ZONES, nearestZone: nearestZone,
    decisionAvailability: decisionAvailability, validateDecision: validateDecision,
    validateExit: validateExit, expiryStatus: expiryStatus, inventoryAlerts: inventoryAlerts,
    validatePassword: validatePassword, PERMISSIONS: PERMISSIONS, ROLE_DEFS: ROLE_DEFS, DEFAULT_PERMS: DEFAULT_PERMS,
    HEALTH: HEALTH, RECORD_TYPES: RECORD_TYPES, nextSequential: nextSequential, pad4: pad4,
    roleLabel: function (role) { return (ROLE_DEFS[role] || { label: role }).label; },
    permissionLabel: function (key) {
      var p = PERMISSIONS.filter(function (x) { return x.key === key; })[0];
      return p ? p.label : key;
    }
  };
})(typeof window !== 'undefined' ? window : this);

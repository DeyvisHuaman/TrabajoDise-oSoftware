/* Autenticación, sesión y control de acceso basado en roles (RF001, RNF001). */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var Store = S.Store, D = S.Domain, H = S.Hash, U = S.Util;

  var SESSION_KEY = 'sifas.session.v1';
  var ATTEMPTS_KEY = 'sifas.attempts.v1';
  var MAX_ATTEMPTS = 5;
  var LOCK_MINUTES = 2;

  function readAttempts() {
    try { return JSON.parse(localStorage.getItem(ATTEMPTS_KEY) || '{}'); } catch (e) { return {}; }
  }
  function writeAttempts(data) {
    try { localStorage.setItem(ATTEMPTS_KEY, JSON.stringify(data)); } catch (e) { /* noop */ }
  }
  function attemptState(email) {
    var data = readAttempts();
    var entry = data[String(email || '').toLowerCase()];
    if (!entry) return { count: 0, locked: false, minutes: 0 };
    if (entry.until && entry.until > Date.now()) {
      return { count: entry.count, locked: true, minutes: Math.ceil((entry.until - Date.now()) / 60000) };
    }
    return { count: entry.count || 0, locked: false, minutes: 0 };
  }

  function login(email, password) {
    var normalized = String(email || '').trim().toLowerCase();
    if (!normalized || !password) {
      return { ok: false, error: 'Ingrese su usuario y contraseña.' };
    }
    var attempt = attemptState(normalized);
    if (attempt.locked) {
      return { ok: false, error: 'Demasiados intentos fallidos. Espere ' + attempt.minutes + ' minuto(s) antes de volver a intentarlo.' };
    }
    var user = Store.findUserByEmail(normalized);
    var valid = false;
    if (user) valid = H.verifyPassword(password, user.passHash);
    if (!user || !valid) {
      var data = readAttempts();
      var entry = data[normalized] || { count: 0 };
      entry.count = (entry.count || 0) + 1;
      if (entry.count >= MAX_ATTEMPTS) {
        entry.until = Date.now() + LOCK_MINUTES * 60000;
        entry.count = 0;
      }
      data[normalized] = entry;
      writeAttempts(data);
      Store.log({ id: 'anon', name: normalized || 'desconocido', role: 'public' },
        'Intento de acceso fallido', 'sesion', '—', 'Credenciales inválidas para ' + (normalized || '(vacío)') + '.', true);
      return { ok: false, error: 'Usuario o contraseña incorrectos. Verifique sus credenciales.' };
    }
    if (!user.active) {
      return { ok: false, error: 'La cuenta se encuentra deshabilitada. Contacte al Administrador.' };
    }
    var data2 = readAttempts();
    delete data2[normalized];
    writeAttempts(data2);
    var hours = (Store.get().settings && Store.get().settings.sessionHours) || 8;
    var session = { userId: user.id, startedAt: U.nowISO(), expiresAt: new Date(Date.now() + hours * 3600000).toISOString() };
    try { localStorage.setItem(SESSION_KEY, JSON.stringify(session)); } catch (e) { /* noop */ }
    user.lastLogin = U.nowISO();
    Store.persist();
    Store.log({ id: user.id, name: user.name, role: user.role }, 'Inicio de sesión', 'sesion', user.id, 'Acceso al sistema con rol ' + D.roleLabel(user.role) + '.', false);
    return { ok: true, user: user };
  }

  function session() {
    try {
      var raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      var s = JSON.parse(raw);
      if (!s || !s.userId) return null;
      if (new Date(s.expiresAt).getTime() < Date.now()) { logout(true); return null; }
      return s;
    } catch (e) { return null; }
  }

  function current() {
    var s = session();
    if (!s) return null;
    var user = Store.findUser(s.userId);
    if (!user || !user.active) return null;
    return user;
  }

  function logout(silent) {
    var user = current();
    if (user && !silent) {
      Store.log({ id: user.id, name: user.name, role: user.role }, 'Cierre de sesión', 'sesion', user.id, 'El usuario cerró su sesión.', false);
    }
    try { localStorage.removeItem(SESSION_KEY); } catch (e) { /* noop */ }
    document.dispatchEvent(new CustomEvent('sifas:logout'));
  }

  function can(perm) {
    var user = current();
    if (!user) return false;
    return Store.can(user.role, perm);
  }

  function permissions() {
    var user = current();
    if (!user) return [];
    return Store.permissionsFor(user.role);
  }

  S.Auth = {
    login: login, logout: logout, current: current, session: session,
    can: can, permissions: permissions, attemptState: attemptState,
    MAX_ATTEMPTS: MAX_ATTEMPTS, SESSION_KEY: SESSION_KEY
  };
})(typeof window !== 'undefined' ? window : this);

/* Componentes de interfaz reutilizables: avisos, modales, evidencias y badges. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util, D = S.Domain;

  var toastRoot = null;
  function toast(message, type, title) {
    if (!toastRoot) toastRoot = document.getElementById('toast-root');
    if (!toastRoot) return;
    type = type || 'success';
    var icons = { success: 'checkCircle', error: 'alert', warn: 'alert', info: 'info' };
    var el = document.createElement('div');
    el.className = 'toast toast-' + type;
    el.innerHTML = '<div class="tt-ic text-' + (type === 'error' || type === 'warn' ? 'red' : type === 'success' ? 'green' : 'muted') + '">' + U.icon(icons[type] || 'info') + '</div>' +
      '<div style="flex:1"><div class="tt-title">' + U.esc(title || (type === 'error' ? 'No se pudo completar la operación' : type === 'warn' ? 'Atención' : type === 'info' ? 'Información' : 'Operación realizada')) + '</div>' +
      '<div class="tt-msg">' + U.esc(message) + '</div></div>' +
      '<button class="tt-close" type="button" aria-label="Cerrar aviso">×</button>';
    toastRoot.appendChild(el);
    var timer = setTimeout(function () { remove(); }, type === 'error' ? 7000 : 4800);
    function remove() { clearTimeout(timer); if (el.parentNode) el.parentNode.removeChild(el); }
    el.querySelector('.tt-close').addEventListener('click', remove);
  }

  function badge(text, tone) {
    return '<span class="badge badge-' + (tone || 'gray') + '">' + U.esc(text) + '</span>';
  }
  function priorityBadge(level) {
    var p = D.normalizePriority(level);
    return '<span class="badge badge-' + p.tone + '"><span class="dotp pri-' + p.level + '" style="width:6px;height:6px"></span>Prioridad ' + p.level + ' · ' + p.tag + '</span>';
  }
  function statusBadge(status) {
    var st = D.STATUS[status] || { label: status, tone: 'gray' };
    return badge(st.label, st.tone);
  }
  function healthBadge(health) {
    var h = D.HEALTH[health] || D.HEALTH.estable;
    return badge(h.label, h.tone);
  }

  function empty(icon, title, text, actionHtml) {
    return '<div class="empty"><div class="em-ic">' + U.icon(icon || 'info') + '</div>' +
      '<h4>' + U.esc(title || 'Sin información') + '</h4>' +
      '<p>' + U.esc(text || '') + '</p>' + (actionHtml || '') + '</div>';
  }

  var activeModal = null;
  function modal(options) {
    options = options || {};
    closeModal();
    var root = document.getElementById('modal-root');
    var backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    var sizeClass = options.size === 'lg' ? ' modal-lg' : options.size === 'xl' ? ' modal-xl' : '';
    backdrop.innerHTML = '<div class="modal' + sizeClass + '" role="dialog" aria-modal="true" aria-labelledby="modal-title">' +
      '<div class="modal-head"><div><h3 id="modal-title">' + U.esc(options.title || '') + '</h3>' +
      (options.subtitle ? '<div class="mh-sub">' + U.esc(options.subtitle) + '</div>' : '') + '</div>' +
      '<button type="button" class="modal-close" aria-label="Cerrar">' + U.icon('x') + '</button></div>' +
      '<div class="modal-body">' + (options.body || '') + '</div>' +
      (options.footer === null ? '' : '<div class="modal-foot">' + (options.footer || '<button class="btn btn-secondary" type="button" data-close-modal>Cancelar</button>') + '</div>') +
      '</div>';
    root.appendChild(backdrop);
    activeModal = backdrop;
    var closeBtn = backdrop.querySelector('.modal-close');
    closeBtn.addEventListener('click', closeModal);
    backdrop.addEventListener('mousedown', function (ev) { if (ev.target === backdrop) closeModal(); });
    function onKey(ev) {
      if (ev.key === 'Escape') closeModal();
      if (ev.key === 'Tab') {
        var focusables = backdrop.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (!focusables.length) return;
        var first = focusables[0], last = focusables[focusables.length - 1];
        if (ev.shiftKey && document.activeElement === first) { last.focus(); ev.preventDefault(); }
        else if (!ev.shiftKey && document.activeElement === last) { first.focus(); ev.preventDefault(); }
      }
    }
    document.addEventListener('keydown', onKey);
    backdrop._onKey = onKey;
    var autofocus = backdrop.querySelector('[autofocus], input:not([type=hidden]), textarea, select');
    if (autofocus) setTimeout(function () { autofocus.focus(); }, 60);
    return {
      el: backdrop,
      close: closeModal,
      body: backdrop.querySelector('.modal-body'),
      footer: backdrop.querySelector('.modal-foot')
    };
  }
  function closeModal() {
    if (!activeModal) return;
    document.removeEventListener('keydown', activeModal._onKey);
    if (activeModal.parentNode) activeModal.parentNode.removeChild(activeModal);
    activeModal = null;
  }
  function confirmDialog(options) {
    return new Promise(function (resolve) {
      var m = modal({
        title: options.title || 'Confirmar acción',
        body: '<p style="font-size:.86rem;margin:0">' + U.esc(options.message || '') + '</p>',
        footer: '<button class="btn btn-secondary" type="button" data-confirm-no>Cancelar</button>' +
          '<button class="btn ' + (options.danger ? 'btn-danger' : 'btn-primary') + '" type="button" data-confirm-yes>' + U.esc(options.confirmLabel || 'Confirmar') + '</button>'
      });
      m.el.querySelector('[data-confirm-no]').addEventListener('click', function () { closeModal(); resolve(false); });
      m.el.querySelector('[data-confirm-yes]').addEventListener('click', function () { closeModal(); resolve(true); });
      m.el.addEventListener('click', function (ev) { if (ev.target === m.el) resolve(false); });
    });
  }

  function lightbox(src, caption) {
    var m = modal({
      title: caption || 'Evidencia fotográfica',
      subtitle: 'Archivo asociado a la intervención',
      size: 'lg',
      footer: '<button class="btn btn-secondary" type="button" data-close-lb>Cerrar</button>',
      body: '<figure style="margin:0"><img src="' + U.attr(src) + '" alt="' + U.attr(caption || 'Evidencia') + '" style="width:100%;border-radius:10px;border:1px solid #e3e8e3">' +
        (caption ? '<figcaption class="hint" style="margin-top:.5rem">' + U.esc(caption) + '</figcaption>' : '') + '</figure>'
    });
    m.el.querySelector('[data-close-lb]').addEventListener('click', closeModal);
  }

  /* ------------------------------------------------------------------
     Evidencias fotográficas (RF004 / RF014): compresión en cliente
     ------------------------------------------------------------------ */
  function compressImage(file, maxDim, quality) {
    maxDim = maxDim || 900; quality = quality || 0.68;
    return new Promise(function (resolve, reject) {
      if (!file || !/^image\//.test(file.type)) { reject(new Error('El archivo no es una imagen válida.')); return; }
      var reader = new FileReader();
      reader.onerror = function () { reject(new Error('No se pudo leer el archivo.')); };
      reader.onload = function () {
        var img = new Image();
        img.onerror = function () { reject(new Error('No se pudo procesar la imagen.')); };
        img.onload = function () {
          var ratio = Math.min(1, maxDim / Math.max(img.width, img.height));
          var w = Math.max(1, Math.round(img.width * ratio));
          var h = Math.max(1, Math.round(img.height * ratio));
          var canvas = document.createElement('canvas');
          canvas.width = w; canvas.height = h;
          var ctx = canvas.getContext('2d');
          ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, w, h);
          ctx.drawImage(img, 0, 0, w, h);
          resolve({ dataUrl: canvas.toDataURL('image/jpeg', quality), width: w, height: h, name: file.name || 'evidencia.jpg' });
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  function readPhotos(files) {
    var list = Array.prototype.slice.call(files || []);
    return Promise.all(list.map(function (file) {
      return compressImage(file).then(function (out) {
        return {
          id: U.uid('img'), name: file.name || 'evidencia.jpg', dataUrl: out.dataUrl,
          ts: U.nowISO(), size: Math.round(out.dataUrl.length * 0.75), width: out.width, height: out.height
        };
      });
    }));
  }

  function photoGrid(photos, opts) {
    opts = opts || {};
    if (!photos || !photos.length) {
      return '<div class="photo-empty">' + U.icon('image') + '<span>Sin evidencias fotográficas registradas.</span></div>';
    }
    return '<div class="photo-grid">' + photos.map(function (p) {
      return '<button type="button" class="photo-thumb" data-photo="' + U.attr(p.dataUrl) + '" data-caption="' + U.attr((opts.prefix || '') + (p.name || '') + ' · ' + U.fmtDateTime(p.ts)) + '">' +
        '<img src="' + U.attr(p.dataUrl) + '" alt="Evidencia fotográfica">' +
        (opts.showTime === false ? '' : '<span class="pt-time">' + U.fmtDateTime(p.ts) + '</span>') +
        '</button>';
    }).join('') + '</div>';
  }

  function serialize(form) {
    var out = {};
    Array.prototype.forEach.call(form.elements, function (el) {
      if (!el.name || el.disabled) return;
      if (el.type === 'checkbox') {
        if (el.name.slice(-2) === '[]') {
          var key = el.name.slice(0, -2);
          out[key] = out[key] || [];
          if (el.checked) out[key].push(el.value);
        } else {
          out[el.name] = el.checked;
        }
        return;
      }
      if (el.type === 'radio') {
        if (el.checked) out[el.name] = el.value;
        return;
      }
      if (el.type === 'file') return;
      if (el.type === 'number') { out[el.name] = el.value === '' ? null : Number(el.value); return; }
      out[el.name] = el.value;
    });
    return out;
  }

  function roleTone(role) {
    return { admin: 'purple', vet: 'blue', field: 'green', logistics: 'amber' }[role] || 'gray';
  }

  function tabs(items, activeKey, attrs) {
    return '<div class="tabs" role="tablist">' + items.map(function (it) {
      return '<button type="button" role="tab" class="' + (it.key === activeKey ? 'active' : '') + '" data-tab="' + U.attr(it.key) + '"' +
        (it.count !== undefined ? ' aria-label="' + U.attr(it.label + ': ' + it.count) + '"' : '') + '>' + U.esc(it.label) +
        (it.count !== undefined ? ' <span class="badge badge-gray" style="margin-left:.25rem">' + it.count + '</span>' : '') + '</button>';
    }).join('') + '</div>';
  }

  function infoRow(label, value, cls) {
    return '<div class="meta-item ' + (cls || '') + '"><div class="mi-label">' + U.esc(label) + '</div><div class="mi-value">' + value + '</div></div>';
  }

  S.UI = {
    toast: toast, modal: modal, closeModal: closeModal, confirm: confirmDialog, lightbox: lightbox,
    badge: badge, priorityBadge: priorityBadge, statusBadge: statusBadge, healthBadge: healthBadge,
    empty: empty, compressImage: compressImage, readPhotos: readPhotos, photoGrid: photoGrid,
    serialize: serialize, roleTone: roleTone, tabs: tabs, infoRow: infoRow
  };
})(typeof window !== 'undefined' ? window : this);

/* Portal público: inicio, catálogo de especies, denuncias y seguimiento. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util, D = S.Domain, Store = S.Store, UI = S.UI, Charts = S.Charts, MapView = S.Map;

  function brandBlock(subtitle) {
    return '<a class="pub-brand" href="#/">' +
      '<span class="brand-mark">' + U.icon('paw') + '</span>' +
      '<span>SIFAS<small>' + U.esc(subtitle || 'Fauna silvestre · Junín') + '</small></span>' +
      '</a>';
  }

  function header(active) {
    function nav(hash, label, key) {
      return '<a href="' + hash + '" class="' + (active === key ? 'active' : '') + '">' + label + '</a>';
    }
    return '<header class="pub-header"><div class="pub-header-inner">' + brandBlock() +
      '<nav class="pub-nav" aria-label="Navegación principal">' +
      nav('#/', 'Inicio', 'home') +
      nav('#/especies', 'Especies protegidas', 'species') +
      nav('#/denunciar', 'Reportar infracción', 'denuncia') +
      nav('#/seguimiento', 'Seguimiento', 'tracking') +
      '</nav>' +
      '<a class="btn btn-primary btn-sm" href="#/login" style="margin-left:.6rem">' + U.icon('lock') + 'Acceso institucional</a>' +
      '</div></header>';
  }

  function footer() {
    return '<footer class="pub-footer"><div class="pub-wrap">' +
      '<div class="pf-grid">' +
      '<div><div style="display:flex;align-items:center;gap:.6rem;margin-bottom:.7rem">' +
      '<span class="brand-mark" style="width:36px;height:36px;flex:0 0 36px;border-radius:9px">' + U.icon('paw') + '</span>' +
      '<strong style="color:#fff;letter-spacing:.12em">SIFAS</strong></div>' +
      '<p style="max-width:34ch;line-height:1.6;margin:0">Sistema de información y trazabilidad de fauna silvestre rescatada. Proyecto académico de Análisis y Diseño de Software alineado al ODS 15 y a la Ley N.° 29763.</p></div>' +
      '<div><h4>Portal ciudadano</h4><a href="#/denunciar">Reportar venta o tenencia ilegal</a><a href="#/seguimiento">Consultar una denuncia</a><a href="#/especies">Especies protegidas de Junín</a></div>' +
      '<div><h4>Institución</h4><a href="#/login">Acceso del personal autorizado</a><span style="display:block;padding:.12rem 0">SERFOR — ATFFS Sierra Central</span><span style="display:block;padding:.12rem 0">Sede Huancayo, Junín</span><span style="display:block;padding:.12rem 0">Ley N.° 29763</span></div>' +
      '</div>' +
      '<div class="pf-bottom"><span>© 2026 SIFAS · Universidad Nacional del Centro del Perú — Análisis y Diseño de Software.</span>' +
      '<span>Prototipo académico. No reemplaza los canales oficiales de denuncia de SERFOR.</span></div>' +
      '</div></footer>';
  }

  function layout(content, active) {
    return '<div>' + header(active) + '<main class="pub-main">' + content + '</main>' + footer() + '</div>';
  }

  function speciesCard(sp) {
    var prot = D.PROTECTION[sp.prot] || D.PROTECTION.DD;
    return '<article class="sp-card" data-species="' + U.attr(sp.id) + '" tabindex="0" role="button" aria-label="Ver ficha de ' + U.attr(sp.common) + '">' +
      '<div class="sp-media" style="background:linear-gradient(145deg,' + sp.color[0] + ',' + sp.color[1] + ')">' +
      '<span class="sp-cat">' + U.esc(sp.cat === 'ave' ? 'Ave' : sp.cat === 'mamifero' ? 'Mamífero' : sp.cat === 'reptil' ? 'Reptil' : 'Anfibio') + '</span>' +
      '<span aria-hidden="true">' + sp.emoji + '</span></div>' +
      '<div class="sp-body"><h3>' + U.esc(sp.common) + '</h3>' +
      '<span class="sp-sci">' + U.esc(sp.sci) + '</span>' +
      '<div class="sp-foot">' + UI.badge(prot.label, prot.tone) +
      (sp.endemic ? '<span class="chip" style="font-size:.64rem">Endémica del Perú</span>' : '') +
      '</div></div></article>';
  }

  /* ------------------------------------------------------------------
     Inicio
     ------------------------------------------------------------------ */
  function home() {
    var stats = Store.stats();
    var sp = Store.species();
    var featured = ['sp-oso', 'sp-condor', 'sp-zambullidor', 'sp-mono'].map(function (id) { return Store.findSpecies(id); }).filter(Boolean);
    var content =
      '<section class="hero"><div class="hero-inner">' +
      '<div>' +
      '<span class="eyebrow">' + U.icon('leaf') + 'ODS 15 · Vida de ecosistemas terrestres</span>' +
      '<h1>Proteger la fauna silvestre empieza por <em>registrar cada caso</em>.</h1>' +
      '<p>Plataforma de gestión, trazabilidad y control de fauna silvestre rescatada de la ATFFS Sierra Central — SERFOR Huancayo. Un registro único para la atención veterinaria, la fiscalización ambiental y la participación ciudadana.</p>' +
      '<div class="hero-actions">' +
      '<a class="btn btn-primary btn-lg" href="#/denunciar">' + U.icon('alert') + 'Reportar una infracción</a>' +
      '<a class="btn btn-secondary btn-lg" href="#/especies">' + U.icon('book') + 'Especies protegidas</a>' +
      '</div>' +
      '<div class="hero-meta">' +
      '<span class="hm">' + U.icon('shieldCheck') + 'Ley N.° 29763</span>' +
      '<span class="hm">' + U.icon('lock') + 'Denuncia anónima</span>' +
      '<span class="hm">' + U.icon('map') + 'Datos georreferenciados</span>' +
      '</div></div>' +
      '<aside class="hero-panel" aria-label="Indicadores del sistema">' +
      '<div class="hp-title">' + U.icon('activity') + 'Registro institucional</div>' +
      '<div class="hp-stat"><span class="hp-num">' + stats.total + '</span><span class="hp-lbl">intervenciones registradas</span></div>' +
      '<div class="hp-stat"><span class="hp-num">' + stats.inCare + '</span><span class="hp-lbl">animales en rehabilitación</span></div>' +
      '<div class="hp-stat"><span class="hp-num">' + stats.released + '</span><span class="hp-lbl">liberaciones documentadas</span></div>' +
      '<div class="hp-stat"><span class="hp-num">' + sp.length + '</span><span class="hp-lbl">especies protegidas en el catálogo</span></div>' +
      '<div class="hp-foot">Información consolidada por la ATFFS Sierra Central. Los datos clínicos y las denuncias son de acceso restringido.</div>' +
      '</aside>' +
      '</div></section>' +

      '<section class="pub-section"><div class="pub-wrap">' +
      '<div class="pub-section-head"><div class="kicker">Qué hacemos</div><h2>Un sistema, todos los eslabones de la trazabilidad</h2>' +
      '<p>Desde el decomiso en campo hasta la liberación y el monitoreo posterior, cada dato queda asociado a un código único de intervención.</p></div>' +
      '<div class="feature-grid">' +
      feature('paw', 'Rescate y pre-acta digital', 'El Agente de Campo registra la intervención desde su celular, captura la ubicación GPS y adjunta fotografías como evidencia.') +
      feature('stethoscope', 'Historia clínica digital', 'Los veterinarios documentan diagnósticos, tratamientos, vacunas y dietas sin perder ningún registro previo.') +
      feature('scale', 'Triaje con prioridad clínica', 'Cuatro criterios clínicos determinan automáticamente la prioridad de atención I, II o III.') +
      feature('box', 'Inventario con alertas', 'Control de stock mínimo y vencimientos a 30 días para alimentos, medicamentos y herramientas de contención.') +
      feature('map', 'Mapa de puntos críticos', 'Las coordenadas GPS permiten identificar zonas y carreteras con mayor concentración de intervenciones.') +
      feature('globe', 'Portal ciudadano', 'Denuncias anónimas con fotografías y ubicación, y consulta abierta del catálogo de especies protegidas.') +
      '</div></div></section>' +

      '<section class="pub-section tint"><div class="pub-wrap">' +
      '<div class="pub-section-head"><div class="kicker">Participación ciudadana</div><h2>Tu reporte puede salvar una vida</h2>' +
      '<p>No solicitamos nombre, documento, correo ni teléfono. Solo necesitamos saber qué ocurrió y dónde.</p></div>' +
      '<div class="steps">' +
      step('Describe el hecho', 'Indica si se trata de venta, tenencia, transporte ilegal o maltrato.') +
      step('Adjunta evidencias', 'Fotografías del animal, del lugar o de la publicación que motiva el reporte.') +
      step('Ubica el lugar', 'Usa el GPS de tu celular o marca el punto directamente en el mapa.') +
      step('Recibe un código', 'Guarda el código de seguimiento para consultar el estado de tu denuncia.') +
      '</div>' +
      '<div style="margin-top:1.4rem;display:flex;gap:.6rem;flex-wrap:wrap">' +
      '<a class="btn btn-primary" href="#/denunciar">' + U.icon('send') + 'Registrar denuncia anónima</a>' +
      '<a class="btn btn-secondary" href="#/seguimiento">' + U.icon('search') + 'Consultar mi denuncia</a>' +
      '</div></div></section>' +

      '<section class="pub-section"><div class="pub-wrap">' +
      '<div class="pub-section-head" style="display:flex;align-items:flex-end;gap:1rem;max-width:none;flex-wrap:wrap">' +
      '<div style="max-width:640px"><div class="kicker">Catálogo regional</div><h2>Especies protegidas de Junín</h2>' +
      '<p>Consulta características, hábitat y condición de protección sin necesidad de iniciar sesión.</p></div>' +
      '<a class="btn btn-secondary" href="#/especies" style="margin-left:auto">Ver las ' + sp.length + ' especies ' + U.icon('arrowRight') + '</a></div>' +
      '<div class="species-preview">' + featured.map(speciesCard).join('') + '</div>' +
      '</div></section>' +

      '<section class="pub-section tint"><div class="pub-wrap" style="display:grid;grid-template-columns:1.1fr .9fr;gap:2rem;align-items:center" id="home-cta">' +
      '<div><div class="kicker">Marco legal</div><h2 style="font-size:1.7rem;letter-spacing:-.03em">El tráfico ilegal de fauna silvestre es un delito</h2>' +
      '<p style="color:var(--muted);font-size:.9rem;line-height:1.65;margin-top:.6rem">La Ley Forestal y de Fauna Silvestre (Ley N.° 29763) regula el aprovechamiento sostenible y la protección de la fauna silvestre. La Estrategia Nacional para Reducir el Tráfico Ilegal de Fauna Silvestre impulsa la interoperabilidad y el gobierno digital para fiscalizar estas conductas.</p>' +
      '<div class="pill-row"><span class="chip">' + U.icon('shieldCheck') + 'Meta 15.7 del ODS 15</span><span class="chip">' + U.icon('scale') + 'FEMA</span><span class="chip">' + U.icon('leaf') + 'SERFOR</span></div></div>' +
      '<div class="card card-pad"><h3 style="font-size:.95rem;margin-bottom:.4rem">¿Encontraste un animal silvestre herido?</h3>' +
      '<p style="font-size:.8rem;color:var(--muted)">No lo manipules sin orientación. Comunícate con la ATFFS Sierra Central o registra el caso en el portal para que el personal autorizado lo evalúe.</p>' +
      '<div class="alert-banner ab-green" style="margin:0">' + U.icon('info') + '<span><strong>Recuerda:</strong> tener fauna silvestre como mascota requiere autorización y, en la mayoría de casos, está prohibido.</span></div>' +
      '<a class="btn btn-primary btn-block mt-2" href="#/denunciar">' + U.icon('alert') + 'Reportar ahora</a></div>' +
      '</div></section>';

    return { html: layout(content, 'home'), mount: function (root) { bindSpeciesCards(root); } };
  }

  function feature(icon, title, text) {
    return '<article class="feature"><div class="f-icon">' + U.icon(icon) + '</div><h3>' + U.esc(title) + '</h3><p>' + U.esc(text) + '</p></article>';
  }
  function step(title, text) {
    return '<div class="step-card"><h4>' + U.esc(title) + '</h4><p>' + U.esc(text) + '</p></div>';
  }
  function bindSpeciesCards(root) {
    U.on(root, '[data-species]', 'click', function () { location.hash = '#/especies/' + this.getAttribute('data-species'); });
    U.on(root, '[data-species]', 'keydown', function (ev) {
      if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); location.hash = '#/especies/' + this.getAttribute('data-species'); }
    });
  }

  /* ------------------------------------------------------------------
     Catálogo de especies (RF015)
     ------------------------------------------------------------------ */
  function speciesList(params) {
    var all = Store.species();
    var content =
      '<section style="background:linear-gradient(160deg,#0b3d2c,#0f553d);color:#fff;padding:2.6rem 0 2.2rem">' +
      '<div class="pub-wrap"><div class="kicker" style="color:#7fd1a8">Consulta pública · sin registro</div>' +
      '<h1 style="font-size:2.1rem;letter-spacing:-.035em;color:#fff">Especies silvestres protegidas de Junín</h1>' +
      '<p style="color:#b9d8c9;max-width:62ch;margin-top:.5rem;font-size:.92rem">Catálogo informativo de fauna silvestre de la región. La condición de protección corresponde a la normativa peruana y a los apéndices CITES de referencia.</p>' +
      '<div class="toolbar" style="margin-top:1.2rem;margin-bottom:0">' +
      '<div class="search-box" style="max-width:380px"><span style="color:#7fa393">' + U.icon('search') + '</span>' +
      '<input class="input" id="sp-search" type="search" placeholder="Buscar por nombre común o científico…" aria-label="Buscar especie" style="padding-left:2rem"></div>' +
      '<select class="select" id="sp-cat" aria-label="Filtrar por categoría" style="background:#fff">' +
      '<option value="">Todas las categorías</option><option value="ave">Aves</option><option value="mamifero">Mamíferos</option><option value="reptil">Reptiles</option><option value="anfibio">Anfibios</option></select>' +
      '<select class="select" id="sp-prot" aria-label="Filtrar por condición" style="background:#fff"><option value="">Toda condición</option>' +
      Object.keys(D.PROTECTION).map(function (k) { return '<option value="' + k + '">' + D.PROTECTION[k].label + ' (' + k + ')</option>'; }).join('') + '</select>' +
      '<span class="result-count" id="sp-count" style="color:#a9cbbd;margin-left:auto"></span>' +
      '</div></div></section>' +
      '<section class="pub-section"><div class="pub-wrap">' +
      '<div class="grid grid-auto" id="sp-grid"></div>' +
      '<div id="sp-empty" class="is-hidden">' + UI.empty('search', 'Sin resultados', 'Prueba con otro nombre o cambia los filtros de búsqueda.') + '</div>' +
      '</div></section>';
    return {
      html: layout(content, 'species'),
      mount: function (root) {
        var grid = root.querySelector('#sp-grid');
        var search = root.querySelector('#sp-search');
        var cat = root.querySelector('#sp-cat');
        var prot = root.querySelector('#sp-prot');
        var count = root.querySelector('#sp-count');
        function draw() {
          var q = U.normalize(search.value);
          var list = all.filter(function (sp) {
            var matchQ = !q || U.normalize(sp.common + ' ' + sp.sci + ' ' + sp.habitat).indexOf(q) >= 0;
            var matchCat = !cat.value || sp.cat === cat.value;
            var matchProt = !prot.value || sp.prot === prot.value;
            return matchQ && matchCat && matchProt;
          });
          grid.innerHTML = list.map(speciesCard).join('');
          root.querySelector('#sp-empty').classList.toggle('is-hidden', list.length > 0);
          count.textContent = list.length + ' de ' + all.length + ' especies';
          bindSpeciesCards(grid);
        }
        search.addEventListener('input', U.debounce(draw, 180));
        cat.addEventListener('change', draw);
        prot.addEventListener('change', draw);
        draw();
      }
    };
  }

  function speciesDetail(params) {
    var sp = Store.findSpecies(params.id);
    if (!sp) return { html: layout('<div class="pub-wrap" style="padding:3rem 0">' + UI.empty('search', 'Especie no encontrada', 'El registro solicitado no existe en el catálogo.', '<a class="btn btn-secondary" href="#/especies">Volver al catálogo</a>') + '</div>', 'species'), mount: function () {} };
    var prot = D.PROTECTION[sp.prot] || D.PROTECTION.DD;
    var related = Store.species().filter(function (s) { return s.id !== sp.id && s.cat === sp.cat; }).slice(0, 3);
    var content = '<section class="pub-wrap" style="padding:1.4rem 0 0"><a href="#/especies" class="btn btn-ghost btn-sm">' + U.icon('arrowLeft') + 'Volver al catálogo</a></section>' +
      '<section class="pub-section" style="padding-top:1rem"><div class="pub-wrap" style="max-width:960px">' +
      '<div class="card card-pad" style="padding:1.6rem">' +
      '<div class="sp-detail-hero">' +
      '<div class="sp-emoji" style="background:linear-gradient(145deg,' + sp.color[0] + ',' + sp.color[1] + ')">' + sp.emoji + '</div>' +
      '<div style="min-width:0"><div class="kicker">' + U.esc(sp.cat === 'ave' ? 'Ave' : sp.cat === 'mamifero' ? 'Mamífero' : sp.cat === 'reptil' ? 'Reptil' : 'Anfibio') + (sp.endemic ? ' · Endémica del Perú' : '') + '</div>' +
      '<h1 style="font-size:1.9rem">' + U.esc(sp.common) + '</h1>' +
      '<p class="mono" style="color:var(--muted);margin:.15rem 0 .5rem">' + U.esc(sp.sci) + '</p>' +
      '<div class="pill-row">' + UI.badge(prot.label + ' (' + prot.code + ')', prot.tone) +
      (sp.cites !== '—' ? UI.badge('CITES ' + sp.cites, 'blue') : '') + '</div></div></div>' +
      '<div class="divider"></div>' +
      '<div class="split-even">' +
      '<div><h3 style="font-size:.95rem;margin-bottom:.5rem">Características principales</h3><p style="font-size:.85rem;color:var(--ink-soft)">' + U.esc(sp.chars) + '</p>' +
      '<h3 style="font-size:.95rem;margin:1rem 0 .5rem">Hábitat</h3><p style="font-size:.85rem;color:var(--ink-soft)">' + U.esc(sp.habitat) + '</p></div>' +
      '<div><div class="card card-pad" style="background:var(--sand-50)"><h3 style="font-size:.85rem;margin-bottom:.4rem">' + U.icon('alert') + ' Amenazas</h3>' +
      '<p style="font-size:.8rem;color:var(--ink-soft);margin-bottom:.8rem">' + U.esc(sp.threats) + '</p>' +
      '<h3 style="font-size:.85rem;margin-bottom:.4rem">' + U.icon('shieldCheck') + ' ¿Cómo ayudar?</h3>' +
      '<p style="font-size:.8rem;color:var(--ink-soft);margin:0">' + U.esc(sp.rec) + '</p></div></div></div>' +
      '<div class="alert-banner ab-green" style="margin-top:1.2rem">' + U.icon('info') +
      '<span><strong>Condición de protección:</strong> ' + U.esc(prot.label) + '. La tenencia, venta o transporte de fauna silvestre sin autorización constituye una infracción a la Ley N.° 29763.</span></div>' +
      (related.length ? '<div class="divider"></div><h3 style="font-size:.95rem;margin-bottom:.7rem">Otras especies de la misma categoría</h3><div class="grid grid-3">' + related.map(speciesCard).join('') + '</div>' : '') +
      '</div></div></section>';
    return { html: layout(content, 'species'), mount: bindSpeciesCards };
  }

  /* ------------------------------------------------------------------
     Denuncia ciudadana (RF013, RF014, RD008)
     ------------------------------------------------------------------ */
  function denuncia() {
    var spOptions = Store.species().map(function (s) { return '<option value="' + U.attr(s.common) + '">'; }).join('');
    var content = '<section class="pub-wrap" style="padding:2rem 1.5rem 0;max-width:960px">' +
      '<div class="kicker">Canal ciudadano · 100% anónimo</div>' +
      '<h1 style="font-size:1.9rem">Reportar venta o tenencia ilegal de fauna silvestre</h1>' +
      '<p style="color:var(--muted);max-width:68ch;font-size:.88rem">Tu reporte será evaluado por el personal autorizado de la ATFFS Sierra Central. No solicitamos nombre, documento, correo ni teléfono: la información se registra sin datos personales.</p>' +
      '<div class="alert-banner ab-green">' + U.icon('lock') +
      '<span><strong>Denuncia anónima.</strong> El sistema no almacena información que permita identificar al ciudadano. Guarda el código que recibirás para hacer seguimiento.</span></div>' +
      '</section>' +
      '<section class="pub-section" style="padding-top:.6rem"><div class="pub-wrap" style="max-width:960px">' +
      '<form id="den-form" novalidate>' +
      '<div class="split" style="align-items:start">' +
      '<div>' +
      '<fieldset class="form-section"><div class="fs-title">' + U.icon('alert') + '1. Hecho observado</div>' +
      '<div class="form-grid">' +
      '<div class="field"><label for="den-type">Tipo de infracción <span class="req">*</span></label>' +
      '<select class="select" id="den-type" name="type" required>' + D.DENUNCIA_TYPES.map(function (t) { return '<option value="' + t.key + '">' + t.label + '</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label for="den-species">Especie (si la conoces)</label>' +
      '<input class="input" id="den-species" name="species" list="sp-list" placeholder="Ej. Gallito de las rocas" maxlength="80">' +
      '<datalist id="sp-list">' + spOptions + '</datalist><span class="hint">Puedes dejarlo vacío si no identificas la especie.</span></div>' +
      '<div class="field span-2"><label for="den-desc">Descripción del hecho <span class="req">*</span></label>' +
      '<textarea class="textarea" id="den-desc" name="description" minlength="20" maxlength="1200" placeholder="Describe qué observaste, cuándo, quiénes participan y cualquier detalle que ayude a la fiscalización…" required></textarea>' +
      '<div class="err" data-err="description">Describe el hecho con al menos 20 caracteres.</div>' +
      '<span class="hint"><span id="den-chars">0</span>/1200 caracteres.</span></div>' +
      '</div></fieldset>' +
      '<fieldset class="form-section"><div class="fs-title">' + U.icon('pin') + '2. Ubicación del hecho</div>' +
      '<p class="fs-sub">Captura tu ubicación actual con GPS o marca el punto exacto sobre el mapa. Al menos una de las dos opciones es necesaria.</p>' +
      '<div class="form-grid">' +
      '<div class="field span-2"><label>Punto en el mapa</label><div id="den-map" style="min-height:230px"></div>' +
      '<div class="err" data-err="location">Indique la ubicación mediante GPS o marcando un punto en el mapa.</div></div>' +
      '<div class="field"><label for="den-ref">Referencia del lugar</label><input class="input" id="den-ref" name="reference" placeholder="Calle, avenida, mercado, distrito…" maxlength="140"></div>' +
      '<div class="field"><label>Coordenadas</label><div class="input-group">' +
      '<input class="input" id="den-lat" name="lat" readonly placeholder="Latitud"><input class="input" id="den-lng" name="lng" readonly placeholder="Longitud"></div></div>' +
      '<div class="field span-2"><div style="display:flex;gap:.5rem;flex-wrap:wrap"><button class="btn btn-secondary btn-sm" type="button" id="den-gps">' + U.icon('pin') + 'Usar mi ubicación GPS</button>' +
      '<button class="btn btn-ghost btn-sm" type="button" id="den-clear">' + U.icon('x') + 'Limpiar ubicación</button>' +
      '<span class="hint" id="den-gps-status" style="align-self:center">También puedes hacer clic en el mapa.</span></div></div>' +
      '</div></fieldset>' +
      '</div>' +
      '<aside>' +
      '<fieldset class="form-section"><div class="fs-title">' + U.icon('camera') + '3. Evidencias fotográficas</div>' +
      '<p class="fs-sub">Adjunta una o más fotografías del animal, del lugar o de la publicación. Son opcionales.</p>' +
      '<div class="uploader"><div class="up-icon">' + U.icon('camera') + '</div>' +
      '<p>Fotografía el hecho o adjunta imágenes existentes</p>' +
      '<div class="up-actions"><label class="btn btn-secondary btn-sm" style="margin:0">' + U.icon('camera') + 'Tomar foto<input type="file" id="den-camera" accept="image/*" capture="environment" multiple hidden></label>' +
      '<label class="btn btn-secondary btn-sm" style="margin:0">' + U.icon('image') + 'Adjuntar<input type="file" id="den-files" accept="image/*" multiple hidden></label></div>' +
      '<div class="hint">Máximo 6 imágenes · se comprimen automáticamente.</div></div>' +
      '<div class="photo-grid" id="den-photos" style="margin-top:.7rem"></div></fieldset>' +
      '<fieldset class="form-section" style="background:var(--green-50);border-color:#cbe8da">' +
      '<div class="fs-title" style="color:var(--green-800)">' + U.icon('shieldCheck') + 'Compromiso de privacidad</div>' +
      '<p style="font-size:.78rem;color:var(--ink-soft);margin:0">No se solicitan datos personales obligatorios. La denuncia se identifica únicamente con un código de seguimiento. Las evidencias se asocian al reporte y no al ciudadano.</p>' +
      '</fieldset>' +
      '<button class="btn btn-primary btn-lg btn-block" type="submit" id="den-submit">' + U.icon('send') + 'Registrar denuncia anónima</button>' +
      '<p class="hint" style="text-align:center;margin-top:.6rem">Al enviar, aceptas que la información sea revisada por la autoridad competente.</p>' +
      '</aside></div></form>' +
      '<div id="den-success" class="is-hidden"></div>' +
      '</div></section>';

    return {
      html: layout(content, 'denuncia'),
      mount: function (root) {
        var state = { photos: [], location: null };
        var form = root.querySelector('#den-form');
        var mapHolder = root.querySelector('#den-map');
        var latInput = root.querySelector('#den-lat');
        var lngInput = root.querySelector('#den-lng');
        var status = root.querySelector('#den-gps-status');
        var chars = root.querySelector('#den-chars');

        var map = MapView.create(mapHolder, {
          markers: [], pick: true, showZones: true, legend: false, zoom: true,
          onPick: function (ll) {
            state.location = { lat: ll.lat, lng: ll.lng, source: 'map', reference: root.querySelector('#den-ref').value };
            latInput.value = ll.lat; lngInput.value = ll.lng;
            map.update({ pickMarker: ll });
            status.textContent = 'Ubicación fijada en el mapa (' + ll.lat + ', ' + ll.lng + ').';
            root.querySelector('[data-err="location"]').classList.remove('show');
          }
        });

        root.querySelector('#den-desc').addEventListener('input', function () { chars.textContent = this.value.length; });
        root.querySelector('#den-gps').addEventListener('click', function () {
          if (!navigator.geolocation) { UI.toast('Este navegador no permite obtener la ubicación. Marca el punto en el mapa.', 'warn'); return; }
          status.textContent = 'Obteniendo ubicación GPS…';
          navigator.geolocation.getCurrentPosition(function (pos) {
            var ll = { lat: +pos.coords.latitude.toFixed(5), lng: +pos.coords.longitude.toFixed(5) };
            state.location = { lat: ll.lat, lng: ll.lng, source: 'gps' };
            latInput.value = ll.lat; lngInput.value = ll.lng;
            map.update({ pickMarker: ll });
            status.textContent = 'Ubicación GPS capturada (precisión ±' + Math.round(pos.coords.accuracy) + ' m).';
            root.querySelector('[data-err="location"]').classList.remove('show');
          }, function () {
            status.textContent = 'No se pudo obtener el GPS. Marca el punto en el mapa.';
            UI.toast('No fue posible obtener la ubicación GPS. Puedes marcar el punto manualmente en el mapa.', 'warn');
          }, { enableHighAccuracy: true, timeout: 9000, maximumAge: 0 });
        });
        root.querySelector('#den-clear').addEventListener('click', function () {
          state.location = null; latInput.value = ''; lngInput.value = '';
          map.update({ pickMarker: null }); status.textContent = 'También puedes hacer clic en el mapa.';
        });

        function addFiles(files) {
          var remaining = 6 - state.photos.length;
          if (remaining <= 0) { UI.toast('Solo se permiten hasta 6 fotografías por denuncia.', 'warn'); return; }
          UI.readPhotos(Array.prototype.slice.call(files).slice(0, remaining)).then(function (photos) {
            state.photos = state.photos.concat(photos);
            drawPhotos();
            if (files.length > remaining) UI.toast('Se adjuntaron solo ' + remaining + ' imágenes por el límite establecido.', 'warn');
          }).catch(function (err) { UI.toast(err.message, 'error'); });
        }
        function drawPhotos() {
          var holder = root.querySelector('#den-photos');
          holder.innerHTML = state.photos.map(function (p, i) {
            return '<div class="photo-thumb" style="cursor:default"><img src="' + U.attr(p.dataUrl) + '" alt="Evidencia">' +
              '<button type="button" class="btn btn-sm" data-remove-photo="' + i + '" aria-label="Quitar foto" style="position:absolute;top:3px;right:3px;padding:2px 6px;background:rgba(6,33,23,.75);color:#fff;border:0">×</button>' +
              '<span class="pt-time">' + U.fmtTime(p.ts) + '</span></div>';
          }).join('');
        }
        U.on(root, '[data-remove-photo]', 'click', function () {
          state.photos.splice(Number(this.getAttribute('data-remove-photo')), 1); drawPhotos();
        });
        root.querySelector('#den-camera').addEventListener('change', function () { addFiles(this.files); this.value = ''; });
        root.querySelector('#den-files').addEventListener('change', function () { addFiles(this.files); this.value = ''; });

        form.addEventListener('submit', function (ev) {
          ev.preventDefault();
          var desc = root.querySelector('#den-desc').value.trim();
          var descErr = root.querySelector('[data-err="description"]');
          var locErr = root.querySelector('[data-err="location"]');
          descErr.classList.toggle('show', desc.length < 20);
          root.querySelector('#den-desc').classList.toggle('is-invalid', desc.length < 20);
          var hasLoc = !!state.location;
          locErr.classList.toggle('show', !hasLoc);
          if (desc.length < 20 || !hasLoc) {
            UI.toast('Revisa los campos marcados antes de enviar la denuncia.', 'error');
            if (desc.length < 20) root.querySelector('#den-desc').focus();
            return;
          }
          try {
            var den = Store.createDenuncia({
              type: root.querySelector('#den-type').value,
              species: root.querySelector('#den-species').value.trim() || 'No identificada',
              description: desc,
              location: {
                lat: state.location.lat, lng: state.location.lng, source: state.location.source,
                reference: root.querySelector('#den-ref').value.trim() || 'Referencia no especificada'
              },
              photos: state.photos
            });
            form.classList.add('is-hidden');
            var success = root.querySelector('#den-success');
            success.classList.remove('is-hidden');
            success.innerHTML = '<div class="card card-pad" style="max-width:640px;margin:0 auto;text-align:center;padding:2rem">' +
              '<div style="width:64px;height:64px;border-radius:50%;background:var(--green-100);display:grid;place-items:center;margin:0 auto .9rem;color:var(--green-700)">' + U.icon('checkCircle') + '</div>' +
              '<h2 style="font-size:1.4rem">Denuncia registrada</h2>' +
              '<p style="color:var(--muted);font-size:.85rem">Tu reporte fue recibido por la ATFFS Sierra Central. No se solicitó ni almacenó ningún dato personal.</p>' +
              '<div style="background:var(--green-50);border:1px dashed #a9d8c3;border-radius:12px;padding:1rem;margin:1rem 0">' +
              '<div class="hint" style="text-transform:uppercase;letter-spacing:.08em;font-weight:800;font-size:.66rem">Código de seguimiento</div>' +
              '<div class="mono" style="font-size:1.35rem;font-weight:800;color:var(--green-900);letter-spacing:.06em" id="den-code">' + U.esc(den.code) + '</div></div>' +
              '<p style="font-size:.78rem;color:var(--muted)">Guarda este código. Es el único medio para consultar el estado de tu denuncia sin identificarte.</p>' +
              '<div style="display:flex;gap:.5rem;justify-content:center;flex-wrap:wrap">' +
              '<button class="btn btn-primary" type="button" data-copy-code="' + U.attr(den.code) + '">' + U.icon('copy') + 'Copiar código</button>' +
              '<a class="btn btn-secondary" href="#/seguimiento?code=' + encodeURIComponent(den.code) + '">' + U.icon('search') + 'Consultar estado</a>' +
              '<a class="btn btn-ghost" href="#/">Volver al inicio</a></div></div>';
            success.scrollIntoView({ behavior: 'smooth', block: 'center' });
            UI.toast('Denuncia registrada con el código ' + den.code + '.', 'success');
          } catch (err) {
            UI.toast(err.message, 'error');
          }
        });
        U.on(root, '[data-copy-code]', 'click', function () {
          U.copyText(this.getAttribute('data-copy-code')).then(function () { UI.toast('Código copiado al portapapeles.', 'success'); });
        });
      }
    };
  }

  /* ------------------------------------------------------------------
     Seguimiento de denuncia
     ------------------------------------------------------------------ */
  function seguimiento(params) {
    var content = '<section class="pub-wrap" style="padding:2.6rem 1.5rem 0;max-width:760px">' +
      '<div class="kicker">Consulta ciudadana</div>' +
      '<h1 style="font-size:1.9rem">Seguimiento de una denuncia</h1>' +
      '<p style="color:var(--muted);font-size:.88rem">Ingresa el código que recibiste al registrar tu reporte. No necesitas cuenta ni datos personales.</p>' +
      '<form id="track-form" class="card card-pad" style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:1rem">' +
      '<input class="input" id="track-code" placeholder="Ej. DEN-2026-0001" style="flex:1;min-width:220px;text-transform:uppercase" autocomplete="off" aria-label="Código de denuncia">' +
      '<button class="btn btn-primary" type="submit">' + U.icon('search') + 'Consultar</button></form>' +
      '</section><section class="pub-section" style="padding-top:1.2rem"><div class="pub-wrap" style="max-width:760px" id="track-result"></div></section>';
    return {
      html: layout(content, 'tracking'),
      mount: function (root) {
        var input = root.querySelector('#track-code');
        var result = root.querySelector('#track-result');
        var q = (params.query && (params.query.code || '')) || '';
        if (q) input.value = q.toUpperCase();
        function render() {
          var code = input.value.trim();
          if (!code) { result.innerHTML = ''; return; }
          var den = Store.findDenunciaByCode(code);
          if (!den) {
            result.innerHTML = '<div class="card card-pad">' + UI.empty('search', 'No encontramos ese código', 'Verifica que el código esté completo, incluyendo el guion y el año. Ejemplo: DEN-2026-0001.') + '</div>';
            return;
          }
          var st = D.DENUNCIA_STATUS[den.status] || { label: den.status, tone: 'gray' };
          var tipo = (D.DENUNCIA_TYPES.filter(function (t) { return t.key === den.type; })[0] || {}).label || den.type;
          result.innerHTML = '<div class="card">' +
            '<div class="card-head"><div><div class="hint" style="text-transform:uppercase;letter-spacing:.08em;font-weight:800;font-size:.64rem">Reporte ciudadano</div>' +
            '<h3 class="mono" style="font-size:1rem">' + U.esc(den.code) + '</h3></div>' +
            '<div class="ch-actions">' + UI.badge(st.label, st.tone) + '</div></div>' +
            '<div class="card-body">' +
            '<div class="meta-grid">' + UI.infoRow('Tipo de infracción', U.esc(tipo)) + UI.infoRow('Fecha de registro', U.fmtDateTime(den.ts)) +
            UI.infoRow('Especie reportada', U.esc(den.species)) + UI.infoRow('Ubicación', U.esc((den.location && den.location.reference) || 'No especificada')) + '</div>' +
            '<div class="divider"></div><div class="fs-75"><strong>Descripción registrada</strong><p style="margin:.35rem 0 0;color:var(--ink-soft)">' + U.esc(den.description) + '</p></div>' +
            (den.photos && den.photos.length ? '<div class="divider"></div><strong class="fs-75">Evidencias</strong>' + UI.photoGrid(den.photos) : '') +
            '<div class="divider"></div><div class="fs-75"><strong>Historial de atención</strong>' +
            '<div class="timeline" style="margin-top:.6rem"><div class="tl-item"><div class="tl-head"><span class="tl-title">Denuncia registrada</span><span class="tl-time">' + U.fmtDateTime(den.ts) + '</span></div>' +
            '<div class="tl-body">Recibida por el canal ciudadano anónimo. Sin datos personales asociados.</div></div>' +
            den.notes.map(function (n) {
              return '<div class="tl-item"><div class="tl-head"><span class="tl-title">Actualización del reporte</span><span class="tl-time">' + U.fmtDateTime(n.ts) + '</span></div>' +
                '<div class="tl-body">' + U.esc(n.text) + '</div></div>';
            }).join('') + '</div></div>' +
            '<div class="alert-banner ab-blue" style="margin:1rem 0 0">' + U.icon('info') + '<span>Por seguridad, no se muestran datos internos de fiscalización ni la identidad de terceros. La denuncia no revela la identidad del ciudadano.</span></div>' +
            '</div></div>';
        }
        root.querySelector('#track-form').addEventListener('submit', function (ev) { ev.preventDefault(); render(); });
        U.on(root, '[data-photo]', 'click', function () { UI.lightbox(this.getAttribute('data-photo'), this.getAttribute('data-caption')); });
        if (q) render();
      }
    };
  }

  /* ------------------------------------------------------------------
     Acceso institucional (RF001)
     ------------------------------------------------------------------ */
  function login() {
    var demos = [
      { role: 'Administrador', email: 'admin@serfor.gob.pe', pass: 'Admin2026!' },
      { role: 'Médico Veterinario', email: 'veterinario@serfor.gob.pe', pass: 'Clinica2026!' },
      { role: 'Agente de Campo', email: 'agente@serfor.gob.pe', pass: 'Campo2026!' },
      { role: 'Logística e Insumos', email: 'logistica@serfor.gob.pe', pass: 'Stock2026!' }
    ];
    var content = '<div class="login-page">' +
      '<aside class="login-aside">' +
      '<div class="login-brand"><span class="brand-mark">' + U.icon('paw') + '</span><div><strong>SIFAS</strong><span>SERFOR · Junín</span></div></div>' +
      '<div class="login-hero"><span class="eyebrow">' + U.icon('lock') + 'Acceso institucional</span>' +
      '<h1>Gestión y trazabilidad de fauna silvestre.</h1>' +
      '<p>Registra rescates, documenta la historia clínica, controla el inventario y consolida los indicadores de la ATFFS Sierra Central.</p></div>' +
      '<div class="login-points">' +
      '<div class="login-point">' + U.icon('shieldCheck') + '<span>Control de acceso por roles: Agente de Campo, Médico Veterinario, Logística y Administrador.</span></div>' +
      '<div class="login-point">' + U.icon('file') + '<span>Trazabilidad completa: pre-acta digital, historia clínica y decisión técnica.</span></div>' +
      '<div class="login-point">' + U.icon('lock') + '<span>Contraseñas resguardadas mediante derivación criptográfica con sal; auditoría de acciones.</span></div>' +
      '</div>' +
      '</aside>' +
      '<div class="login-main"><div class="login-card">' +
      '<div class="lc-head"><h2>Iniciar sesión</h2><p class="lc-sub">Ingresa con las credenciales asignadas por el Administrador.</p></div>' +
      '<div class="login-error" id="login-error">' + U.icon('alert') + '<span></span></div>' +
      '<form id="login-form" novalidate>' +
      '<div class="field"><label for="login-email">Usuario institucional</label>' +
      '<div class="input-icon">' + U.icon('user') + '<input class="input" id="login-email" type="email" autocomplete="username" placeholder="nombre@serfor.gob.pe" required></div></div>' +
      '<div class="field"><label for="login-pass">Contraseña</label><div class="pw-wrap">' +
      '<input class="input" id="login-pass" type="password" autocomplete="current-password" placeholder="••••••••" required>' +
      '<button class="pw-toggle" type="button" id="pw-toggle" aria-label="Mostrar contraseña">' + U.icon('eye') + '</button></div></div>' +
      '<div style="display:flex;align-items:center;justify-content:space-between;margin:.2rem 0 .9rem">' +
      '<label class="check" style="font-size:.75rem"><input type="checkbox" id="login-remember"> Mantener sesión en este equipo</label>' +
      '<span class="hint" style="font-size:.7rem">Sesión de 8 horas</span></div>' +
      '<button class="btn btn-primary btn-block btn-lg" type="submit" id="login-btn">' + U.icon('lock') + 'Ingresar al sistema</button>' +
      '</form>' +
      '<div class="demo-box"><div class="db-title">' + U.icon('info') + 'Cuentas de demostración</div>' +
      demos.map(function (d) {
        return '<div class="demo-row"><span class="dr-role">' + U.esc(d.role) + '</span><code>' + U.esc(d.email) + '</code>' +
          '<button type="button" data-demo-email="' + U.attr(d.email) + '" data-demo-pass="' + U.attr(d.pass) + '">Usar</button></div>';
      }).join('') +
      '</div>' +
      '<p class="login-foot">Sistema académico de demostración. Los datos se almacenan en este navegador.<br>' +
      '<a href="#/">Volver al portal público</a> · <a href="#/especies">Consultar especies</a></p>' +
      '</div></div></div>';
    return {
      html: content,
      mount: function (root) {
        var form = root.querySelector('#login-form');
        var errorBox = root.querySelector('#login-error');
        var btn = root.querySelector('#login-btn');
        function showError(msg) {
          errorBox.querySelector('span').textContent = msg;
          errorBox.classList.add('show');
        }
        root.querySelector('#pw-toggle').addEventListener('click', function () {
          var input = root.querySelector('#login-pass');
          var showing = input.type === 'text';
          input.type = showing ? 'password' : 'text';
          this.innerHTML = U.icon(showing ? 'eye' : 'x');
          this.setAttribute('aria-label', showing ? 'Mostrar contraseña' : 'Ocultar contraseña');
        });
        U.on(root, '[data-demo-email]', 'click', function () {
          root.querySelector('#login-email').value = this.getAttribute('data-demo-email');
          root.querySelector('#login-pass').value = this.getAttribute('data-demo-pass');
          errorBox.classList.remove('show');
          root.querySelector('#login-btn').focus();
        });
        form.addEventListener('submit', function (ev) {
          ev.preventDefault();
          errorBox.classList.remove('show');
          var email = root.querySelector('#login-email').value;
          var pass = root.querySelector('#login-pass').value;
          if (!email || !pass) { showError('Ingrese su usuario y contraseña.'); return; }
          btn.classList.add('is-disabled');
          btn.innerHTML = U.icon('refresh') + 'Verificando…';
          setTimeout(function () {
            var res = S.Auth.login(email, pass);
            if (!res.ok) {
              showError(res.error);
              btn.classList.remove('is-disabled');
              btn.innerHTML = U.icon('lock') + 'Ingresar al sistema';
              UI.toast(res.error, 'error', 'No se pudo iniciar sesión');
              return;
            }
            var target = sessionStorage.getItem('sifas.redirect') || '#/app/panel';
            sessionStorage.removeItem('sifas.redirect');
            UI.toast('Bienvenido(a), ' + res.user.name.split(' ')[0] + '.', 'success', 'Sesión iniciada');
            location.hash = target;
          }, 60);
        });
      }
    };
  }

  S.Views = S.Views || {};
  S.Views.public = {
    home: home, speciesList: speciesList, speciesDetail: speciesDetail,
    denuncia: denuncia, seguimiento: seguimiento, login: login
  };
})(typeof window !== 'undefined' ? window : this);

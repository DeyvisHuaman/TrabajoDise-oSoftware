/* Capa de persistencia local y reglas de negocio.
   En un despliegue institucional esta capa se sustituye por una API REST +
   PostgreSQL; la interfaz de operaciones se mantiene idéntica. */
(function (global) {
  'use strict';
  var S = global.SIFAS = global.SIFAS || {};
  var U = S.Util, D = S.Domain, H = S.Hash;

  var KEY = 'sifas.db.v3';
  var db = null;

  /* ==================================================================
     Semilla de demostración
     ================================================================== */
  function hash(pw) { return H.hashPassword(pw); }

  var SPECIES_SEED = [
    { id:'sp-oso', common:'Oso de anteojos', sci:'Tremarctos ornatus', cat:'mamifero', prot:'EN', cites:'I', emoji:'🐻', color:['#6d4c33','#2f2117'], habitat:'Bosques nublados y páramos de la vertiente oriental andina, entre 1 000 y 4 200 m s. n. m.', chars:'Mamífero plantígrado de pelaje negro con manchas faciales claras. Es el único oso sudamericano y un importante dispersor de semillas.', threats:'Pérdida de hábitat, caza por conflicto con cultivos y tráfico de crías para espectáculos.', rec:'No adquirir crías ni productos derivados. Reportar avistamientos o tenencia ilegal a la ATFFS.', endemic:false },
    { id:'sp-condor', common:'Cóndor andino', sci:'Vultur gryphus', cat:'ave', prot:'EN', cites:'I', emoji:'🦅', color:['#3c4a52','#141c21'], habitat:'Acantilados y punas altoandinas; en Junín se le observa en zonas de pastizales y quebradas.', chars:'Ave carroñera de gran envergadura (hasta 3.2 m). Cumple un rol sanitario al consumir animales muertos.', threats:'Envenenamiento por cebos tóxicos, caza ilegal y uso de partes en rituales.', rec:'Denunciar la caza o comercio de plumas y especímenes. Evitar el uso de cebos tóxicos.', endemic:false },
    { id:'sp-zambullidor', common:'Zambullidor de Junín', sci:'Podiceps taczanowskii', cat:'ave', prot:'CR', cites:'I', emoji:'🦆', color:['#4e6a74','#1d2b33'], habitat:'Exclusivo del lago Chinchaycocha (Junín), a 4 080 m s. n. m.', chars:'Ave acuática endémica del lago de Junín, no voladora, adaptada a aguas profundas.', threats:'Contaminación del lago, disminución del stock de peces, perturbación humana.', rec:'Proteger el lago Chinchaycocha; reportar mortalidades o capturas.', endemic:true },
    { id:'sp-rana', common:'Rana de Junín', sci:'Telmatobius macrostomus', cat:'anfibio', prot:'CR', cites:'II', emoji:'🐸', color:['#5b6b34','#222a12'], habitat:'Aguas frías y oxigenadas del lago Chinchaycocha y afluentes.', chars:'Anfibio de gran tamaño, endémico de la cuenca del lago Junín. Indicador de la calidad del agua.', threats:'Sobrexplotación para consumo, contaminación minera y pérdida de hábitat.', rec:'No consumir ni comercializar esta especie; reportar su venta.', endemic:true },
    { id:'sp-taruca', common:'Taruca', sci:'Hippocamelus antisensis', cat:'mamifero', prot:'VU', cites:'I', emoji:'🦌', color:['#7b6247','#33271b'], habitat:'Punas y laderas rocosas altoandinas.', chars:'Cérvido andino de tamaño mediano con astas bifurcadas. Vive en pequeños grupos.', threats:'Caza furtiva, fragmentación de hábitat y competencia con ganado.', rec:'Reportar cacería o venta de carne y trofeos.', endemic:false },
    { id:'sp-mono', common:'Mono choro de cola amarilla', sci:'Oreonax flavicauda', cat:'mamifero', prot:'CR', cites:'I', emoji:'🐒', color:['#87652f','#3a2a10'], habitat:'Bosques nublados de la ceja de selva, principalmente en San Martín, Amazonas y Junín.', chars:'Primate endémico del Perú, con pelaje largo y cola amarilla. Especie emblemática y en peligro crítico.', threats:'Deforestación, caza y tráfico ilegal como mascota.', rec:'No tener primates silvestres como mascotas; denunciar su venta.', endemic:true },
    { id:'sp-lobo-rio', common:'Lobo de río', sci:'Pteronura brasiliensis', cat:'mamifero', prot:'EN', cites:'I', emoji:'🦦', color:['#4c5f55','#1b241f'], habitat:'Ríos y cochas de la Amazonía; en Junín habita cuencas de selva baja.', chars:'Nutria gigante de hábitos diurnos y sociales. Puede medir hasta 1.8 m.', threats:'Caza por piel, minería ilegal y contaminación de ríos.', rec:'Denunciar la venta de pieles y la perturbación de su hábitat.', endemic:false },
    { id:'sp-nutria', common:'Nutria neotropical', sci:'Lontra longicaudis', cat:'mamifero', prot:'VU', cites:'I', emoji:'🦫', color:['#5c6b57','#212a1e'], habitat:'Ríos, arroyos y lagunas de la vertiente amazónica.', chars:'Mustélido semiacuático solitario, indicador de ecosistemas fluviales saludables.', threats:'Contaminación del agua, pérdida de riberas y caza.', rec:'Conservar la vegetación ribereña y reportar capturas.', endemic:false },
    { id:'sp-puma', common:'Puma', sci:'Puma concolor', cat:'mamifero', prot:'NT', cites:'II', emoji:'🐆', color:['#8a6b4c','#3a2a1a'], habitat:'Desde bosques nublados hasta punas, en casi toda la sierra y selva peruana.', chars:'Felino de gran tamaño y amplia distribución. Evita zonas con presencia humana intensa.', threats:'Caza por conflicto ganadero, pérdida de hábitat y atropellos.', rec:'Reportar avistamientos y conflictos; no cazarlo.', endemic:false },
    { id:'sp-venado', common:'Venado gris', sci:'Odocoileus virginianus', cat:'mamifero', prot:'LC', cites:'—', emoji:'🦌', color:['#8d7658','#3c3020'], habitat:'Bosques secos, matorrales y bordes de bosque entre 0 y 4 000 m s. n. m.', chars:'Cérvido de hábitos crepusculares, importante en la dispersión de semillas.', threats:'Caza furtiva y pérdida de cobertura vegetal.', rec:'No adquirir carne de origen desconocido.', endemic:false },
    { id:'sp-gato-andino', common:'Gato andino', sci:'Leopardus jacobita', cat:'mamifero', prot:'EN', cites:'I', emoji:'🐈', color:['#8a8c7f','#2c2f27'], habitat:'Puna y ambientes rocosos altoandinos por encima de 3 500 m s. n. m.', chars:'Felino pequeño de cola larga y pelaje grisáceo con manchas; una de las especies menos conocidas del mundo.', threats:'Pérdida de hábitat, caza y disminución de sus presas (vizcachas).', rec:'Reportar registros con fotografías sin perseguir al animal.', endemic:false },
    { id:'sp-gallito', common:'Gallito de las rocas', sci:'Rupicola peruvianus', cat:'ave', prot:'LC', cites:'II', emoji:'🐦', color:['#b4552d','#4a1c0d'], habitat:'Bosques nublados con quebradas rocosas y vegetación densa.', chars:'Ave nacional del Perú, conocida por el plumaje naranja intenso de los machos y sus exhibiciones de cortejo.', threats:'Captura para avicultura ornamental y pérdida de hábitat.', rec:'No comprar aves silvestres; denunciar su venta.', endemic:false },
    { id:'sp-parihuana', common:'Parihuana andina', sci:'Phoenicopterus chilensis', cat:'ave', prot:'NT', cites:'II', emoji:'🦩', color:['#b96a6a','#4a2222'], habitat:'Lagunas altoandinas y salares; en Junín habita Chinchaycocha.', chars:'Ave filtradora de plumaje rosado, con patas y pico adaptados a aguas someras.', threats:'Perturbación de colonias, contaminación y cambio climático.', rec:'Mantener distancia en lagunas y no alimentar a las aves.', endemic:false },
    { id:'sp-halcon', common:'Halcón peregrino', sci:'Falco peregrinus', cat:'ave', prot:'LC', cites:'II', emoji:'🦅', color:['#4d5a66','#1a2229'], habitat:'Acantilados, cañones y áreas abiertas; también zonas urbanas.', chars:'Rapaz de vuelo veloz, especializada en la caza de aves en vuelo.', threats:'Captura ilegal, contaminantes y perturbación de nidos.', rec:'Reportar tenencia ilegal y perturbación de nidos.', endemic:false },
    { id:'sp-boa', common:'Boa constrictora', sci:'Boa constrictor', cat:'reptil', prot:'LC', cites:'II', emoji:'🐍', color:['#7a6b44','#2e2815'], habitat:'Bosques húmedos y secos, bordes de cultivos y riberas de la selva.', chars:'Serpiente no venenosa que controla poblaciones de roedores.', threats:'Caza por miedo, comercio de pieles y tráfico como mascota.', rec:'No matar serpientes; solicitar manejo especializado.', endemic:false },
    { id:'sp-jergon', common:'Jergón', sci:'Bothrops atrox', cat:'reptil', prot:'LC', cites:'—', emoji:'🐍', color:['#6b5a3b','#241f10'], habitat:'Bosques tropicales húmedos de la Amazonía y vertientes orientales.', chars:'Serpiente venenosa de importancia médica; cumple rol ecológico como depredador.', threats:'Mortalidad por conflicto con personas y pérdida de hábitat.', rec:'No manipular serpientes; acudir de inmediato a un centro de salud ante mordedura.', endemic:false },
    { id:'sp-vizcacha', common:'Vizcacha', sci:'Lagidium viscacia', cat:'mamifero', prot:'LC', cites:'—', emoji:'🐹', color:['#93795b','#3b2f21'], habitat:'Laderas rocosas y formaciones de roca en la puna andina.', chars:'Roedor de cola larga y orejas grandes, adaptado a ambientes rocosos de altura.', threats:'Caza y deterioro de su hábitat rocoso.', rec:'Observar a distancia; no capturar crías.', endemic:false },
    { id:'sp-zorro', common:'Zorro andino', sci:'Lycalopex culpaeus', cat:'mamifero', prot:'LC', cites:'II', emoji:'🦊', color:['#9c6d45','#3f2a17'], habitat:'Punas, matorrales y bosques andinos.', chars:'Cánido oportunista de gran adaptabilidad; controla poblaciones de roedores.', threats:'Caza por conflicto con ganado y uso de su piel.', rec:'Reportar cacería y no adquirir pieles silvestres.', endemic:false }
  ];

  function buildSeed() {
    var now = new Date();
    function daysAgo(n, hour, min) {
      var d = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour || 9, min || 0, 0, 0);
      d.setDate(d.getDate() - n);
      return d.toISOString();
    }
    var users = [
      { id:'u-admin', name:'Carlos Mendoza Rojas', email:'admin@serfor.gob.pe', role:'admin', passHash:hash('Admin2026!'), active:true, createdAt:daysAgo(240,8), createdBy:'sistema', phone:'064-481200' },
      { id:'u-field', name:'Deyvis Huamán Ccarhuaypiña', email:'agente@serfor.gob.pe', role:'field', passHash:hash('Campo2026!'), active:true, createdAt:daysAgo(230,8), createdBy:'u-admin', phone:'964 112 334' },
      { id:'u-field2', name:'Anjhely Trujillo Rosales', email:'agente2@serfor.gob.pe', role:'field', passHash:hash('Campo2026!'), active:true, createdAt:daysAgo(210,9), createdBy:'u-admin', phone:'961 445 902' },
      { id:'u-vet', name:'Shantal Poma Huaman', email:'veterinario@serfor.gob.pe', role:'vet', passHash:hash('Clinica2026!'), active:true, createdAt:daysAgo(228,10), createdBy:'u-admin', phone:'954 778 210' },
      { id:'u-vet2', name:'Madaí Porras Sedano', email:'veterinario2@serfor.gob.pe', role:'vet', passHash:hash('Clinica2026!'), active:true, createdAt:daysAgo(190,11), createdBy:'u-admin', phone:'952 330 118' },
      { id:'u-log', name:'Luis Quispe Ayala', email:'logistica@serfor.gob.pe', role:'logistics', passHash:hash('Stock2026!'), active:true, createdAt:daysAgo(220,12), createdBy:'u-admin', phone:'966 201 774' }
    ];
    var rolePermissions = JSON.parse(JSON.stringify(D.DEFAULT_PERMS));

    var seedDefs = [
      { d:118, sp:'sp-condor', agent:'u-field', type:'rescate', zone:'tunan', status:'liberado', p:'II', ref:'Comunidad de San Jerónimo de Tunán, ladera este', desc:'Ejemplar juvenil hallado en un pastizal, con dificultad para emprender vuelo. Se coordinó con la comunidad para su evaluación.', cond:['Desnutrición','Estrés severo'], records:4, release:{place:'Reserva paisajística Nor Yauyos Cochas, sector Tunan', days:14} },
      { d:104, sp:'sp-gallito', agent:'u-field2', type:'decomiso', zone:'huancayo', status:'custodia', p:'II', ref:'Feria dominical de Huancayo, Jr. Huánuco', desc:'Ave ofrecida para la venta como mascota en la feria dominical. Se decomisaron dos ejemplares; uno fue derivado al zoológico municipal.', cond:['Cautiverio','Venta ilegal'], records:3, custody:{dest:'Zoológico Municipal del Cerrito de la Libertad', days:20} },
      { d:96, sp:'sp-oso', agent:'u-field', type:'rescate', zone:'cajas', status:'en_cuarentena', p:'I', ref:'Sector Quebrada Honda, San Agustín de Cajas', desc:'Cría de oso de anteojos hallada sola junto a cultivos, con deshidratación y heridas superficiales. Atención prioritaria inmediata.', cond:['Desnutrición','Deshidratación','Herida abierta'], records:5 },
      { d:88, sp:'sp-taruca', agent:'u-field2', type:'decomiso', zone:'pucara', status:'liberado', p:'III', ref:'Pucará, ruta a la laguna de Ñahuimpuquio', desc:'Ejemplar adulto trasladado en un vehículo sin autorización. Sin lesiones aparentes; se verificó su estado y se liberó en su hábitat.', cond:['Cautiverio'], records:2, release:{place:'Zona de amortiguamiento de la Reserva de Junín, Pucará', days:9} },
      { d:79, sp:'sp-zambullidor', agent:'u-field', type:'rescate', zone:'tunan', status:'en_cuarentena', p:'I', ref:'Orilla del lago Chinchaycocha, sector San Pedro de Cajas', desc:'Ave acuática varada en la orilla, con compromiso respiratorio y bajo peso. Se activó el protocolo de atención inmediata.', cond:['Herida abierta','Desnutrición'], records:4 },
      { d:71, sp:'sp-rana', agent:'u-field2', type:'rescate', zone:'tunan', status:'en_cuarentena', p:'II', ref:'Canal de regadío cercano al lago Chinchaycocha', desc:'Anfibio hallado en un canal con sedimentos mineros. Se recolectaron muestras de agua y se trasladó para evaluación.', cond:['Estrés severo'], records:3 },
      { d:63, sp:'sp-mono', agent:'u-field', type:'decomiso', zone:'huancayo', status:'custodia', p:'II', ref:'Terminal terrestre de Huancayo', desc:'Primate transportado en una caja sin ventilación. Se decomisó y derivó a un centro autorizado para su evaluación.', cond:['Cautiverio','Estrés severo','Deshidratación'], records:4, custody:{dest:'Centro de Custodia Temporal de Fauna Silvestre – Satipo', days:18} },
      { d:55, sp:'sp-puma', agent:'u-field2', type:'rescate', zone:'sapallanga', status:'liberado', p:'I', ref:'Zona agrícola de Sapallanga, quebrada seca', desc:'Felino juvenil atrapado en una malla de cerco. Presentaba lesiones en una pata; fue evaluado y rehabilitado.', cond:['Fractura','Estrés severo'], records:6, release:{place:'Bosque de protección de Pui Pui, Satipo', days:21} },
      { d:48, sp:'sp-gato-andino', agent:'u-field', type:'rescate', zone:'pucara', status:'eutanasia', p:'I', ref:'Pucará, sector rocoso altoandino', desc:'Felino hallado con traumatismo severo por atropellamiento. El equipo veterinario determinó compromiso vital irreversible.', cond:['Fractura','Herida abierta'], records:2, euthanasia:{reason:'Traumatismo craneoencefálico severo con pronóstico irreversible; se aplicó el protocolo de bienestar animal.', days:1} },
      { d:41, sp:'sp-venado', agent:'u-field2', type:'hallazgo', zone:'chilca', status:'liberado', p:'III', ref:'Borde del río Mantaro, Chilca', desc:'Cría de venado hallada junto al río, sin lesiones. Se verificó que la madre permanecía en la zona y se liberó tras evaluación.', cond:['Sin lesiones aparentes'], records:2, release:{place:'Ribera del río Mantaro, Chilca', days:3} },
      { d:34, sp:'sp-lobo-rio', agent:'u-field', type:'rescate', zone:'sapallanga', status:'en_cuarentena', p:'II', ref:'Río Chanchamayo, límite con Sapallanga', desc:'Nutria gigante hallada con un anzuelo incrustado. Se realizó la extracción y se mantiene en observación.', cond:['Herida abierta'], records:3 },
      { d:27, sp:'sp-parihuana', agent:'u-field2', type:'rescate', zone:'tunan', status:'en_cuarentena', p:'III', ref:'Humedal de Chinchaycocha, sector Chucupampa', desc:'Ave acuática con plumaje impregnado de hidrocarburos. Se inició limpieza y hidratación.', cond:['Estrés severo','Plumaje o pelaje deteriorado'], records:2 },
      { d:19, sp:'sp-halcon', agent:'u-field', type:'decomiso', zone:'el-tambo', status:'liberado', p:'III', ref:'Mercado de animales de El Tambo', desc:'Halcón mantenido en cautiverio para exhibición. Se decomisó, evaluó y liberó sin lesiones.', cond:['Cautiverio'], records:2, release:{place:'Acantilados de Quiullacocha, El Tambo', days:5} },
      { d:12, sp:'sp-boa', agent:'u-field2', type:'rescate', zone:'huancayo', status:'en_cuarentena', p:'II', ref:'Vivienda en el barrio de La Merced, Huancayo', desc:'Serpiente hallada en una vivienda; la familia solicitó su retiro. Se encuentra en observación antes de su reubicación.', cond:['Estrés severo'], records:1 },
      { d:6, sp:'sp-vizcacha', agent:'u-field', type:'rescate', zone:'cajas', status:'registrado', p:'III', ref:'Zona rocosa de San Agustín de Cajas', desc:'Cría de vizcacha hallada fuera de su madriguera, aparentemente sana. Pendiente de evaluación veterinaria.', cond:['Cría huérfana'], records:0 },
      { d:2, sp:'sp-zorro', agent:'u-field2', type:'rescate', zone:'huayucachi', status:'registrado', p:'I', ref:'Carretera Central, km 12, Huayucachi', desc:'Zorro andino atropellado en la Carretera Central. Presenta compromiso vital evidente; se traslada de urgencia.', cond:['Fractura','Herida abierta','Atropellamiento'], records:1 }
    ];

    var interventions = [], clinicalRecords = [], decisions = [];
    var byId = {};
    SPECIES_SEED.forEach(function (s) { byId[s.id] = s; });

    var ordered = seedDefs.slice().sort(function (a, b) { return b.d - a.d; });
    ordered.forEach(function (def, index) {
      var sp = byId[def.sp];
      var zone = D.ZONES.filter(function (z) { return z.key === def.zone; })[0] || D.ZONES[0];
      var agent = users.filter(function (u) { return u.id === def.agent; })[0];
      var occurred = daysAgo(def.d, 7 + (index % 9), (index * 7) % 60);
      var id = 'int-' + String(index + 1).padStart(3, '0');
      var code = 'ATFFS-HYO-' + new Date(occurred).getFullYear() + '-' + D.pad4(index + 1);
      var criteria = def.p === 'I'
        ? { signs: index % 3 === 0 ? 2 : 1, lesions: 2, response: 1, mobility: 1 }
        : def.p === 'II'
          ? { signs: 1, lesions: (index % 2 ? 1 : 0), response: 1, mobility: (index % 2 ? 0 : 1) }
          : { signs: 0, lesions: 0, response: 0, mobility: 1 };
      var tri = D.triage(criteria);
      var lat = zone.lat + ((index % 5) - 2) * 0.0026;
      var lng = zone.lng + ((index % 7) - 3) * 0.0022;
      var intervention = {
        id: id, code: code, type: def.type, createdAt: occurred, occurredAt: occurred,
        agentId: agent.id, agentName: agent.name,
        speciesId: sp.id, speciesName: sp.common, scientificName: sp.sci,
        preliminaryId: ['Juvenil, sexo no determinado', 'Adulto, macho', 'Adulto, hembra', 'Cría, sexo no determinado', 'Juvenil, hembra'][index % 5],
        description: def.desc,
        conditions: def.cond.slice(),
        priority: tri,
        location: {
          lat: +lat.toFixed(5), lng: +lng.toFixed(5), accuracy: 8 + (index % 14),
          source: 'gps', reference: def.ref, zone: zone.name
        },
        photos: [],
        status: def.status === 'liberado' ? 'en_cuarentena' : def.status,
        decisionId: null,
        preacta: { generatedAt: occurred, version: 1 },
        history: [
          { ts: occurred, userId: agent.id, userName: agent.name, action: 'Intervención registrada', detail: 'Código único ' + code + ' · Triaje ' + tri.name + ' (' + tri.score + '/8).' }
        ],
        discharge: false,
        behaviorApt: false,
        updatedAt: occurred
      };
      // Registros clínicos
      var vet = index % 2 ? users[4] : users[3];
      var recCount = def.records || 0;
      for (var r = 0; r < recCount; r++) {
        var recDate = new Date(new Date(occurred).getTime() + (r + 1) * 2.2 * 86400000).toISOString();
        var isLast = r === recCount - 1;
        var isDischarge = (def.status === 'liberado') && isLast;
        var health = r === 0 ? (def.p === 'I' ? 'grave' : def.p === 'II' ? 'estable' : 'bueno') : (isLast ? 'bueno' : 'estable');
        var rec = {
          id: 'rec-' + id + '-' + (r + 1), interventionId: id, type: r === 0 ? 'evaluacion' : 'control',
          ts: recDate, vetId: vet.id, vetName: vet.name,
          vitals: {
            fc: 60 + ((index * 7 + r * 9) % 70), fr: 14 + ((index + r * 3) % 22),
            temp: +(37.2 + ((index + r) % 5) * 0.18).toFixed(1),
            weight: +(3.2 + ((index * 3 + r) % 25) * 0.7).toFixed(1), bodyCondition: 2 + (r % 3)
          },
          diagnosis: r === 0
            ? (def.p === 'I' ? 'Politraumatismo con compromiso vital. Requiere estabilización y fluidoterapia.' : 'Cuadro compatible con desnutrición leve y estrés por cautiverio.')
            : 'Evolución favorable. Control de peso, hidratación y tolerancia alimentaria.',
          medications: r === 0
            ? [{ name: 'Solución fisiológica 0.9%', dose: '15 ml/kg', route: 'IV', freq: 'Cada 8 h', days: 3 }]
            : [{ name: 'Enrofloxacina 10%', dose: '5 mg/kg', route: 'SC', freq: 'Cada 24 h', days: 5 }],
          treatment: r === 0 ? 'Estabilización, analgesia y aislamiento en cuarentena.' : 'Continuar antibioticoterapia y enriquecimiento ambiental.',
          observations: r === 0 ? 'Ingresa a cuarentena. Se solicita control diario de constantes.' : 'Animal activo, consume alimento y muestra mejoría progresiva.',
          health: health,
          discharge: isDischarge,
          behaviorApt: isDischarge ? true : false,
          quarantine: true,
          createdAt: recDate
        };
        clinicalRecords.push(rec);
        intervention.history.push({ ts: recDate, userId: vet.id, userName: vet.name, action: isDischarge ? 'Alta médica registrada' : 'Control clínico registrado', detail: D.HEALTH[health].label + ' · ' + rec.diagnosis });
        if (isDischarge) { intervention.discharge = true; intervention.behaviorApt = true; }
      }
      // Decisiones
      if (def.status === 'liberado' || def.status === 'custodia' || def.status === 'eutanasia') {
        var decType = def.status === 'liberado' ? 'liberacion' : def.status;
        var decDate = daysAgo(def.d - (def.release ? def.release.days : def.custody ? def.custody.days : def.euthanasia ? def.euthanasia.days : 1), 11, 20);
        var dec = {
          id: 'dec-' + id, interventionId: id, type: decType, ts: decDate,
          vetId: vet.id, vetName: vet.name,
          justification: def.release
            ? 'Evaluación clínica favorable, alta médica registrada y comportamiento apto para la vida silvestre.'
            : def.custody
              ? 'El ejemplar no es apto para su liberación inmediata por impronta con seres humanos; se requiere custodia permanente en un centro autorizado.'
              : def.euthanasia.reason,
          destination: def.custody ? def.custody.dest : null,
          releaseDate: def.release ? decDate : null,
          releasePlace: def.release ? def.release.place : null,
          monitoring: def.release ? [
            { id: 'mon-' + index + '-1', ts: new Date(new Date(decDate).getTime() + 4 * 86400000).toISOString(), observations: 'Se observó al ejemplar adaptándose al hábitat; desplazamiento y alimentación normales.', vetName: vet.name }
          ] : []
        };
        decisions.push(dec);
        intervention.decisionId = dec.id;
        intervention.status = def.status;
        intervention.history.push({ ts: decDate, userId: vet.id, userName: vet.name, action: 'Decisión técnica registrada', detail: decType === 'liberacion' ? 'Liberación aprobada.' : decType === 'custodia' ? 'Traslado a custodia permanente.' : 'Eutanasia humanitaria.' });
        intervention.updatedAt = decDate;
      }
      interventions.push(intervention);
    });

    // ---------------- Inventario ----------------
    var inventoryItems = [
      { id:'inv-01', code:'ALI-001', name:'Dieta balanceada para primates', category:'alimento', unit:'kg', stock:24, minStock:20, expiresAt:daysAgo(-120,0), lot:'L-2026-114', supplier:'AgroVet Perú', location:'Almacén A – estante 1', active:true },
      { id:'inv-02', code:'ALI-002', name:'Carne de pollo (ración diaria)', category:'alimento', unit:'kg', stock:18, minStock:15, expiresAt:daysAgo(-6,0), lot:'L-2026-221', supplier:'Distribuidora El Sol', location:'Cámara fría 1', active:true },
      { id:'inv-03', code:'ALI-003', name:'Frutas variadas de estación', category:'alimento', unit:'kg', stock:30, minStock:25, expiresAt:daysAgo(-4,0), lot:'L-2026-233', supplier:'Mercado Mayorista Huancayo', location:'Cámara fría 2', active:true },
      { id:'inv-04', code:'ALI-004', name:'Pellets para aves insectívoras', category:'alimento', unit:'kg', stock:12, minStock:15, expiresAt:daysAgo(-150,0), lot:'L-2026-102', supplier:'AgroVet Perú', location:'Almacén A – estante 2', active:true },
      { id:'inv-05', code:'ALI-005', name:'Heno de alfalfa', category:'alimento', unit:'kg', stock:40, minStock:20, expiresAt:daysAgo(-260,0), lot:'L-2026-090', supplier:'Ganadera Andina', location:'Almacén B', active:true },
      { id:'inv-06', code:'MED-001', name:'Ivermectina 1%', category:'medicamento', unit:'ml', stock:250, minStock:100, expiresAt:daysAgo(-12,0), lot:'IV-8842', supplier:'Farmavet', location:'Refrigerador 1', active:true },
      { id:'inv-07', code:'MED-002', name:'Enrofloxacina 10%', category:'medicamento', unit:'ml', stock:80, minStock:100, expiresAt:daysAgo(-210,0), lot:'EN-5521', supplier:'Farmavet', location:'Estante medicinal 1', active:true },
      { id:'inv-08', code:'MED-003', name:'Dexametasona 2 mg/ml', category:'medicamento', unit:'ml', stock:40, minStock:20, expiresAt:daysAgo(-62,0), lot:'DX-1180', supplier:'Farmavet', location:'Estante medicinal 1', active:true },
      { id:'inv-09', code:'MED-004', name:'Vacuna antirrábica veterinaria', category:'medicamento', unit:'dosis', stock:15, minStock:10, expiresAt:daysAgo(-24,0), lot:'VR-2026-07', supplier:'Biológicos del Perú', location:'Refrigerador 2', active:true },
      { id:'inv-10', code:'MED-005', name:'Solución fisiológica 0.9%', category:'medicamento', unit:'bolsas', stock:30, minStock:20, expiresAt:daysAgo(-400,0), lot:'SF-9921', supplier:'Farmavet', location:'Estante medicinal 2', active:true },
      { id:'inv-11', code:'MED-006', name:'Complejo vitamínico B', category:'medicamento', unit:'ml', stock:6, minStock:10, expiresAt:daysAgo(9,0), lot:'VB-3320', supplier:'Farmavet', location:'Estante medicinal 2', active:true },
      { id:'inv-12', code:'HER-001', name:'Jaulas de contención medianas', category:'herramienta', unit:'unidades', stock:4, minStock:3, expiresAt:null, lot:null, supplier:'Equipos SERFOR', location:'Depósito de campo', active:true },
      { id:'inv-13', code:'HER-002', name:'Lazos de manejo', category:'herramienta', unit:'unidades', stock:6, minStock:8, expiresAt:null, lot:null, supplier:'Equipos SERFOR', location:'Depósito de campo', active:true },
      { id:'inv-14', code:'HER-003', name:'Guantes de cuero reforzado', category:'herramienta', unit:'pares', stock:10, minStock:12, expiresAt:null, lot:null, supplier:'Seguridad Industrial Andina', location:'Depósito de campo', active:true },
      { id:'inv-15', code:'HER-004', name:'Redes de captura', category:'herramienta', unit:'unidades', stock:3, minStock:2, expiresAt:null, lot:null, supplier:'Equipos SERFOR', location:'Depósito de campo', active:true }
    ];
    var movements = [];
    var mIndex = 0;
    function movement(item, type, qty, days, user, reason, interventionId) {
      mIndex++;
      var mvDate = daysAgo(days, 8 + (mIndex % 8), (mIndex * 11) % 60);
      movements.push({
        id: 'mov-' + String(mIndex).padStart(3, '0'), itemId: item.id, itemName: item.name,
        type: type, qty: qty, ts: mvDate, userId: user.id, userName: user.name,
        reason: reason, interventionId: interventionId || null,
        interventionCode: interventionId ? (interventions.filter(function (i) { return i.id === interventionId; })[0] || {}).code : null,
        balanceAfter: item.stock
      });
    }
    movement(inventoryItems[0], 'entrada', 40, 30, users[5], 'Compra programada – orden 045-2026');
    movement(inventoryItems[1], 'entrada', 30, 27, users[5], 'Compra semanal de alimentos');
    movement(inventoryItems[5], 'entrada', 200, 24, users[5], 'Reposición de stock veterinario');
    movement(inventoryItems[6], 'entrada', 100, 22, users[5], 'Reposición de antibióticos');
    movement(inventoryItems[6], 'salida', 20, 6, users[5], 'Tratamiento de oso de anteojos', 'int-003');
    movement(inventoryItems[0], 'salida', 16, 5, users[5], 'Alimentación de primates en custodia', 'int-007');
    movement(inventoryItems[7], 'salida', 10, 4, users[5], 'Manejo antiinflamatorio', 'int-005');
    movement(inventoryItems[8], 'salida', 5, 3, users[5], 'Vacunación de zorro andino', 'int-016');
    movement(inventoryItems[2], 'salida', 12, 2, users[5], 'Dieta diaria de aves y primates');
    movement(inventoryItems[12], 'salida', 2, 1, users[5], 'Operativo de campo – APFFS', 'int-015');
    movement(inventoryItems[13], 'salida', 2, 1, users[5], 'Operativo de campo – APFFS', 'int-015');

    // ---------------- Denuncias ----------------
    var denuncias = [
      { id:'den-001', code:'DEN-2026-0001', ts:daysAgo(21,10,15), type:'venta', species:'Gallito de las rocas', description:'En la feria dominical se observó a una persona ofreciendo aves de colores llamativos en jaulas pequeñas. Comentaba que eran "gallitos de las rocas" traídos de la selva.', location:{ lat:-12.0658, lng:-75.2051, reference:'Feria dominical, Jr. Huánuco, Huancayo', source:'map' }, photos:[], status:'derivada', notes:[{ ts:daysAgo(19,9,0), author:'Carlos Mendoza Rojas', text:'Derivado a la Fiscalía Especializada en Materia Ambiental para verificación en campo.' }] },
      { id:'den-002', code:'DEN-2026-0002', ts:daysAgo(15,16,40), type:'tenencia', species:'Mono choro de cola amarilla', description:'Un vecino mantiene un mono pequeño amarrado en el patio de su vivienda. Lo alimenta con comida casera y lo muestra a los visitantes.', location:{ lat:-12.0452, lng:-75.2128, reference:'Pasaje Los Álamos, El Tambo', source:'map' }, photos:[], status:'en_revision', notes:[{ ts:daysAgo(13,11,30), author:'Carlos Mendoza Rojas', text:'Se coordina visita de inspección con la ATFFS y la municipalidad distrital.' }] },
      { id:'den-003', code:'DEN-2026-0003', ts:daysAgo(9,8,5), type:'transporte', species:'No identificada', description:'Camión con jaulas cubiertas con mantas estacionado en la Carretera Central. Se escuchaban sonidos de aves y se observó movimiento de plumas.', location:{ lat:-12.1310, lng:-75.2215, reference:'Carretera Central, altura de Huayucachi', source:'gps' }, photos:[], status:'nueva', notes:[] },
      { id:'den-004', code:'DEN-2026-0004', ts:daysAgo(4,12,20), type:'maltrato', species:'Tortuga / quelonio', description:'Se observó una tortuga mantenida en un balde sin agua ni sombra en la puerta de un local comercial.', location:{ lat:-12.0808, lng:-75.2031, reference:'Av. Giráldez, Chilca', source:'map' }, photos:[], status:'nueva', notes:[] },
      { id:'den-005', code:'DEN-2026-0005', ts:daysAgo(2,18,10), type:'venta', species:'Boa constrictora', description:'Anuncio en redes sociales ofrece una boa "domesticada" para entrega en el centro de Huancayo. Se adjunta captura de la publicación.', location:{ lat:-12.0662, lng:-75.2067, reference:'Centro de Huancayo', source:'map' }, photos:[], status:'en_revision', notes:[] }
    ];

    var notifications = [];
    interventions.forEach(function (i) {
      if (i.priority.level === 'I' && D.isInCare(i)) {
        notifications.push({
          id: 'ntf-' + i.id, ts: i.createdAt, role: 'vet', type: 'triage',
          title: 'Atención inmediata requerida', message: i.code + ' · ' + i.speciesName + ' clasificado con Prioridad I (crítico).', link: '#/app/rescates/' + i.id, read: false
        });
      }
    });
    D.inventoryAlerts(inventoryItems).forEach(function (a, idx) {
      notifications.push({
        id: 'ntf-inv-' + idx, ts: daysAgo(1, 8, idx), role: 'logistics', type: 'inventory',
        title: a.title, message: a.reason, link: '#/app/inventario', read: false
      });
    });
    denuncias.forEach(function (d) {
      if (d.status === 'nueva') {
        notifications.push({ id: 'ntf-' + d.id, ts: d.ts, role: 'admin', type: 'denuncia', title: 'Nueva denuncia ciudadana', message: d.code + ' · ' + d.type, link: '#/app/denuncias', read: false });
      }
    });

    var audit = [
      { id:'log-seed-1', ts:daysAgo(240,8,0), userId:'u-admin', userName:'Carlos Mendoza Rojas', role:'admin', action:'Sistema inicializado', entity:'sistema', entityId:'—', detail:'Creación del usuario administrador inicial.', sensitive:false },
      { id:'log-seed-2', ts:daysAgo(239,9,15), userId:'u-admin', userName:'Carlos Mendoza Rojas', role:'admin', action:'Usuario creado', entity:'usuario', entityId:'u-field', detail:'Alta de Deyvis Huamán Ccarhuaypiña con rol Agente de Campo.', sensitive:true },
      { id:'log-seed-3', ts:daysAgo(238,10,5), userId:'u-admin', userName:'Carlos Mendoza Rojas', role:'admin', action:'Usuario creado', entity:'usuario', entityId:'u-vet', detail:'Alta de Shantal Poma Huaman con rol Médico Veterinario.', sensitive:true }
    ];

    return {
      version: 3,
      createdAt: now.toISOString(),
      counters: { intervention: ordered.length, denuncia: denuncias.length },
      users: users,
      rolePermissions: rolePermissions,
      interventions: interventions,
      clinicalRecords: clinicalRecords,
      decisions: decisions,
      inventoryItems: inventoryItems,
      movements: movements,
      denuncias: denuncias,
      notifications: notifications,
      audit: audit,
      species: SPECIES_SEED,
      settings: { institution: 'SERFOR — ATFFS Sierra Central, Sede Huancayo', expiryWarningDays: 30, sessionHours: 8 }
    };
  }

  /* ==================================================================
     Acceso y persistencia
     ================================================================== */
  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        if (parsed && parsed.version === 3) return parsed;
      }
    } catch (e) { /* datos corruptos: se regenera */ }
    var seed = buildSeed();
    try { localStorage.setItem(KEY, JSON.stringify(seed)); } catch (e) { /* modo memoria */ }
    return seed;
  }
  function init() { db = load(); return db; }
  function get() { if (!db) init(); return db; }
  function persist() {
    try {
      localStorage.setItem(KEY, JSON.stringify(db));
      document.dispatchEvent(new CustomEvent('sifas:change', { detail: { source: 'store' } }));
    } catch (e) {
      document.dispatchEvent(new CustomEvent('sifas:quota'));
      throw new Error('No se pudo guardar: el almacenamiento local está lleno. Elimine evidencias antiguas o descargue un respaldo.');
    }
  }
  function emit() { document.dispatchEvent(new CustomEvent('sifas:change', { detail: { source: 'store' } })); }
  function reset() {
    db = buildSeed();
    persist();
    return db;
  }

  /* ---------------- Auditoría ---------------- */
  function audit(actor, action, entity, entityId, detail, sensitive) {
    if (!actor) actor = { id: 'anon', name: 'Ciudadano anónimo', role: 'public' };
    var entry = {
      id: U.uid('log'), ts: U.nowISO(), userId: actor.id, userName: actor.name,
      role: actor.role || 'public', action: action, entity: entity, entityId: entityId || '—',
      detail: detail || '', sensitive: !!sensitive
    };
    get().audit.unshift(entry);
    if (db.audit.length > 800) db.audit.length = 800;
    return entry;
  }
  function log(actor, action, entity, entityId, detail, sensitive) {
    var entry = audit(actor, action, entity, entityId, detail, sensitive);
    persist();
    return entry;
  }

  /* ---------------- Notificaciones ---------------- */
  function notify(data) {
    var n = {
      id: U.uid('ntf'), ts: U.nowISO(), role: data.role || 'admin', type: data.type || 'info',
      title: data.title, message: data.message || '', link: data.link || '', read: false
    };
    get().notifications.unshift(n);
    if (db.notifications.length > 200) db.notifications.length = 200;
    return n;
  }
  function notificationsFor(role) {
    return get().notifications.filter(function (n) { return n.role === role || n.role === 'all'; });
  }
  function unreadCount(role) {
    return notificationsFor(role).filter(function (n) { return !n.read; }).length;
  }
  function markRead(id) {
    get().notifications.forEach(function (n) { if (!id || n.id === id) n.read = true; });
    persist();
  }

  /* ---------------- Usuarios y permisos ---------------- */
  function users() { return get().users; }
  function findUser(id) { return get().users.filter(function (u) { return u.id === id; })[0] || null; }
  function findUserByEmail(email) {
    var lower = String(email || '').trim().toLowerCase();
    return get().users.filter(function (u) { return u.email.toLowerCase() === lower; })[0] || null;
  }
  function createUser(data, actor) {
    var email = String(data.email || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new Error('Ingrese un correo electrónico válido.');
    if (findUserByEmail(email)) throw new Error('El correo ' + email + ' ya se encuentra registrado.');
    var pwCheck = D.validatePassword(data.password || '');
    if (!pwCheck.ok) throw new Error('Contraseña insegura: ' + pwCheck.errors.join(' '));
    if (!D.ROLE_DEFS[data.role]) throw new Error('Seleccione un rol válido.');
    var user = {
      id: U.uid('usr'), name: String(data.name || '').trim(), email: email, role: data.role,
      passHash: H.hashPassword(data.password), active: true, createdAt: U.nowISO(),
      createdBy: actor ? actor.id : 'sistema', phone: data.phone || ''
    };
    if (!user.name) throw new Error('Ingrese el nombre completo del usuario.');
    get().users.push(user);
    audit(actor, 'Usuario creado', 'usuario', user.id, 'Alta de ' + user.name + ' con rol ' + D.roleLabel(user.role) + '.', true);
    persist();
    return user;
  }
  function updateUser(id, patch, actor) {
    var user = findUser(id);
    if (!user) throw new Error('Usuario no encontrado.');
    if (patch.email) {
      var email = String(patch.email).trim().toLowerCase();
      var existing = findUserByEmail(email);
      if (existing && existing.id !== id) throw new Error('El correo ya pertenece a otro usuario.');
      user.email = email;
    }
    if (patch.name) user.name = String(patch.name).trim();
    if (patch.phone !== undefined) user.phone = patch.phone;
    if (patch.role && D.ROLE_DEFS[patch.role]) user.role = patch.role;
    if (patch.active !== undefined) user.active = !!patch.active;
    if (patch.password) {
      var check = D.validatePassword(patch.password);
      if (!check.ok) throw new Error('Contraseña insegura: ' + check.errors.join(' '));
      user.passHash = H.hashPassword(patch.password);
    }
    audit(actor, 'Usuario actualizado', 'usuario', user.id, 'Se modificó la cuenta de ' + user.name + (patch.password ? ' (incluye restablecimiento de contraseña).' : '.'), true);
    persist();
    return user;
  }
  function permissionsFor(role) { return get().rolePermissions[role] || []; }
  function can(role, perm) {
    if (role === 'admin') return true;
    return permissionsFor(role).indexOf(perm) >= 0;
  }
  function setRolePermissions(role, perms, actor) {
    if (!D.ROLE_DEFS[role]) throw new Error('Rol inválido.');
    if (role === 'admin') throw new Error('Los permisos del Administrador no se pueden restringir.');
    var valid = D.PERMISSIONS.map(function (p) { return p.key; });
    get().rolePermissions[role] = Array.from(new Set((perms || []).filter(function (p) { return valid.indexOf(p) >= 0; })));
    audit(actor, 'Permisos actualizados', 'rol', role, 'Se actualizaron los permisos del rol ' + D.roleLabel(role) + '.', true);
    persist();
  }

  /* ---------------- Intervenciones ---------------- */
  function interventions() { return get().interventions; }
  function intervention(id) { return get().interventions.filter(function (i) { return i.id === id; })[0] || null; }
  function nextInterventionCode() {
    var year = new Date().getFullYear();
    var prefix = 'ATFFS-HYO-' + year + '-';
    var max = 0;
    get().interventions.forEach(function (i) {
      if (String(i.code).indexOf(prefix) === 0) {
        var n = parseInt(String(i.code).slice(prefix.length), 10);
        if (isFinite(n)) max = Math.max(max, n);
      }
    });
    var candidate;
    do { max++; candidate = prefix + D.pad4(max); }
    while (get().interventions.some(function (i) { return i.code === candidate; }));
    return candidate;
  }
  function createIntervention(data, actor) {
    if (!actor) throw new Error('Debe iniciar sesión para registrar una intervención.');
    if (!data.speciesName) throw new Error('Seleccione o indique la especie del animal.');
    if (!data.description || String(data.description).trim().length < 10) throw new Error('Describa la intervención (mínimo 10 caracteres).');
    var tri = D.triage(data.criteria || {});
    if (!tri.valid) throw new Error(tri.error);
    var code = nextInterventionCode();
    var species = get().species.filter(function (s) { return s.id === data.speciesId; })[0];
    var intv = {
      id: U.uid('int'), code: code, type: data.type || 'rescate',
      createdAt: U.nowISO(), occurredAt: data.occurredAt || U.nowISO(),
      agentId: actor.id, agentName: actor.name,
      speciesId: species ? species.id : null,
      speciesName: data.speciesName,
      scientificName: species ? species.sci : (data.scientificName || 'No identificada'),
      preliminaryId: data.preliminaryId || 'No determinado',
      description: String(data.description).trim(),
      conditions: data.conditions || [],
      priority: tri,
      location: data.location || { lat: null, lng: null, accuracy: null, source: 'sin_gps', reference: '', zone: '' },
      photos: data.photos || [],
      status: 'registrado',
      decisionId: null,
      preacta: { generatedAt: U.nowISO(), version: 1 },
      history: [{
        ts: U.nowISO(), userId: actor.id, userName: actor.name,
        action: 'Intervención registrada',
        detail: 'Código único ' + code + ' · Triaje ' + tri.name + ' (' + tri.score + '/8).'
      }],
      discharge: false, behaviorApt: false, updatedAt: U.nowISO()
    };
    if (intv.location && intv.location.lat !== null && intv.location.lat !== undefined &&
        intv.location.lng !== null && intv.location.lng !== undefined &&
        isFinite(intv.location.lat) && isFinite(intv.location.lng) && !intv.location.zone) {
      var near = D.nearestZone(intv.location.lat, intv.location.lng);
      if (near) intv.location.zone = near.zone.name;
    }
    get().interventions.push(intv);
    audit(actor, 'Intervención registrada', 'intervencion', intv.id, code + ' · ' + intv.speciesName + ' · Prioridad ' + tri.level + '.', true);
    if (tri.level === 'I') {
      notify({
        role: 'vet', type: 'triage', title: 'Atención inmediata requerida',
        message: code + ' · ' + intv.speciesName + ' clasificado con Prioridad I (crítico).',
        link: '#/app/rescates/' + intv.id
      });
    }
    persist();
    return intv;
  }
  function updateIntervention(id, patch, actor, note) {
    var intv = intervention(id);
    if (!intv) throw new Error('Intervención no encontrada.');
    var allowed = ['speciesId', 'speciesName', 'scientificName', 'preliminaryId', 'description', 'conditions', 'occurredAt', 'location', 'type'];
    var changes = [];
    allowed.forEach(function (key) {
      if (patch[key] !== undefined && JSON.stringify(patch[key]) !== JSON.stringify(intv[key])) {
        changes.push(key);
        intv[key] = patch[key];
      }
    });
    if (!changes.length) return intv;
    intv.updatedAt = U.nowISO();
    intv.history.push({
      ts: U.nowISO(), userId: actor.id, userName: actor.name,
      action: 'Datos del animal actualizados',
      detail: 'Campos modificados: ' + changes.map(function (c) {
        return ({ speciesName: 'especie', preliminaryId: 'identificación', description: 'descripción', conditions: 'condiciones', occurredAt: 'fecha', location: 'ubicación', type: 'tipo', speciesId: 'especie', scientificName: 'nombre científico' })[c] || c;
      }).join(', ') + (note ? ' · ' + note : '')
    });
    audit(actor, 'Intervención actualizada', 'intervencion', intv.id, intv.code + ' · ' + changes.join(', '), true);
    persist();
    return intv;
  }
  function setStatus(id, status, actor, detail) {
    var intv = intervention(id);
    if (!intv) return null;
    intv.status = status;
    intv.updatedAt = U.nowISO();
    intv.history.push({ ts: U.nowISO(), userId: actor.id, userName: actor.name, action: 'Estado actualizado', detail: detail || D.STATUS[status].label });
    persist();
    return intv;
  }

  /* ---------------- Historia clínica ---------------- */
  function recordsFor(interventionId) {
    return get().clinicalRecords.filter(function (r) { return r.interventionId === interventionId; })
      .sort(function (a, b) { return new Date(a.ts) - new Date(b.ts); });
  }
  function addRecord(interventionId, data, actor) {
    var intv = intervention(interventionId);
    if (!intv) throw new Error('No se puede crear una historia clínica para un animal no registrado.');
    var type = data.type || 'evaluacion';
    if (type === 'evaluacion') {
      if (!data.diagnosis || String(data.diagnosis).trim().length < 5) throw new Error('Registre el diagnóstico clínico.');
      if (!data.vitals || !data.vitals.fc || !data.vitals.fr || !data.vitals.temp) throw new Error('Complete los signos vitales (FC, FR y temperatura).');
    }
    if (type === 'vacuna' && !String(data.vaccineName || '').trim()) throw new Error('Indique el nombre de la vacuna.');
    if (type === 'dieta' && !String(data.diet || '').trim()) throw new Error('Describa la dieta suministrada.');
    var rec = {
      id: U.uid('rec'), interventionId: interventionId, type: type, ts: data.ts || U.nowISO(),
      vetId: actor.id, vetName: actor.name,
      vitals: data.vitals || null,
      diagnosis: data.diagnosis || '',
      medications: (data.medications || []).filter(function (m) { return m.name; }),
      treatment: data.treatment || '',
      observations: data.observations || '',
      health: data.health || 'estable',
      discharge: !!data.discharge,
      behaviorApt: !!data.behaviorApt,
      quarantine: true,
      vaccineName: data.vaccineName || '',
      vaccineDose: data.vaccineDose || '',
      vaccineLot: data.vaccineLot || '',
      diet: data.diet || '',
      dietQty: data.dietQty || '',
      createdAt: U.nowISO()
    };
    get().clinicalRecords.push(rec);
    if (rec.discharge) intv.discharge = true;
    if (rec.behaviorApt) intv.behaviorApt = true;
    if (intv.status === 'registrado') {
      intv.status = 'en_cuarentena';
      intv.history.push({ ts: U.nowISO(), userId: actor.id, userName: actor.name, action: 'Ingreso a cuarentena', detail: 'Apertura de historia clínica digital y control periódico.' });
    }
    intv.history.push({
      ts: rec.ts, userId: actor.id, userName: actor.name,
      action: rec.discharge ? 'Alta médica registrada' : D.RECORD_TYPES[type].label + ' registrada',
      detail: rec.discharge ? 'El animal cuenta con alta médica; se habilita la evaluación de liberación.' : (rec.diagnosis || rec.observations || rec.vaccineName || rec.diet || '').slice(0, 180)
    });
    intv.updatedAt = U.nowISO();
    audit(actor, 'Registro clínico añadido', 'historia_clinica', intv.id, intv.code + ' · ' + D.RECORD_TYPES[type].label + (rec.discharge ? ' · ALTA MÉDICA' : ''), true);
    persist();
    return rec;
  }
  function clinicalSummary(interventionId) {
    var recs = recordsFor(interventionId);
    var controls = recs.filter(function (r) { return r.type === 'control' || r.type === 'evaluacion'; });
    return {
      records: recs, count: recs.length, last: recs[recs.length - 1] || null,
      lastControl: controls[controls.length - 1] || null,
      hasDischarge: recs.some(function (r) { return r.discharge; }),
      hasApt: recs.some(function (r) { return r.behaviorApt; }),
      weights: controls.filter(function (r) { return r.vitals && r.vitals.weight; }).map(function (r) { return { ts: r.ts, value: Number(r.vitals.weight) }; }),
      healthSeries: controls.map(function (r) { return { ts: r.ts, value: (D.HEALTH[r.health] || D.HEALTH.estable).score, label: (D.HEALTH[r.health] || D.HEALTH.estable).label }; })
    };
  }

  /* ---------------- Decisiones ---------------- */
  function decisionFor(interventionId) {
    return get().decisions.filter(function (d) { return d.interventionId === interventionId; })[0] || null;
  }
  function saveDecision(interventionId, data, actor) {
    var intv = intervention(interventionId);
    if (!intv) throw new Error('Debe identificar al animal antes de registrar una decisión.');
    if (actor.role !== 'vet' && actor.role !== 'admin') throw new Error('Solo un Médico Veterinario puede registrar la decisión técnica.');
    if (decisionFor(interventionId)) throw new Error('Ya existe una decisión técnica registrada para este animal.');
    var check = D.validateDecision(data.type, data);
    if (!check.ok) throw new Error(check.error);
    var recs = recordsFor(interventionId);
    if (data.type === 'liberacion' && !recs.some(function (r) { return r.discharge; })) {
      throw new Error('No se puede liberar: la historia clínica no registra alta médica.');
    }
    if (data.type === 'liberacion' && !recs.some(function (r) { return r.behaviorApt; })) {
      throw new Error('No se puede liberar: no se registró comportamiento apto para liberación.');
    }
    var dec = {
      id: U.uid('dec'), interventionId: interventionId, type: data.type, ts: U.nowISO(),
      vetId: actor.id, vetName: actor.name,
      justification: String(data.justification || '').trim(),
      destination: data.destination || null,
      releaseDate: data.releaseDate || null,
      releasePlace: data.releasePlace || null,
      monitoring: []
    };
    get().decisions.push(dec);
    intv.decisionId = dec.id;
    intv.status = data.type === 'liberacion' ? 'liberado' : data.type === 'custodia' ? 'custodia' : 'eutanasia';
    intv.updatedAt = U.nowISO();
    intv.history.push({
      ts: dec.ts, userId: actor.id, userName: actor.name, action: 'Decisión técnica registrada',
      detail: data.type === 'liberacion' ? 'Liberación aprobada. Lugar: ' + dec.releasePlace + '.' : data.type === 'custodia' ? 'Custodia permanente en ' + dec.destination + '.' : 'Eutanasia humanitaria justificada.'
    });
    audit(actor, 'Decisión técnica registrada', 'intervencion', intv.id, intv.code + ' · ' + data.type.toUpperCase(), true);
    persist();
    return dec;
  }
  function addMonitoring(interventionId, data, actor) {
    var dec = decisionFor(interventionId);
    if (!dec) throw new Error('No existe una liberación registrada para este animal.');
    if (dec.type !== 'liberacion') throw new Error('El monitoreo posterior solo aplica a animales liberados.');
    if (!String(data.observations || '').trim()) throw new Error('Registre las observaciones de adaptación.');
    var mon = { id: U.uid('mon'), ts: U.nowISO(), observations: String(data.observations).trim(), vetName: actor.name };
    dec.monitoring.push(mon);
    var intv = intervention(interventionId);
    if (intv) {
      intv.history.push({ ts: mon.ts, userId: actor.id, userName: actor.name, action: 'Monitoreo post-liberación', detail: mon.observations.slice(0, 160) });
      intv.updatedAt = mon.ts;
    }
    audit(actor, 'Monitoreo post-liberación', 'intervencion', interventionId, 'Registro de adaptación al hábitat.', false);
    persist();
    return mon;
  }

  /* ---------------- Inventario ---------------- */
  function items() { return get().inventoryItems; }
  function item(id) { return get().inventoryItems.filter(function (i) { return i.id === id; })[0] || null; }
  function createItem(data, actor) {
    if (!String(data.name || '').trim()) throw new Error('Ingrese el nombre del insumo.');
    if (!D.INVENTORY_CATEGORIES.some(function (c) { return c.key === data.category; })) throw new Error('Seleccione una categoría válida.');
    var stock = U.num(data.stock, 0);
    var minStock = U.num(data.minStock, 0);
    if (stock < 0 || minStock < 0) throw new Error('El stock y el mínimo no pueden ser negativos.');
    var catPrefix = { alimento: 'ALI', medicamento: 'MED', herramienta: 'HER' }[data.category];
    var count = get().inventoryItems.filter(function (i) { return i.category === data.category; }).length + 1;
    var it = {
      id: U.uid('inv'), code: catPrefix + '-' + D.pad4(count), name: String(data.name).trim(),
      category: data.category, unit: data.unit || 'unidades', stock: stock,
      minStock: minStock, expiresAt: data.expiresAt || null, lot: data.lot || null,
      supplier: data.supplier || '', location: data.location || '', active: true,
      createdAt: U.nowISO(), createdBy: actor.name
    };
    if (data.category === 'medicamento' && !data.expiresAt) throw new Error('Los medicamentos deben registrar fecha de vencimiento.');
    get().inventoryItems.push(it);
    if (stock > 0) {
      get().movements.unshift({
        id: U.uid('mov'), itemId: it.id, itemName: it.name, type: 'entrada', qty: stock,
        ts: U.nowISO(), userId: actor.id, userName: actor.name,
        reason: 'Stock inicial del insumo', interventionId: null, interventionCode: null, balanceAfter: stock
      });
    }
    audit(actor, 'Insumo registrado', 'inventario', it.id, it.name + ' · ' + stock + ' ' + it.unit, false);
    persist();
    return it;
  }
  function updateItem(id, patch, actor) {
    var it = item(id);
    if (!it) throw new Error('Insumo no encontrado.');
    ['name', 'category', 'unit', 'minStock', 'expiresAt', 'lot', 'supplier', 'location'].forEach(function (k) {
      if (patch[k] !== undefined) it[k] = patch[k];
    });
    if (patch.active !== undefined) it.active = !!patch.active;
    audit(actor, 'Insumo actualizado', 'inventario', it.id, it.name, false);
    persist();
    return it;
  }
  function movements() { return get().movements; }
  function moveStock(itemId, data, actor) {
    var it = item(itemId);
    if (!it) throw new Error('Insumo no encontrado.');
    var qty = U.num(data.qty);
    if (data.type === 'salida') {
      var check = D.validateExit(it.stock, qty);
      if (!check.ok) throw new Error(check.error);
      it.stock = U.round(it.stock - qty, 2);
    } else {
      if (!(qty > 0)) throw new Error('La cantidad debe ser mayor a cero.');
      it.stock = U.round(it.stock + qty, 2);
    }
    var intv = data.interventionId ? intervention(data.interventionId) : null;
    var mv = {
      id: U.uid('mov'), itemId: it.id, itemName: it.name, type: data.type, qty: qty,
      ts: U.nowISO(), userId: actor.id, userName: actor.name,
      reason: data.reason || (data.type === 'entrada' ? 'Entrada de stock' : 'Salida de stock'),
      interventionId: intv ? intv.id : null, interventionCode: intv ? intv.code : null,
      balanceAfter: it.stock
    };
    get().movements.unshift(mv);
    audit(actor, data.type === 'entrada' ? 'Entrada de inventario' : 'Salida de inventario', 'inventario', it.id,
      it.name + ' · ' + qty + ' ' + it.unit + ' · saldo ' + it.stock + (intv ? ' · ' + intv.code : ''), false);
    if (it.stock <= it.minStock) {
      notify({ role: 'logistics', type: 'inventory', title: 'Stock mínimo alcanzado', message: it.name + ': quedan ' + it.stock + ' ' + it.unit + ' (mínimo ' + it.minStock + ').', link: '#/app/inventario' });
    }
    persist();
    return mv;
  }

  /* ---------------- Denuncias ---------------- */
  function denuncias() { return get().denuncias; }
  function denuncia(id) { return get().denuncias.filter(function (d) { return d.id === id; })[0] || null; }
  function nextDenunciaCode() {
    var year = new Date().getFullYear();
    var prefix = 'DEN-' + year + '-';
    var max = 0;
    get().denuncias.forEach(function (d) {
      if (String(d.code).indexOf(prefix) === 0) {
        var n = parseInt(String(d.code).slice(prefix.length), 10);
        if (isFinite(n)) max = Math.max(max, n);
      }
    });
    var candidate;
    do { max++; candidate = prefix + D.pad4(max); }
    while (get().denuncias.some(function (d) { return d.code === candidate; }));
    return candidate;
  }
  function createDenuncia(data) {
    if (!data.description || String(data.description).trim().length < 20) throw new Error('Describa el hecho con al menos 20 caracteres.');
    var code = nextDenunciaCode();
    var den = {
      id: U.uid('den'), code: code, ts: U.nowISO(), type: data.type || 'venta',
      species: data.species || 'No identificada',
      description: String(data.description).trim(),
      location: data.location || null,
      photos: data.photos || [],
      status: 'nueva', notes: []
    };
    get().denuncias.push(den);
    audit({ id: 'anon', name: 'Ciudadano anónimo', role: 'public' }, 'Denuncia anónima registrada', 'denuncia', den.id, code + ' · sin datos personales.', true);
    notify({ role: 'admin', type: 'denuncia', title: 'Nueva denuncia ciudadana', message: code + ' · ' + (D.DENUNCIA_TYPES.filter(function (t) { return t.key === den.type; })[0] || {}).label, link: '#/app/denuncias' });
    persist();
    return den;
  }
  function findDenunciaByCode(code) {
    var c = String(code || '').trim().toUpperCase();
    return get().denuncias.filter(function (d) { return d.code.toUpperCase() === c; })[0] || null;
  }
  function updateDenuncia(id, patch, actor) {
    var den = denuncia(id);
    if (!den) throw new Error('Denuncia no encontrada.');
    if (patch.status && D.DENUNCIA_STATUS[patch.status]) den.status = patch.status;
    if (patch.note && String(patch.note).trim()) {
      den.notes.push({ ts: U.nowISO(), author: actor.name, text: String(patch.note).trim() });
    }
    audit(actor, 'Denuncia actualizada', 'denuncia', den.id, den.code + ' · estado ' + den.status, true);
    persist();
    return den;
  }

  /* ---------------- Especies ---------------- */
  function species() { return get().species; }
  function findSpecies(id) { return get().species.filter(function (s) { return s.id === id; })[0] || null; }

  /* ---------------- Estadísticas ---------------- */
  function stats() {
    var all = get().interventions;
    var inCare = all.filter(D.isInCare);
    var released = all.filter(function (i) { return i.status === 'liberado'; });
    var custody = all.filter(function (i) { return i.status === 'custodia'; });
    var euthanasia = all.filter(function (i) { return i.status === 'eutanasia'; });
    var critical = inCare.filter(function (i) { return i.priority.level === 'I'; });
    return {
      total: all.length, inCare: inCare.length, released: released.length,
      custody: custody.length, euthanasia: euthanasia.length, critical: critical.length,
      denuncias: get().denuncias.length, newDenuncias: get().denuncias.filter(function (d) { return d.status === 'nueva'; }).length,
      inventoryAlerts: D.inventoryAlerts(get().inventoryItems).length,
      speciesInCare: U.unique(inCare.map(function (i) { return i.speciesName; })).length
    };
  }

  S.Store = {
    KEY: KEY, init: init, get: get, persist: persist, reset: reset,
    audit: audit, log: log,
    notify: notify, notificationsFor: notificationsFor, unreadCount: unreadCount, markRead: markRead,
    users: users, findUser: findUser, findUserByEmail: findUserByEmail, createUser: createUser, updateUser: updateUser,
    permissionsFor: permissionsFor, can: can, setRolePermissions: setRolePermissions,
    interventions: interventions, intervention: intervention, nextInterventionCode: nextInterventionCode,
    createIntervention: createIntervention, updateIntervention: updateIntervention, setStatus: setStatus,
    recordsFor: recordsFor, addRecord: addRecord, clinicalSummary: clinicalSummary,
    decisionFor: decisionFor, saveDecision: saveDecision, addMonitoring: addMonitoring,
    items: items, item: item, createItem: createItem, updateItem: updateItem,
    movements: movements, moveStock: moveStock,
    denuncias: denuncias, denuncia: denuncia, createDenuncia: createDenuncia, findDenunciaByCode: findDenunciaByCode, updateDenuncia: updateDenuncia,
    species: species, findSpecies: findSpecies, stats: stats,
    exportAll: function () { return JSON.parse(JSON.stringify(get())); },
    importAll: function (data, actor) {
      if (!data || data.version !== 3 || !Array.isArray(data.interventions) || !Array.isArray(data.users)) {
        throw new Error('El archivo no corresponde a un respaldo válido de SIFAS.');
      }
      if (!data.users.some(function (u) { return u && u.active && u.role === 'admin'; })) {
        throw new Error('El respaldo no contiene un administrador activo y no puede restaurarse.');
      }
      var base = buildSeed();
      var next = {
        version: 3,
        createdAt: data.createdAt || U.nowISO(),
        users: data.users,
        interventions: data.interventions
      };
      ['clinicalRecords', 'decisions', 'inventoryItems', 'movements', 'denuncias', 'notifications', 'audit', 'species'].forEach(function (key) {
        next[key] = Array.isArray(data[key]) ? data[key] : base[key];
      });
      next.rolePermissions = (data.rolePermissions && typeof data.rolePermissions === 'object') ? data.rolePermissions : {};
      Object.keys(base.rolePermissions).forEach(function (role) {
        if (!Array.isArray(next.rolePermissions[role])) next.rolePermissions[role] = base.rolePermissions[role].slice();
      });
      var settings = (data.settings && typeof data.settings === 'object') ? data.settings : {};
      var hours = Number(settings.sessionHours);
      next.settings = {
        institution: (typeof settings.institution === 'string' && settings.institution.trim()) ? settings.institution.trim() : base.settings.institution,
        expiryWarningDays: base.settings.expiryWarningDays,
        sessionHours: (isFinite(hours) && hours >= 1 && hours <= 24) ? Math.round(hours) : base.settings.sessionHours
      };
      var counters = (data.counters && typeof data.counters === 'object') ? data.counters : {};
      next.counters = {
        intervention: isFinite(Number(counters.intervention)) ? Number(counters.intervention) : data.interventions.length,
        denuncia: isFinite(Number(counters.denuncia)) ? Number(counters.denuncia) : next.denuncias.length
      };
      db = next;
      audit(actor, 'Respaldo restaurado', 'sistema', '—', 'Importación de copia de seguridad con ' + data.interventions.length + ' intervenciones.', true);
      persist();
    }
  };
})(typeof window !== 'undefined' ? window : this);
